-- ======================================================================
-- EcoTrack: AI-Powered Smart Waste Management & Reporting Platform
-- MySQL Relational Database Schema
-- Compatible with MySQL 8.0+ / MariaDB
-- ======================================================================

SET FOREIGN_KEY_CHECKS = 0;
DROP TABLE IF EXISTS hotspot_data;
DROP TABLE IF EXISTS violation_evidence;
DROP TABLE IF EXISTS vehicle_records;
DROP TABLE IF EXISTS violations;
DROP TABLE IF EXISTS rewards;
DROP TABLE IF EXISTS credit_points;
DROP TABLE IF EXISTS notifications;
DROP TABLE IF EXISTS waste_centers;
DROP TABLE IF EXISTS assignments;
DROP TABLE IF EXISTS waste_reports;
DROP TABLE IF EXISTS waste_scans;
DROP TABLE IF EXISTS waste_categories;
DROP TABLE IF EXISTS workers;
DROP TABLE IF EXISTS admins;
DROP TABLE IF EXISTS users;
SET FOREIGN_KEY_CHECKS = 1;

-- 1. USERS (Citizens, Workers, Admins, Enforcement Officers)
CREATE TABLE users (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    mobile_number VARCHAR(20) NOT NULL,
    role ENUM('citizen', 'admin', 'worker', 'enforcement') NOT NULL DEFAULT 'citizen',
    profile_photo VARCHAR(500) NULL,
    vehicle_number VARCHAR(30) NULL,
    license_number VARCHAR(40) NULL,
    credit_points INT NOT NULL DEFAULT 100,
    green_score INT NOT NULL DEFAULT 150,
    account_status ENUM('active', 'warning', 'fine_pending', 'temporarily_restricted', 'suspended') NOT NULL DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_user_role (role),
    INDEX idx_user_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 2. ADMINS (Municipal Officers & System Admins)
CREATE TABLE admins (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    department VARCHAR(100) NOT NULL DEFAULT 'Solid Waste Management',
    designation VARCHAR(100) NOT NULL DEFAULT 'Municipal Officer',
    jurisdiction_zone VARCHAR(100) NOT NULL DEFAULT 'Central Zone',
    badge_number VARCHAR(50) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 3. WORKERS (Field Sanitation & Collection Workforce)
CREATE TABLE workers (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    worker_id VARCHAR(50) NOT NULL UNIQUE,
    assigned_zone VARCHAR(100) NOT NULL,
    vehicle_type VARCHAR(50) DEFAULT 'Compactor Truck',
    vehicle_number VARCHAR(30),
    is_available BOOLEAN DEFAULT TRUE,
    current_lat DECIMAL(10, 8),
    current_lng DECIMAL(11, 8),
    tasks_completed INT DEFAULT 0,
    rating DECIMAL(2, 1) DEFAULT 4.8,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 4. WASTE CATEGORIES
CREATE TABLE waste_categories (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    classification ENUM('Recyclable', 'Biodegradable', 'Hazardous', 'Special Disposal', 'Non-Recyclable') NOT NULL,
    description TEXT NOT NULL,
    environmental_impact TEXT NOT NULL,
    correct_disposal TEXT NOT NULL,
    recycling_info TEXT NOT NULL,
    safety_precautions TEXT NOT NULL,
    color_code VARCHAR(10) DEFAULT '#10B981',
    icon_name VARCHAR(50) DEFAULT 'Trash2',
    degradation_period VARCHAR(100) DEFAULT 'Unknown',
    points_reward INT DEFAULT 10
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 5. WASTE SCANS (AI Vision Scanner logs)
CREATE TABLE waste_scans (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    image_url TEXT NOT NULL,
    detected_category_id VARCHAR(50) NOT NULL,
    detected_item_name VARCHAR(100) NOT NULL,
    confidence_score DECIMAL(5, 2) NOT NULL,
    disposal_instructions TEXT,
    points_awarded INT DEFAULT 5,
    scan_timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (detected_category_id) REFERENCES waste_categories(id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 6. WASTE REPORTS (Citizen Garbage Complaints)
CREATE TABLE waste_reports (
    id VARCHAR(36) PRIMARY KEY,
    complaint_id VARCHAR(30) NOT NULL UNIQUE,
    user_id VARCHAR(36) NOT NULL,
    category_id VARCHAR(50) NOT NULL,
    description TEXT NOT NULL,
    image_url TEXT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    address TEXT NOT NULL,
    priority ENUM('low', 'medium', 'high', 'critical') DEFAULT 'medium',
    status ENUM('Submitted', 'Under Verification', 'Verified', 'Worker Assigned', 'In Progress', 'Resolved', 'Rejected') DEFAULT 'Submitted',
    assigned_worker_id VARCHAR(36) NULL,
    before_photo_url TEXT NULL,
    after_photo_url TEXT NULL,
    rejection_reason TEXT NULL,
    verified_by VARCHAR(36) NULL,
    verified_at TIMESTAMP NULL,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (category_id) REFERENCES waste_categories(id),
    FOREIGN KEY (assigned_worker_id) REFERENCES workers(id) ON DELETE SET NULL,
    INDEX idx_report_status (status),
    INDEX idx_report_priority (priority)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 7. ASSIGNMENTS (Worker Job Dispatches)
CREATE TABLE assignments (
    id VARCHAR(36) PRIMARY KEY,
    report_id VARCHAR(36) NOT NULL,
    worker_id VARCHAR(36) NOT NULL,
    assigned_by VARCHAR(36) NOT NULL,
    assignment_status ENUM('Assigned', 'Accepted', 'On the Way', 'Cleaning', 'Proof Uploaded', 'Completed') DEFAULT 'Assigned',
    notes TEXT,
    accepted_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (report_id) REFERENCES waste_reports(id) ON DELETE CASCADE,
    FOREIGN KEY (worker_id) REFERENCES workers(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 8. WASTE CENTERS (Recycling and Collection Facilities)
CREATE TABLE waste_centers (
    id VARCHAR(36) PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    facility_type ENUM('Recycling Center', 'E-Waste Center', 'Dry Waste Collection Point', 'Wet Waste Composting Facility', 'Hazardous Waste Depot', 'Smart Public Bin') NOT NULL,
    address TEXT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    contact_phone VARCHAR(20),
    operating_hours VARCHAR(100) DEFAULT '08:00 AM - 06:00 PM',
    accepted_categories TEXT NOT NULL,
    capacity_status ENUM('normal', 'high', 'full') DEFAULT 'normal',
    is_active BOOLEAN DEFAULT TRUE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 9. NOTIFICATIONS
CREATE TABLE notifications (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    type ENUM('report_status', 'points_earned', 'violation_alert', 'general_announcement', 'worker_dispatch') NOT NULL,
    related_id VARCHAR(50) NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    INDEX idx_notif_user_read (user_id, is_read)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 10. CREDIT POINTS (Green Rewards Ledger)
CREATE TABLE credit_points (
    id VARCHAR(36) PRIMARY KEY,
    user_id VARCHAR(36) NOT NULL,
    amount INT NOT NULL,
    activity_type ENUM('waste_scan', 'correct_disposal', 'valid_report', 'verified_illegal_dumping_report', 'community_cleanup', 'false_report_penalty', 'reward_redemption') NOT NULL,
    description VARCHAR(255) NOT NULL,
    reference_id VARCHAR(50) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 11. REWARDS (Redeemable Green Badges & Municipal Vouchers)
CREATE TABLE rewards (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    badge_title VARCHAR(100) NOT NULL,
    points_required INT NOT NULL,
    category ENUM('badge', 'municipal_discount', 'transit_pass', 'eco_merchandise', 'plantation') NOT NULL,
    description TEXT NOT NULL,
    icon_name VARCHAR(50) DEFAULT 'Award'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 12. VEHICLE RECORDS (Enforcement Vehicle Database)
CREATE TABLE vehicle_records (
    vehicle_number VARCHAR(30) PRIMARY KEY,
    owner_name VARCHAR(100),
    vehicle_type VARCHAR(50),
    registered_rto VARCHAR(100),
    restriction_status ENUM('Cleared', 'Warning', 'Fine Pending', 'Temporarily Restricted') DEFAULT 'Cleared',
    total_violations INT DEFAULT 0,
    last_violation_date TIMESTAMP NULL,
    notes TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 13. VIOLATIONS (Illegal Dumping & Enforcement Cases)
CREATE TABLE violations (
    id VARCHAR(36) PRIMARY KEY,
    case_number VARCHAR(30) NOT NULL UNIQUE,
    reporter_id VARCHAR(36) NOT NULL,
    vehicle_number VARCHAR(30) NOT NULL,
    location_address TEXT NOT NULL,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    incident_timestamp TIMESTAMP NOT NULL,
    ocr_confidence DECIMAL(5, 2) DEFAULT 0.00,
    violation_type VARCHAR(100) DEFAULT 'Illegal Solid Waste Dumping',
    status ENUM('Pending Verification', 'Verified Violation', 'Warning Issued', 'Fine Levied', 'Restriction Applied', 'Dismissed') DEFAULT 'Pending Verification',
    penalty_amount DECIMAL(10, 2) DEFAULT 0.00,
    verified_by VARCHAR(36) NULL,
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (reporter_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 14. VIOLATION EVIDENCE
CREATE TABLE violation_evidence (
    id VARCHAR(36) PRIMARY KEY,
    violation_id VARCHAR(36) NOT NULL,
    evidence_type ENUM('vehicle_photo', 'dumping_photo', 'cctv_frame', 'document') NOT NULL,
    image_url TEXT NOT NULL,
    plate_bounding_box JSON NULL,
    uploaded_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (violation_id) REFERENCES violations(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- 15. HOTSPOT DATA (AI Risk Prediction & Historical Frequency)
CREATE TABLE hotspot_data (
    id VARCHAR(36) PRIMARY KEY,
    zone_name VARCHAR(100) NOT NULL,
    risk_level ENUM('High', 'Medium', 'Low') NOT NULL,
    complaint_count INT DEFAULT 0,
    predicted_probability DECIMAL(5, 2) DEFAULT 0.00,
    primary_waste_type VARCHAR(50) DEFAULT 'Plastic',
    recommended_action TEXT,
    latitude DECIMAL(10, 8) NOT NULL,
    longitude DECIMAL(11, 8) NOT NULL,
    radius_meters INT DEFAULT 500,
    last_assessed TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
