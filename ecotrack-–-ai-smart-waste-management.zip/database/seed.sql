-- ======================================================================
-- EcoTrack Seed Data: Smart City Initial Dataset
-- ======================================================================

-- 1. WASTE CATEGORIES
INSERT INTO waste_categories (id, name, classification, description, environmental_impact, correct_disposal, recycling_info, safety_precautions, color_code, icon_name, degradation_period, points_reward) VALUES
('cat_organic', 'Organic / Wet Waste', 'Biodegradable', 'Kitchen food scraps, vegetable peels, leftovers, coffee grounds, and garden foliage.', 'Decomposing organic waste in landfills produces potent methane gas. Proper composting yields rich fertilizer.', 'Segregate in green bin. Drain liquids before disposal. Do not mix with plastic wrappers.', '100% compostable through aerated composting or biomethanation.', 'Keep bins covered to avoid flies and odors.', '#10B981', 'Apple', '2 to 6 weeks', 10),
('cat_plastic', 'Plastic Waste', 'Recyclable', 'PET beverage bottles, HDPE containers, polythene bags, packaging films, and food trays.', 'Plastic takes 450+ years to degrade and breaks into microplastics that contaminate soil, waterways, and marine life.', 'Rinse residue, crush to reduce volume, place in dry blue recycling bin.', 'Can be shredded into flakes, melted into pellets, and remanufactured into fabrics or recycled containers.', 'Never burn plastics; toxic dioxins are released.', '#3B82F6', 'Package', '100 to 500 years', 10),
('cat_paper', 'Paper & Cardboard', 'Recyclable', 'Newspapers, corrugated cartons, office stationery, magazines, and paper bags.', 'Heavy paper demand drives deforestation and industrial water consumption; recycling saves 17 trees per ton.', 'Flatten cardboard boxes. Keep completely dry; grease-soaked paper should go to compost.', 'Pulp fibers can be reprocessed 5 to 7 times into packaging or newspaper.', 'Keep dry; soggy or oil-stained paper cannot be processed in optical sorters.', '#F59E0B', 'FileText', '2 to 5 months', 10),
('cat_glass', 'Glass Waste', 'Recyclable', 'Glass bottles, condiment jars, laboratory glassware, and broken glass containers.', 'Glass does not biodegrade in landfills but can be 100% infinitely melted and recycled without quality loss.', 'Rinse clean, remove plastic caps, store in dedicated glass bin. Handle broken glass with gloves.', 'Crushed into cullet, melted at high temperatures into new bottles, reducing furnace energy by 30%.', 'Wrap broken shards in newspaper and label clearly to protect sanitation workers.', '#06B6D4', 'Wine', '1,000,000+ years', 15),
('cat_metal', 'Metal & Cans', 'Recyclable', 'Aluminum beverage cans, tin food tins, scrap iron, copper wire, and foil wrappers.', 'Mining bauxite and iron ore causes major land degradation. Recycling aluminum saves 95% of energy.', 'Rinse food remnants, compress aluminum cans, place in dry metal recycling stream.', 'Melted in electric arc furnaces and reshaped into automotive parts, cans, and structural steel.', 'Watch for sharp ragged edges when handling cut tin cans.', '#64748B', 'Hammer', '50 to 200 years', 15),
('cat_ewaste', 'E-Waste (Electronic)', 'Special Disposal', 'Outdated mobile phones, lithium batteries, printed circuit boards, chargers, and monitors.', 'Contains valuable gold and copper, but also toxic lead, cadmium, and mercury that poison groundwater.', 'Never throw in regular trash. Drop off at designated municipal E-Waste collection points.', 'Specialized hydrometallurgical recycling extracts precious metals and safely treats hazardous components.', 'Do not puncture lithium batteries; risk of thermal runaway and fire.', '#8B5CF6', 'Cpu', 'Non-biodegradable', 25),
('cat_hazardous', 'Hazardous Waste', 'Hazardous', 'Paint cans, harsh solvents, pesticides, engine oil, fluorescents, and chemical cleaners.', 'Severe biohazard; poisons water tables, harms soil biology, and creates explosive or toxic vapors.', 'Store in original sealed containers with labels intact. Hand over only to authorized hazardous waste depots.', 'Treated through high-temperature incineration, neutralization, or specialized secure landfills.', 'Wear protective gloves; keep strictly out of reach of children and water drains.', '#EF4444', 'AlertTriangle', 'Non-biodegradable', 30),
('cat_construction', 'Construction & Demolition', 'Special Disposal', 'Concrete rubble, broken tiles, masonry bricks, gypsum board, and sand.', 'High volume blocks stormwater drains, creates airborne silica dust (PM2.5/PM10), and causes siltation.', 'Call municipal C&D bulk collection or transport to certified crushing and recycling aggregate facilities.', 'Crushed into recycled aggregates, paver blocks, sub-base gravel for road construction.', 'Wear dust mask and safety boots during loading and transportation.', '#78716C', 'HardHat', 'Non-biodegradable', 20),
('cat_biomedical', 'Biomedical / Sanitary Waste', 'Special Disposal', 'Face masks, sanitary pads, bandages, expired medicines, and disposable syringes.', 'High pathogen transmission risk; can infect sanitation workers and stray animals.', 'Wrap securely in newspaper with a red marker cross, or place in designated yellow biohazard bag.', 'Subjected to autoclave sterilization and controlled medical incineration.', 'Never flush pads or wipes down toilets; causes severe sewer blockages.', '#EC4899', 'ShieldAlert', '25 to 500 years', 20),
('cat_general', 'General Non-Recyclable', 'Non-Recyclable', 'Multi-layer chip packaging, thermally coated receipts, dirty ceramics, and vacuum dust.', 'Contributes to landfill volume and requires methane containment.', 'Deposit into black general waste bin only when items cannot be recycled or composted.', 'Processed through Waste-to-Energy (incineration for electricity generation) or engineered landfill.', 'Ensure no hazardous or e-waste items are mixed inside.', '#94A3B8', 'Trash', 'Indefinite', 5);

-- 2. USERS
INSERT INTO users (id, name, email, password_hash, mobile_number, role, profile_photo, vehicle_number, license_number, credit_points, green_score, account_status) VALUES
('usr_citizen_1', 'Priya Sharma', 'citizen@ecotrack.city', '$2a$10$wK4...hash', '+91 98230 45671', 'citizen', 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150', 'MH12AB4589', 'DL-12201900341', 340, 850, 'active'),
('usr_citizen_2', 'Rahul Verma', 'rahul.v@ecotrack.city', '$2a$10$wK4...hash', '+91 97110 88234', 'citizen', 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150', 'MH12CD8821', 'DL-12201800912', 2450, 1420, 'active'),
('usr_citizen_3', 'Amina Khan', 'amina.k@ecotrack.city', '$2a$10$wK4...hash', '+91 98450 11923', 'citizen', 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150', 'MH14XY1029', 'DL-14202100876', 2120, 1310, 'active'),
('usr_admin_1', 'Rajiv Nair', 'admin@ecotrack.city', '$2a$10$wK4...hash', '+91 98221 00987', 'admin', 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150', 'MH12GOV001', 'DL-GOV-9981', 1200, 990, 'active'),
('usr_worker_1', 'Suresh Kumar', 'worker@ecotrack.city', '$2a$10$wK4...hash', '+91 94230 55123', 'worker', 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=150', 'MH12TRK108', 'DL-COMM-4412', 650, 920, 'active'),
('usr_enforce_1', 'Inspector Vikram Deshmukh', 'enforcement@ecotrack.city', '$2a$10$wK4...hash', '+91 99230 77412', 'enforcement', 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=150', 'MH12POL055', 'DL-POL-8812', 890, 940, 'active');

-- 3. ADMINS
INSERT INTO admins (id, user_id, department, designation, jurisdiction_zone, badge_number) VALUES
('adm_1', 'usr_admin_1', 'Urban Environment & Sanitation', 'Chief Sanitation Commissioner', 'Central Municipal Zone', 'PMC-SWM-801');

-- 4. WORKERS
INSERT INTO workers (id, user_id, worker_id, assigned_zone, vehicle_type, vehicle_number, is_available, current_lat, current_lng, tasks_completed, rating) VALUES
('wrk_1', 'usr_worker_1', 'WK-4092', 'Central Market & Station Corridor', 'Hydraulic Compactor (8 Ton)', 'MH12TRK108', TRUE, 18.5204, 73.8567, 142, 4.9);

-- 5. WASTE CENTERS
INSERT INTO waste_centers (id, name, facility_type, address, latitude, longitude, contact_phone, operating_hours, accepted_categories, capacity_status, is_active) VALUES
('wc_1', 'Central Eco-Recycling Hub', 'Recycling Center', 'Sector 4, Near Gandhi Smriti Circle', 18.5245, 73.8580, '+91 20 2553 4100', '07:00 AM - 08:00 PM', 'Plastic, Paper, Glass, Metal', 'normal', TRUE),
('wc_2', 'Metro Electronic Waste Safe Drop', 'E-Waste Center', 'Old Railway Workshop Road, Station Area', 18.5292, 73.8741, '+91 20 2612 8890', '09:00 AM - 05:00 PM', 'E-Waste, Batteries, Computers', 'normal', TRUE),
('wc_3', 'GreenLeaf Composting Facility', 'Wet Waste Composting Facility', 'Agronomy Campus, University Road', 18.5390, 73.8290, '+91 20 2569 1120', '06:00 AM - 06:00 PM', 'Organic / Wet Waste, Garden Waste', 'normal', TRUE),
('wc_4', 'Municipal Hazardous Waste Depot', 'Hazardous Waste Depot', 'MIDC Industrial Gate 2, Hadapsar', 18.5020, 73.9280, '+91 20 2687 4300', '10:00 AM - 04:00 PM', 'Hazardous Waste, Paints, Solvents', 'normal', TRUE),
('wc_5', 'Smart Solar Bin 14 - Market Gate', 'Smart Public Bin', 'Main Vegetable Market Outer Gate', 18.5180, 73.8540, '+91 20 2553 4101', '24 Hours Open', 'Dry Recyclables, Plastic Cans', 'high', TRUE);

-- 6. WASTE REPORTS
INSERT INTO waste_reports (id, complaint_id, user_id, category_id, description, image_url, latitude, longitude, address, priority, status, assigned_worker_id, before_photo_url, after_photo_url, created_at) VALUES
('rep_1', 'WT-2026-00125', 'usr_citizen_1', 'cat_plastic', 'Heavy pile of discarded plastic packaging and pet bottles near stormwater drain.', 'https://images.unsplash.com/photo-1605600659873-d808a13e4d2a?w=600', 18.5212, 73.8550, 'Market Road, Near Shop 42, Ward 12', 'high', 'Worker Assigned', 'wrk_1', 'https://images.unsplash.com/photo-1605600659873-d808a13e4d2a?w=600', NULL, '2026-09-04 09:30:00'),
('rep_2', 'WT-2026-00124', 'usr_citizen_2', 'cat_organic', 'Overflowing community composting bin attracting strays and generating foul smell.', 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600', 18.5298, 73.8710, 'Station Bus Stand Plaza, Platform 2 exit', 'critical', 'Resolved', 'wrk_1', 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600', 'https://images.unsplash.com/photo-1528323273322-d81458248d40?w=600', '2026-09-03 14:15:00'),
('rep_3', 'WT-2026-00126', 'usr_citizen_1', 'cat_construction', 'Illegal dumping of concrete debris, tile pieces, and plaster bags on sidewalk.', 'https://images.unsplash.com/photo-1590496793929-36417d3117de?w=600', 18.5350, 73.8420, 'Shivaji Nagar Ring Road, Near Flyover Pillar 14', 'medium', 'Under Verification', NULL, 'https://images.unsplash.com/photo-1590496793929-36417d3117de?w=600', NULL, '2026-09-04 16:45:00');

-- 7. REWARDS
INSERT INTO rewards (id, name, badge_title, points_required, category, description, icon_name) VALUES
('rew_1', 'Green Citizen Badge', 'Level 1 Eco Citizen', 200, 'badge', 'Official certification badge acknowledging active participation in smart waste reporting.', 'Award'),
('rew_2', 'Waste Warrior Badge', 'Certified Waste Warrior', 500, 'badge', 'Silver honor badge for 25+ verified waste classifications and clean city submissions.', 'ShieldCheck'),
('rew_3', 'Clean City Champion', 'Smart City Champion', 1000, 'badge', 'Gold municipality citation with priority invitation to city green governance panels.', 'Crown'),
('rew_4', 'Eco Hero', 'Hall of Fame Eco Hero', 2000, 'badge', 'Diamond badge, annual mayoral certificate, and honorary smart city environmental ambassador status.', 'Sparkles'),
('rew_5', 'Municipal Property Tax Rebate (5%)', '5% Tax Voucher', 800, 'municipal_discount', 'Direct voucher code applicable toward annual municipal property or water tax.', 'Receipt'),
('rew_6', 'Green Metro Transit Pass (1 Month)', 'Free Transit Pass', 600, 'transit_pass', 'Unlimited 30-day electric bus and metro subway travel card.', 'Bus'),
('rew_7', 'City Tree Plantation Certificate', 'Adopt a Sacred Grove Tree', 300, 'plantation', 'Municipal garden committee plants a tagged sapling in your name with GPS tracking.', 'Trees');

-- 8. VIOLATIONS (Illegal Dumping Enforcement)
INSERT INTO violations (id, case_number, reporter_id, vehicle_number, location_address, latitude, longitude, incident_timestamp, ocr_confidence, violation_type, status, penalty_amount, notes) VALUES
('viol_1', 'VIO-2026-0089', 'usr_citizen_1', 'MH12AB1234', 'Market Road Backside, Near Canal Edge', 18.5195, 73.8530, '2026-09-04 06:20:00', 96.4, 'Commercial Bulk Waste Dumping from Light Commercial Vehicle', 'Pending Verification', 2500.00, 'Automatic license plate OCR detected MH12AB1234. High-resolution photographic evidence captured unloading 8 plastic crates of rotten produce into public canal.');

-- 9. VEHICLE RECORDS
INSERT INTO vehicle_records (vehicle_number, owner_name, vehicle_type, registered_rto, restriction_status, total_violations, last_violation_date, notes) VALUES
('MH12AB1234', 'Mahesh Transport & Logistics', 'Tata Ace Commercial Mini Truck', 'Pune Central RTO', 'Warning', 1, '2026-09-04 06:20:00', 'Pending human officer confirmation on canal dumping report.');

-- 10. HOTSPOT DATA
INSERT INTO hotspot_data (id, zone_name, risk_level, complaint_count, predicted_probability, primary_waste_type, recommended_action, latitude, longitude, radius_meters) VALUES
('hot_1', 'Market Road Commercial Hub', 'High', 42, 88.5, 'Plastic & Organic', 'Deploy 2 extra compactor rounds at 11 AM & 8 PM; install CCTV enforcement cam.', 18.5200, 73.8550, 400),
('hot_2', 'Central Railway Station & Bus Stand', 'High', 38, 84.0, 'Single-Use Plastic & Food Wrappers', 'Increase smart solar compacting bins from 4 to 10; daily worker beat.', 18.5290, 73.8740, 500),
('hot_3', 'Shivaji Nagar Metro Transit Line', 'Medium', 19, 58.2, 'Construction Debris & Beverage Cans', 'Night patrolling between 1 AM and 5 AM to curb midnight debris dumping.', 18.5330, 73.8450, 600),
('hot_4', 'Model Colony Green Residential Zone', 'Low', 4, 12.0, 'Garden Leaves', 'Standard alternate day municipal collection schedule sufficient.', 18.5380, 73.8320, 350);
