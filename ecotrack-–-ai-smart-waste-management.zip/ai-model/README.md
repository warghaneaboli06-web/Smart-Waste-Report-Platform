# EcoTrack AI Microservices Architecture

This directory details and defines the standalone Python AI Microservice layer that powers:
1. **YOLO-based Waste Object Detection & Classification** (`ai-model/waste_detection`)
2. **License Plate Detection & OCR Engine** (`ai-model/license_plate`)
3. **Machine Learning Waste Hotspot & Spatial Risk Predictor** (`ai-model/hotspot_prediction`)

## Architecture Overview

```
[ Frontend Client (React) ]
             |  HTTPS
             v
[ Node.js + Express Core Backend ] (server.ts)
             |
             +---> [ Gemini 3.8 Flash Vision API / In-Memory ML Fallback ]
             |
             +---> [ Standalone Python AI FastAPI Microservice : Port 8000 ]
                           |
                           +---> YOLOv8 Waste Classifier
                           +---> PaddleOCR / EasyOCR License Reader
                           +---> Random Forest Hotspot Spatial Predictor
```

## Running the Python Microservice (Optional Production Deployment)

```bash
cd ai-model
pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000
```
