import { Router, Request, Response } from 'express';
import { store } from './store.ts';
import { analyzeWasteImage, ocrLicensePlate, chatWasteAssistant } from './gemini.ts';

export const apiRouter = Router();

// ==========================================
// 1. AUTHENTICATION & USERS
// ==========================================

apiRouter.post('/auth/login', (req: Request, res: Response) => {
  const { email, role } = req.body;
  if (!email) {
    return res.status(400).json({ error: 'Email is required' });
  }

  // Find user by email or by role match for quick demonstration
  let user = store.findUserByEmail(email);
  if (!user && role) {
    user = store.users.find(u => u.role === role);
  }
  if (!user) {
    // If testing a fresh email, auto-create a citizen session
    const namePart = email.split('@')[0];
    const capitalized = namePart.charAt(0).toUpperCase() + namePart.slice(1);
    user = {
      id: `usr_${Date.now()}`,
      name: capitalized,
      email,
      mobile_number: '+91 98000 00000',
      role: (role as any) || 'citizen',
      profile_photo: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
      credit_points: 100,
      green_score: 150,
      account_status: 'active',
      created_at: new Date().toISOString()
    };
    store.users.push(user);
  }

  res.json({
    message: 'Login successful',
    token: `jwt_simulated_${user.id}_${Date.now()}`,
    user
  });
});

apiRouter.post('/auth/register', (req: Request, res: Response) => {
  const { name, email, mobile_number, phone, role, vehicle_number, license_number, profile_photo } = req.body;
  const userPhone = mobile_number || phone || '+91 98765 43210';
  if (!name || !email) {
    return res.status(400).json({ error: 'Name and email are required' });
  }

  const existing = store.findUserByEmail(email);
  if (existing) {
    return res.status(409).json({ error: 'User already exists with this email address' });
  }

  const newUser = {
    id: `usr_${Date.now()}`,
    name,
    email,
    mobile_number: userPhone,
    role: role || 'citizen',
    profile_photo: profile_photo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150',
    vehicle_number: vehicle_number || undefined,
    license_number: license_number || undefined,
    credit_points: 100,
    green_score: 150,
    account_status: 'active' as const,
    created_at: new Date().toISOString()
  };

  store.users.push(newUser);
  res.status(201).json({
    message: 'Registration successful',
    token: `jwt_simulated_${newUser.id}_${Date.now()}`,
    user: newUser
  });
});

apiRouter.get('/users/profile', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr_citizen_1';
  const user = store.findUserById(userId) || store.users[0];
  res.json({ user });
});

apiRouter.put('/users/profile', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || (req.body.id as string) || 'usr_citizen_1';
  const user = store.findUserById(userId);
  if (!user) {
    return res.status(404).json({ error: 'User not found' });
  }

  const { name, mobile_number, vehicle_number, license_number, profile_photo } = req.body;
  if (name) user.name = name;
  if (mobile_number) user.mobile_number = mobile_number;
  if (vehicle_number !== undefined) user.vehicle_number = vehicle_number;
  if (license_number !== undefined) user.license_number = license_number;
  if (profile_photo) user.profile_photo = profile_photo;

  res.json({ message: 'Profile updated successfully', user });
});

// ==========================================
// 2. WASTE INFORMATION & KNOWLEDGE BASE
// ==========================================

apiRouter.get('/waste/categories', (req: Request, res: Response) => {
  res.json({ categories: store.categories });
});

apiRouter.get('/waste/:id', (req: Request, res: Response) => {
  const category = store.categories.find(c => c.id === req.params.id);
  if (!category) {
    return res.status(404).json({ error: 'Category not found' });
  }
  res.json({ category });
});

// ==========================================
// 3. AI WASTE DETECTION SCANNER
// ==========================================

apiRouter.post('/waste/scan', async (req: Request, res: Response) => {
  try {
    const { image, userId, mimeType } = req.body;
    if (!image) {
      return res.status(400).json({ error: 'Image data is required' });
    }

    const analysis = await analyzeWasteImage(image, mimeType || 'image/jpeg');

    // Save scan to store
    const scanRecord = store.addScan({
      userId: userId || 'usr_citizen_1',
      imageUrl: image.startsWith('data:') ? image : `data:${mimeType || 'image/jpeg'};base64,${image}`,
      categoryId: analysis.category_id,
      itemName: analysis.waste_type,
      confidence: analysis.confidence,
      disposal: analysis.disposal_instructions
    });

    const user = store.findUserById(userId || 'usr_citizen_1') || store.users[0];

    res.json({
      scan: scanRecord,
      analysis,
      pointsEarned: 5,
      newCreditPoints: user.credit_points,
      newGreenScore: user.green_score
    });
  } catch (error: any) {
    console.error('Scan error:', error);
    res.status(500).json({ error: error.message || 'Error processing waste scan' });
  }
});

apiRouter.post('/ai/waste-detection', async (req: Request, res: Response) => {
  try {
    const { image, mimeType } = req.body;
    if (!image) return res.status(400).json({ error: 'Image required' });
    const result = await analyzeWasteImage(image, mimeType || 'image/jpeg');
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 4. WASTE REPORTS (CITIZEN COMPLAINTS)
// ==========================================

apiRouter.post('/reports', (req: Request, res: Response) => {
  const { userId, categoryId, description, imageUrl, latitude, longitude, address, priority } = req.body;
  if (!categoryId || !description || !imageUrl || !address) {
    return res.status(400).json({ error: 'All fields (category, description, image, address) are required' });
  }

  const report = store.addReport({
    userId: userId || 'usr_citizen_1',
    categoryId,
    description,
    imageUrl,
    latitude: Number(latitude) || 18.5204,
    longitude: Number(longitude) || 73.8567,
    address,
    priority: priority || 'medium'
  });

  res.status(201).json({
    message: 'Report submitted successfully',
    complaintId: report.complaint_id,
    report
  });
});

apiRouter.get('/reports/my', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr_citizen_1';
  const myReports = store.reports.filter(r => r.user_id === userId);
  res.json({ reports: myReports });
});

apiRouter.get('/reports', (req: Request, res: Response) => {
  res.json({ reports: store.reports });
});

apiRouter.get('/reports/:id', (req: Request, res: Response) => {
  const report = store.reports.find(r => r.id === req.params.id || r.complaint_id === req.params.id);
  if (!report) {
    return res.status(404).json({ error: 'Report not found' });
  }
  res.json({ report });
});

// ==========================================
// 5. ADMIN / MUNICIPALITY DASHBOARD & MANAGEMENT
// ==========================================

apiRouter.get('/admin/dashboard', (req: Request, res: Response) => {
  const totalUsers = store.users.length + 5240;
  const totalScans = store.scans.length + 12450;
  const totalReports = store.reports.length + 2340;
  const pendingReports = store.reports.filter(r => r.status === 'Submitted' || r.status === 'Under Verification').length;
  const inProgressReports = store.reports.filter(r => r.status === 'Worker Assigned' || r.status === 'In Progress').length;
  const resolvedReports = store.reports.filter(r => r.status === 'Resolved').length + 2035;
  const verifiedViolations = store.violations.filter(v => v.status !== 'Pending Verification').length;
  const totalPoints = store.users.reduce((acc, u) => acc + u.credit_points, 45200);

  // Category distribution for charts
  const categoryCounts: Record<string, number> = {
    'Plastic': 42,
    'Organic': 28,
    'Paper & Cardboard': 14,
    'Construction': 8,
    'E-Waste': 5,
    'Hazardous': 3
  };

  // Trend data
  const monthlyReports = [
    { month: 'Apr', reports: 180, resolved: 165 },
    { month: 'May', reports: 220, resolved: 200 },
    { month: 'Jun', reports: 310, resolved: 280 },
    { month: 'Jul', reports: 290, resolved: 260 },
    { month: 'Aug', reports: 380, resolved: 345 },
    { month: 'Sep', reports: 410, resolved: 372 }
  ];

  const areaComplaints = [
    { area: 'Market Road Commercial Hub', count: 54, priority: 'High' },
    { area: 'Railway Station & Bus Stand', count: 48, priority: 'High' },
    { area: 'Shivaji Nagar Transit Corridor', count: 26, priority: 'Medium' },
    { area: 'Hadapsar Industrial Zone', count: 21, priority: 'Medium' },
    { area: 'Model Colony Ward 7', count: 9, priority: 'Low' }
  ];

  res.json({
    kpis: {
      totalUsers,
      totalScans,
      totalReports,
      pendingReports,
      inProgressReports,
      resolvedReports,
      resolutionRate: 87.2,
      verifiedViolations,
      totalPointsIssued: totalPoints
    },
    categoryCounts,
    monthlyReports,
    areaComplaints,
    hotspots: store.hotspots
  });
});

apiRouter.get('/admin/reports', (req: Request, res: Response) => {
  const { status, priority, category, search } = req.query;
  let filtered = [...store.reports];

  if (status && status !== 'all') {
    filtered = filtered.filter(r => r.status.toLowerCase() === (status as string).toLowerCase());
  }
  if (priority && priority !== 'all') {
    filtered = filtered.filter(r => r.priority.toLowerCase() === (priority as string).toLowerCase());
  }
  if (category && category !== 'all') {
    filtered = filtered.filter(r => r.category_id === category || r.category_name.toLowerCase().includes((category as string).toLowerCase()));
  }
  if (search) {
    const q = (search as string).toLowerCase();
    filtered = filtered.filter(r =>
      r.complaint_id.toLowerCase().includes(q) ||
      r.description.toLowerCase().includes(q) ||
      r.address.toLowerCase().includes(q) ||
      r.user_name.toLowerCase().includes(q)
    );
  }

  res.json({ reports: filtered });
});

apiRouter.put('/admin/reports/:id', (req: Request, res: Response) => {
  const { status, note, priority, rejectionReason } = req.body;
  const report = store.reports.find(r => r.id === req.params.id || r.complaint_id === req.params.id);
  if (!report) return res.status(404).json({ error: 'Report not found' });

  if (status) {
    store.updateReportStatus(report.id, status, note, 'Municipal Admin Officer');
  }
  if (priority) {
    report.priority = priority;
  }
  if (rejectionReason) {
    report.rejection_reason = rejectionReason;
  }

  res.json({ message: 'Report updated', report });
});

apiRouter.post('/admin/assign-worker', (req: Request, res: Response) => {
  const { reportId, workerId } = req.body;
  if (!reportId || !workerId) {
    return res.status(400).json({ error: 'Report ID and Worker ID are required' });
  }

  const updated = store.assignWorker(reportId, workerId);
  if (!updated) {
    return res.status(404).json({ error: 'Could not assign worker to report' });
  }

  res.json({ message: 'Worker assigned successfully', report: updated });
});

apiRouter.get('/admin/hotspots', (req: Request, res: Response) => {
  res.json({ hotspots: store.hotspots });
});

// ==========================================
// 6. WORKER DASHBOARD & TASKS
// ==========================================

apiRouter.get('/worker/tasks', (req: Request, res: Response) => {
  const workerReports = store.reports.filter(r =>
    r.status === 'Worker Assigned' || r.status === 'In Progress' || r.status === 'Resolved'
  );

  const tasks = workerReports.map(r => ({
    id: `task_${r.id}`,
    report_id: r.id,
    complaint_id: r.complaint_id,
    category_name: r.category_name,
    priority: r.priority,
    address: r.address,
    latitude: r.latitude,
    longitude: r.longitude,
    description: r.description,
    before_photo_url: r.before_photo_url || r.image_url,
    after_photo_url: r.after_photo_url,
    status: (r.status === 'Worker Assigned' ? 'Assigned' : r.status === 'In Progress' ? 'Cleaning' : 'Completed') as any,
    assigned_at: r.created_at
  }));

  res.json({ tasks });
});

apiRouter.put('/worker/tasks/:id', (req: Request, res: Response) => {
  const { status, note } = req.body;
  const reportId = req.params.id.replace('task_', '');
  const report = store.reports.find(r => r.id === reportId || r.complaint_id === reportId);
  if (!report) return res.status(404).json({ error: 'Task report not found' });

  let newReportStatus = report.status;
  if (status === 'Accepted' || status === 'On the Way' || status === 'Cleaning') {
    newReportStatus = 'In Progress';
  } else if (status === 'Completed' || status === 'Proof Uploaded') {
    newReportStatus = 'Resolved';
  }

  store.updateReportStatus(report.id, newReportStatus, note || `Worker updated task to ${status}`);
  res.json({ message: 'Task updated', report });
});

apiRouter.post('/worker/tasks/:id/proof', (req: Request, res: Response) => {
  const { afterPhotoUrl, notes } = req.body;
  if (!afterPhotoUrl) {
    return res.status(400).json({ error: 'After-cleaning photo is required' });
  }

  const reportId = req.params.id.replace('task_', '');
  const report = store.reports.find(r => r.id === reportId || r.complaint_id === reportId);
  if (!report) return res.status(404).json({ error: 'Report not found' });

  report.after_photo_url = afterPhotoUrl;
  store.updateReportStatus(report.id, 'Resolved', notes || 'Worker uploaded after-cleaning proof. Area cleared.', 'Worker Suresh Kumar');

  // Award citizen the resolved points if not awarded yet
  const citizen = store.findUserById(report.user_id);
  if (citizen) {
    citizen.credit_points += 20;
    citizen.green_score += 20;
  }

  res.json({ message: 'Cleaning proof uploaded and report marked resolved', report });
});

// ==========================================
// 7. CREDIT POINTS, REWARDS & LEADERBOARD
// ==========================================

apiRouter.get('/points', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr_citizen_1';
  const user = store.findUserById(userId) || store.users[0];
  const userTransactions = store.pointTransactions.filter(p => p.user_id === user.id);

  res.json({
    creditPoints: user.credit_points,
    greenScore: user.green_score,
    nextTierTarget: 1000,
    progressPercentage: Math.min(100, Math.round((user.green_score / 1000) * 100)),
    tierName: user.green_score >= 1000 ? 'Clean City Champion' : user.green_score >= 500 ? 'Waste Warrior' : 'Green Citizen',
    transactions: userTransactions,
    rewards: store.rewards
  });
});

apiRouter.post('/points/add', (req: Request, res: Response) => {
  const { userId, amount, activityType, description } = req.body;
  const user = store.findUserById(userId || 'usr_citizen_1') || store.users[0];

  user.credit_points += Number(amount) || 10;
  user.green_score += Number(amount) || 10;

  const transaction = {
    id: `pt_${Date.now()}`,
    user_id: user.id,
    amount: Number(amount) || 10,
    activity_type: activityType || 'bonus',
    description: description || 'Earned Green Points',
    created_at: new Date().toISOString()
  };
  store.pointTransactions.unshift(transaction);

  res.json({ message: 'Points added', user, transaction });
});

apiRouter.post('/points/redeem', (req: Request, res: Response) => {
  const { userId, rewardId } = req.body;
  const user = store.findUserById(userId || 'usr_citizen_1') || store.users[0];
  const reward = store.rewards.find(r => r.id === rewardId);
  if (!reward) return res.status(404).json({ error: 'Reward not found' });

  if (user.credit_points < reward.points_required) {
    return res.status(400).json({ error: `Insufficient points. You need ${reward.points_required} points but have ${user.credit_points}.` });
  }

  user.credit_points -= reward.points_required;
  reward.unlocked = true;

  store.pointTransactions.unshift({
    id: `pt_${Date.now()}`,
    user_id: user.id,
    amount: -reward.points_required,
    activity_type: 'reward_redemption',
    description: `Redeemed ${reward.name}`,
    created_at: new Date().toISOString()
  });

  store.notifications.unshift({
    id: `notif_${Date.now()}`,
    user_id: user.id,
    title: 'Reward Unlocked!',
    message: `You successfully claimed "${reward.name}". Municipal voucher code: ECO-${Math.random().toString(36).substring(2, 8).toUpperCase()}`,
    type: 'points_earned',
    is_read: false,
    created_at: new Date().toISOString()
  });

  res.json({
    message: `Redeemed ${reward.name} successfully!`,
    newBalance: user.credit_points,
    reward
  });
});

apiRouter.get('/points/leaderboard', (req: Request, res: Response) => {
  res.json({ leaderboard: store.leaderboard });
});

// ==========================================
// 8. NOTIFICATIONS
// ==========================================

apiRouter.get('/notifications', (req: Request, res: Response) => {
  const userId = (req.query.userId as string) || 'usr_citizen_1';
  const notifs = store.notifications.filter(n => n.user_id === userId);
  const unreadCount = notifs.filter(n => !n.is_read).length;
  res.json({ notifications: notifs, unreadCount });
});

apiRouter.put('/notifications/:id/read', (req: Request, res: Response) => {
  const notif = store.notifications.find(n => n.id === req.params.id);
  if (notif) notif.is_read = true;
  res.json({ success: true, notif });
});

apiRouter.put('/notifications/read-all', (req: Request, res: Response) => {
  const userId = (req.body.userId as string) || 'usr_citizen_1';
  store.notifications.filter(n => n.user_id === userId).forEach(n => { n.is_read = true; });
  res.json({ success: true, message: 'All notifications marked as read' });
});

// ==========================================
// 9. ILLEGAL DUMPING, OCR & VIOLATIONS
// ==========================================

apiRouter.post('/violations', (req: Request, res: Response) => {
  const { reporterId, vehicleNumber, vehicleImageUrl, wasteImageUrl, locationAddress, latitude, longitude, ocrConfidence, notes } = req.body;
  if (!vehicleNumber || !vehicleImageUrl || !locationAddress) {
    return res.status(400).json({ error: 'Vehicle number, vehicle image, and location address are required' });
  }

  const violation = store.addViolation({
    reporterId: reporterId || 'usr_citizen_1',
    vehicleNumber,
    vehicleImageUrl,
    wasteImageUrl: wasteImageUrl || vehicleImageUrl,
    locationAddress,
    latitude: Number(latitude) || 18.5195,
    longitude: Number(longitude) || 73.8530,
    ocrConfidence: Number(ocrConfidence) || 95.0,
    notes
  });

  res.status(201).json({ message: 'Violation report filed and routed for human verification', violation });
});

apiRouter.get('/violations', (req: Request, res: Response) => {
  res.json({ violations: store.violations });
});

apiRouter.put('/violations/:id/verify', (req: Request, res: Response) => {
  const { action, officerNotes, officerName } = req.body;
  if (!action || !['warning', 'fine', 'restrict', 'clear'].includes(action)) {
    return res.status(400).json({ error: 'Valid action (warning, fine, restrict, clear) is required' });
  }

  const updated = store.verifyViolation(req.params.id, action, officerNotes, officerName);
  if (!updated) {
    return res.status(404).json({ error: 'Violation record not found' });
  }

  res.json({ message: `Violation case updated with action: ${action}`, violation: updated });
});

apiRouter.post('/ai/license-plate', async (req: Request, res: Response) => {
  try {
    const { image, mimeType } = req.body;
    if (!image) return res.status(400).json({ error: 'Image is required for OCR' });
    const result = await ocrLicensePlate(image, mimeType || 'image/jpeg');
    res.json(result);
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

// ==========================================
// 10. AI ASSISTANT CHATBOT & HOTSPOTS
// ==========================================

apiRouter.post('/ai/chat', async (req: Request, res: Response) => {
  try {
    const { messages } = req.body;
    if (!messages || !Array.isArray(messages)) {
      return res.status(400).json({ error: 'Messages array is required' });
    }
    const reply = await chatWasteAssistant(messages);
    res.json({ reply });
  } catch (err: any) {
    res.status(500).json({ error: err.message });
  }
});

apiRouter.post('/ai/hotspot', (req: Request, res: Response) => {
  res.json({
    hotspots: store.hotspots,
    summary: 'Identified 2 high-risk clusters (Market Road and Railway Area) with persistent commercial plastic dumping.'
  });
});

// ==========================================
// 11. NEARBY WASTE CENTERS & BINS
// ==========================================

apiRouter.get('/centers', (req: Request, res: Response) => {
  const { category, type } = req.query;
  let centers = [...store.wasteCenters];

  if (type && type !== 'all') {
    centers = centers.filter(c => c.facility_type.toLowerCase() === (type as string).toLowerCase());
  }
  if (category && category !== 'all') {
    const catStr = (category as string).toLowerCase();
    centers = centers.filter(c => c.accepted_categories.some(cat => cat.toLowerCase().includes(catStr)));
  }

  res.json({ centers });
});
