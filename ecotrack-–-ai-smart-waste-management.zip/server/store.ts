import {
  User,
  WasteCategory,
  WasteReport,
  WorkerTask,
  WasteCenter,
  NotificationItem,
  PointTransaction,
  RewardItem,
  ViolationRecord,
  WasteScanRecord,
  HotspotArea,
  ReportStatus
} from './types.ts';

class MemoryStore {
  public users: User[] = [
    {
      id: 'usr_citizen_1',
      name: 'Priya Sharma',
      email: 'citizen@ecotrack.city',
      mobile_number: '+91 98230 45671',
      role: 'citizen',
      profile_photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&auto=format&fit=crop&q=80',
      vehicle_number: 'MH12AB4589',
      license_number: 'DL-12201900341',
      credit_points: 340,
      green_score: 850,
      account_status: 'active',
      created_at: '2026-01-15T08:00:00.000Z'
    },
    {
      id: 'usr_admin_1',
      name: 'Rajiv Nair',
      email: 'admin@ecotrack.city',
      mobile_number: '+91 98221 00987',
      role: 'admin',
      profile_photo: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&auto=format&fit=crop&q=80',
      vehicle_number: 'MH12GOV001',
      license_number: 'DL-GOV-9981',
      credit_points: 1200,
      green_score: 990,
      account_status: 'active',
      created_at: '2025-10-10T09:00:00.000Z'
    },
    {
      id: 'usr_worker_1',
      name: 'Suresh Kumar',
      email: 'worker@ecotrack.city',
      mobile_number: '+91 94230 55123',
      role: 'worker',
      profile_photo: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=200&auto=format&fit=crop&q=80',
      vehicle_number: 'MH12TRK108',
      license_number: 'DL-COMM-4412',
      credit_points: 650,
      green_score: 920,
      account_status: 'active',
      created_at: '2025-11-01T07:30:00.000Z'
    },
    {
      id: 'usr_enforce_1',
      name: 'Inspector Vikram Deshmukh',
      email: 'enforcement@ecotrack.city',
      mobile_number: '+91 99230 77412',
      role: 'enforcement',
      profile_photo: 'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?w=200&auto=format&fit=crop&q=80',
      vehicle_number: 'MH12POL055',
      license_number: 'DL-POL-8812',
      credit_points: 890,
      green_score: 940,
      account_status: 'active',
      created_at: '2025-12-05T08:15:00.000Z'
    }
  ];

  public categories: WasteCategory[] = [
    {
      id: 'cat_organic',
      name: 'Organic / Wet Waste',
      classification: 'Biodegradable',
      description: 'Kitchen food scraps, vegetable peels, fruit rinds, leftover cooked meals, and garden trimmings.',
      environmental_impact: 'Landfilled food waste releases potent methane gas. Proper composting produces nutrient-rich organic soil.',
      correct_disposal: 'Place in green compost bin. Drain excess gravies and moisture. Never mix with plastic liners or cling wraps.',
      recycling_info: '100% compostable through aerated windrow composting or municipal biomethanation digestors.',
      safety_precautions: 'Cover bins securely to avoid breeding flies, odors, and attracting scavengers.',
      color_code: '#10B981',
      icon_name: 'Apple',
      degradation_period: '2 to 6 weeks',
      points_reward: 10,
      examples: ['Vegetable & fruit peels', 'Cooked rice/dal leftovers', 'Eggshells & tea bags', 'Fallen leaves & garden waste']
    },
    {
      id: 'cat_plastic',
      name: 'Plastic Waste',
      classification: 'Recyclable',
      description: 'PET mineral water bottles, HDPE milk jugs, shampoo bottles, polybags, containers, and packaging films.',
      environmental_impact: 'Plastics take 450+ years to break down, disintegrating into toxic microplastics that enter food chains and oceans.',
      correct_disposal: 'Empty remaining liquids, rinse residues, compress to flatten, and place in dry blue recycling bin.',
      recycling_info: 'Shredded, washed, melted into pellets, and reused to produce textiles, fleece jackets, and new containers.',
      safety_precautions: 'Do not burn plastic! Open incineration emits deadly carcinogenic dioxins and furans.',
      color_code: '#3B82F6',
      icon_name: 'Package',
      degradation_period: '100 to 500 years',
      points_reward: 10,
      examples: ['PET beverage bottles', 'Takeout plastic boxes', 'Detergent containers', 'Polyethylene packaging']
    },
    {
      id: 'cat_paper',
      name: 'Paper & Cardboard',
      classification: 'Recyclable',
      description: 'Newspapers, corrugated delivery boxes, magazines, office documents, envelopes, and paper grocery bags.',
      environmental_impact: 'Recycling 1 ton of paper spares 17 mature trees, 7,000 gallons of water, and 4,000 kilowatt-hours of electricity.',
      correct_disposal: 'Flatten cardboard boxes to save space. Keep completely dry. Put greasy pizza paper in compost.',
      recycling_info: 'Wood pulp fibers can be chemically cleaned and recycled 5 to 7 times into packaging and newsprint.',
      safety_precautions: 'Keep away from damp or greasy items. Wet paper fiber degrades quickly and jams sorting machines.',
      color_code: '#F59E0B',
      icon_name: 'FileText',
      degradation_period: '2 to 5 months',
      points_reward: 10,
      examples: ['Shipping cardboard boxes', 'Newspapers & gazettes', 'Printer sheets & notebooks', 'Paper egg cartons']
    },
    {
      id: 'cat_glass',
      name: 'Glass Waste',
      classification: 'Recyclable',
      description: 'Glass juice bottles, condiment jars, beverage bottles, glass tumblers, and clear broken containers.',
      environmental_impact: 'Glass in landfills never biodegrades, but is 100% infinitely recyclable without any loss in purity or quality.',
      correct_disposal: 'Rinse jars, discard plastic lids, and place in designated glass crate or bin. Handle broken glass with care.',
      recycling_info: 'Crushed into cullet and melted in glass furnaces at lower temperatures, saving 30% industrial furnace energy.',
      safety_precautions: 'Wrap sharp broken pieces in thick newspaper and write "BROKEN GLASS" to protect waste pickers.',
      color_code: '#06B6D4',
      icon_name: 'Wine',
      degradation_period: '1,000,000+ years',
      points_reward: 15,
      examples: ['Clear & amber beverage bottles', 'Jam & pickle jars', 'Perfume bottles', 'Broken window glass pane']
    },
    {
      id: 'cat_metal',
      name: 'Metal & Aluminum Cans',
      classification: 'Recyclable',
      description: 'Aluminum soft drink cans, tin food cans, metal bottle caps, scrap iron bolts, and copper wires.',
      environmental_impact: 'Recycling aluminum consumes 95% less energy than refining virgin bauxite ore, drastically reducing carbon emissions.',
      correct_disposal: 'Rinse out food remains, crush cans flat, and deposit into the dry metal recycling compartment.',
      recycling_info: 'Remelted in electric arc furnaces and endlessly re-rolled into aluminum cans, engine blocks, or beams.',
      safety_precautions: 'Beware of sharp jagged edges on opened food cans. Push lids down before disposing.',
      color_code: '#64748B',
      icon_name: 'Hammer',
      degradation_period: '50 to 200 years',
      points_reward: 15,
      examples: ['Soda & energy drink cans', 'Canned vegetable tins', 'Aluminum foil & trays', 'Metal lids & scrap copper']
    },
    {
      id: 'cat_ewaste',
      name: 'E-Waste (Electronics)',
      classification: 'Special Disposal',
      description: 'Discarded cell phones, laptop chargers, lithium batteries, motherboards, headphones, and printers.',
      environmental_impact: 'Contains valuable precious metals (gold, palladium) along with hazardous lead, cadmium, and mercury that seep into ground water.',
      correct_disposal: 'Never discard in household trash. Drop off at certified municipal E-Waste Drop Boxes or buyback kiosks.',
      recycling_info: 'Undergoes dismantling, circuit extraction, hydrometallurgical leaching, and environmentally safe plastic recovery.',
      safety_precautions: 'Never pierce or smash lithium-ion batteries. Damaged cells can ignite spontaneous chemical fires.',
      color_code: '#8B5CF6',
      icon_name: 'Cpu',
      degradation_period: 'Non-biodegradable',
      points_reward: 25,
      examples: ['Lithium phone batteries', 'Defunct mobile handsets', 'Charger cables & adapters', 'Computer circuit boards']
    },
    {
      id: 'cat_hazardous',
      name: 'Hazardous Waste',
      classification: 'Hazardous',
      description: 'Pesticide bottles, leftover oil-based paints, thinners, household chemicals, drain cleaners, and car motor oil.',
      environmental_impact: 'Extremely toxic to humans, aquatic ecosystems, and municipal wastewater treatment bacteria.',
      correct_disposal: 'Retain in original containers with warning labels. Deliver strictly to specialized municipal Hazardous Waste Depots.',
      recycling_info: 'Neutralized chemically, incinerated at ultra-high temperatures in certified facilities, or secured in engineered pits.',
      safety_precautions: 'Wear rubber gloves and eye protection. Never mix chemicals together as toxic gas can be generated.',
      color_code: '#EF4444',
      icon_name: 'AlertTriangle',
      degradation_period: 'Non-biodegradable',
      points_reward: 30,
      examples: ['Chemical weedkiller bottles', 'Synthetic paint tins & turpentine', 'Motor engine lubricants', 'Bleach & strong drain acids']
    },
    {
      id: 'cat_construction',
      name: 'Construction & Demolition (C&D)',
      classification: 'Special Disposal',
      description: 'Concrete rubble, broken ceramic tiles, masonry bricks, cured plaster, mortar, and gypsum drywall.',
      environmental_impact: 'Chokes storm drainage culverts, creates heavy particulate matter (PM2.5/PM10), and causes soil compaction.',
      correct_disposal: 'Do not dump on roadsides. Book municipal C&D pickup service or transport directly to designated aggregate plants.',
      recycling_info: 'Crushed and sieved into recycled sand, sub-base gravel for asphalt roads, and manufactured interlocking paver tiles.',
      safety_precautions: 'Wear an N95 dust mask and heavy duty work boots during handling to prevent silica inhalation.',
      color_code: '#78716C',
      icon_name: 'HardHat',
      degradation_period: 'Non-biodegradable',
      points_reward: 20,
      examples: ['Concrete lumps & masonry bricks', 'Ceramic floor tile pieces', 'Hardened cement sacks', 'Plaster & drywall offcuts']
    },
    {
      id: 'cat_biomedical',
      name: 'Biomedical & Sanitary Waste',
      classification: 'Special Disposal',
      description: 'Sanitary pads, disposable diapers, medical face masks, surgical gauze, bandages, and insulin syringes.',
      environmental_impact: 'Carries active bloodborne pathogens, viruses, and bacteria; threatens informal ragpickers and animal safety.',
      correct_disposal: 'Wrap securely in newspapers marked with a visible red cross, or seal in designated municipal yellow sanitary pouch.',
      recycling_info: 'Treated via high-pressure autoclave sterilization and double-chamber biomedical incinerators.',
      safety_precautions: 'Never flush sanitary products down toilets—they expand and cause catastrophic sewer pipeline blockage.',
      color_code: '#EC4899',
      icon_name: 'ShieldAlert',
      degradation_period: '25 to 500 years',
      points_reward: 20,
      examples: ['Sanitary napkins & tampons', 'Baby & adult diapers', 'Face masks & wound bandages', 'Capped disposable syringes']
    },
    {
      id: 'cat_general',
      name: 'General / Non-Recyclable Waste',
      classification: 'Non-Recyclable',
      description: 'Multi-layer laminated chip packets, carbon papers, cigarette butts, vacuum dust bags, and broken ceramics.',
      environmental_impact: 'Fills up municipal landfill cells and takes centuries to degrade without energetic recovery.',
      correct_disposal: 'Only discard into the black General Waste bin when items genuinely cannot be recycled, repaired, or composted.',
      recycling_info: 'Directed toward municipal Waste-to-Energy (WtE) incinerator plants to produce electricity and heat.',
      safety_precautions: 'Ensure no hazardous chemicals or lithium batteries are mistakenly mixed into general trash.',
      color_code: '#94A3B8',
      icon_name: 'Trash',
      degradation_period: 'Indefinite',
      points_reward: 5,
      examples: ['Multi-layer aluminized snack wrappers', 'Thermal cash register receipts', 'Ceramic mugs & porcelain shards', 'Dirty vacuum cleaner bag waste']
    }
  ];

  public reports: WasteReport[] = [
    {
      id: 'rep_1',
      complaint_id: 'WT-2026-00125',
      user_id: 'usr_citizen_1',
      user_name: 'Priya Sharma',
      user_email: 'citizen@ecotrack.city',
      category_id: 'cat_plastic',
      category_name: 'Plastic Waste',
      description: 'Heavy pile of discarded plastic packaging and pet bottles near stormwater drain on Market Road.',
      image_url: 'https://images.unsplash.com/photo-1605600659873-d808a13e4d2a?w=700&auto=format&fit=crop&q=80',
      latitude: 18.5212,
      longitude: 73.8550,
      address: 'Market Road, Near Shop 42, Ward 12, Central Zone',
      priority: 'high',
      status: 'Worker Assigned',
      assigned_worker_id: 'usr_worker_1',
      assigned_worker_name: 'Suresh Kumar',
      before_photo_url: 'https://images.unsplash.com/photo-1605600659873-d808a13e4d2a?w=700&auto=format&fit=crop&q=80',
      after_photo_url: undefined,
      created_at: '2026-09-04T09:30:00.000Z',
      timeline: [
        { status: 'Submitted', timestamp: '2026-09-04T09:30:00.000Z', note: 'Report submitted by Priya Sharma with GPS coordinates.' },
        { status: 'Under Verification', timestamp: '2026-09-04T09:45:00.000Z', note: 'AI image analysis verified high concentration of plastic debris.' },
        { status: 'Verified', timestamp: '2026-09-04T10:15:00.000Z', note: 'Verified by Municipal Officer Rajiv Nair.' },
        { status: 'Worker Assigned', timestamp: '2026-09-04T10:30:00.000Z', note: 'Worker Suresh Kumar dispatched with Compactor Truck MH12TRK108.' }
      ]
    },
    {
      id: 'rep_2',
      complaint_id: 'WT-2026-00124',
      user_id: 'usr_citizen_1',
      user_name: 'Priya Sharma',
      user_email: 'citizen@ecotrack.city',
      category_id: 'cat_organic',
      category_name: 'Organic / Wet Waste',
      description: 'Overflowing community composting bin near railway station exit causing odor and flies.',
      image_url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=700&auto=format&fit=crop&q=80',
      latitude: 18.5298,
      longitude: 73.8710,
      address: 'Station Bus Stand Plaza, Platform 2 Exit Road',
      priority: 'critical',
      status: 'Resolved',
      assigned_worker_id: 'usr_worker_1',
      assigned_worker_name: 'Suresh Kumar',
      before_photo_url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=700&auto=format&fit=crop&q=80',
      after_photo_url: 'https://images.unsplash.com/photo-1528323273322-d81458248d40?w=700&auto=format&fit=crop&q=80',
      verified_by: 'Rajiv Nair',
      verified_at: '2026-09-03T15:00:00.000Z',
      resolved_at: '2026-09-03T17:45:00.000Z',
      created_at: '2026-09-03T14:15:00.000Z',
      timeline: [
        { status: 'Submitted', timestamp: '2026-09-03T14:15:00.000Z', note: 'Complaint logged by citizen with geo-tagged photo.' },
        { status: 'Verified', timestamp: '2026-09-03T14:30:00.000Z', note: 'Escalated to critical priority due to transit traffic density.' },
        { status: 'Worker Assigned', timestamp: '2026-09-03T14:45:00.000Z', note: 'Worker Suresh Kumar accepted the assignment.' },
        { status: 'In Progress', timestamp: '2026-09-03T15:30:00.000Z', note: 'Clean-up operations underway at station plaza.' },
        { status: 'Resolved', timestamp: '2026-09-03T17:45:00.000Z', note: 'Cleaned area verified by admin. +20 Green Points issued to citizen.' }
      ]
    },
    {
      id: 'rep_3',
      complaint_id: 'WT-2026-00126',
      user_id: 'usr_citizen_1',
      user_name: 'Priya Sharma',
      user_email: 'citizen@ecotrack.city',
      category_id: 'cat_construction',
      category_name: 'Construction & Demolition',
      description: 'Illegal midnight dumping of concrete debris, tile fragments, and cement sacks on the sidewalk.',
      image_url: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?w=700&auto=format&fit=crop&q=80',
      latitude: 18.5350,
      longitude: 73.8420,
      address: 'Shivaji Nagar Ring Road, Near Flyover Pillar 14',
      priority: 'medium',
      status: 'Under Verification',
      before_photo_url: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?w=700&auto=format&fit=crop&q=80',
      created_at: '2026-09-04T16:45:00.000Z',
      timeline: [
        { status: 'Submitted', timestamp: '2026-09-04T16:45:00.000Z', note: 'Report submitted. Pending field inspection.' },
        { status: 'Under Verification', timestamp: '2026-09-04T17:00:00.000Z', note: 'Assigned to Ward 14 Sanitation Inspector for cross-validation.' }
      ]
    },
    {
      id: 'rep_4',
      complaint_id: 'WT-2026-00127',
      user_id: 'usr_citizen_1',
      user_name: 'Rahul Verma',
      user_email: 'rahul.v@ecotrack.city',
      category_id: 'cat_ewaste',
      category_name: 'E-Waste (Electronics)',
      description: 'Discarded computer monitors and cables left open near community garden.',
      image_url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=700&auto=format&fit=crop&q=80',
      latitude: 18.5140,
      longitude: 73.8610,
      address: 'Near Gandhi Park West Gate, Sector 3',
      priority: 'high',
      status: 'Submitted',
      before_photo_url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?w=700&auto=format&fit=crop&q=80',
      created_at: '2026-09-04T20:10:00.000Z',
      timeline: [
        { status: 'Submitted', timestamp: '2026-09-04T20:10:00.000Z', note: 'Complaint received and queued for dispatch.' }
      ]
    }
  ];

  public wasteCenters: WasteCenter[] = [
    {
      id: 'wc_1',
      name: 'Central Eco-Recycling Hub',
      facility_type: 'Recycling Center',
      address: 'Sector 4, Near Gandhi Smriti Circle, Pune Central',
      latitude: 18.5245,
      longitude: 73.8580,
      contact_phone: '+91 20 2553 4100',
      operating_hours: '07:00 AM - 08:00 PM (All 7 Days)',
      accepted_categories: ['Plastic', 'Paper', 'Glass', 'Metal'],
      capacity_status: 'normal',
      distance_km: 1.2
    },
    {
      id: 'wc_2',
      name: 'Metro Electronic Waste Safe Drop',
      facility_type: 'E-Waste Center',
      address: 'Old Railway Workshop Road, Station Area',
      latitude: 18.5292,
      longitude: 73.8741,
      contact_phone: '+91 20 2612 8890',
      operating_hours: '09:00 AM - 05:00 PM (Mon-Sat)',
      accepted_categories: ['E-Waste', 'Lithium Batteries', 'Computers', 'Smartphones'],
      capacity_status: 'normal',
      distance_km: 2.5
    },
    {
      id: 'wc_3',
      name: 'GreenLeaf Wet Waste Composting Unit',
      facility_type: 'Wet Waste Composting Facility',
      address: 'Agronomy Campus, University Road, Gate 3',
      latitude: 18.5390,
      longitude: 73.8290,
      contact_phone: '+91 20 2569 1120',
      operating_hours: '06:00 AM - 06:00 PM (Daily)',
      accepted_categories: ['Organic / Wet Waste', 'Garden Foliage', 'Food Scraps'],
      capacity_status: 'normal',
      distance_km: 3.8
    },
    {
      id: 'wc_4',
      name: 'Municipal Hazardous Materials Depot',
      facility_type: 'Hazardous Waste Depot',
      address: 'MIDC Industrial Sector Gate 2, Hadapsar',
      latitude: 18.5020,
      longitude: 73.9280,
      contact_phone: '+91 20 2687 4300',
      operating_hours: '10:00 AM - 04:00 PM (Tue, Thu, Sat)',
      accepted_categories: ['Hazardous Waste', 'Solvents', 'Paints', 'Biomedical'],
      capacity_status: 'normal',
      distance_km: 6.4
    },
    {
      id: 'wc_5',
      name: 'Smart Public Solar Bin #14',
      facility_type: 'Smart Public Bin',
      address: 'Main Vegetable Market Outer Gate, Market Road',
      latitude: 18.5180,
      longitude: 73.8540,
      contact_phone: '+91 20 2553 4101',
      operating_hours: '24 Hours Open',
      accepted_categories: ['Plastic Bottles', 'Aluminum Cans', 'Dry Paper'],
      capacity_status: 'high',
      distance_km: 0.6
    },
    {
      id: 'wc_6',
      name: 'Community Dry Waste Sorting Kiosk',
      facility_type: 'Dry Waste Collection Point',
      address: 'Deccan Gymkhana Bus Terminal Corner',
      latitude: 18.5160,
      longitude: 73.8410,
      contact_phone: '+91 20 2553 9922',
      operating_hours: '08:00 AM - 07:00 PM (Daily)',
      accepted_categories: ['Paper', 'Cardboard', 'Plastic Milk Bags'],
      capacity_status: 'normal',
      distance_km: 1.9
    }
  ];

  public notifications: NotificationItem[] = [
    {
      id: 'notif_1',
      user_id: 'usr_citizen_1',
      title: 'Waste Report Updated',
      message: 'Your report WT-2026-00125 on Market Road has been assigned to worker Suresh Kumar.',
      type: 'report_status',
      related_id: 'rep_1',
      is_read: false,
      created_at: '2026-09-04T10:30:00.000Z'
    },
    {
      id: 'notif_2',
      user_id: 'usr_citizen_1',
      title: 'Green Points Credited! (+20)',
      message: 'You earned 20 Green Points for submitting verified report WT-2026-00124.',
      type: 'points_earned',
      related_id: 'rep_2',
      is_read: false,
      created_at: '2026-09-03T17:46:00.000Z'
    },
    {
      id: 'notif_3',
      user_id: 'usr_citizen_1',
      title: 'Issue Successfully Resolved',
      message: 'Your reported garbage issue WT-2026-00124 at Station Bus Stand has been fully cleaned and closed.',
      type: 'report_status',
      related_id: 'rep_2',
      is_read: true,
      created_at: '2026-09-03T17:45:00.000Z'
    },
    {
      id: 'notif_4',
      user_id: 'usr_citizen_1',
      title: 'Nearby E-Waste Drop Box Available',
      message: 'A specialized electronic waste collection center is active within 2.5km of your location.',
      type: 'general_announcement',
      related_id: 'wc_2',
      is_read: true,
      created_at: '2026-09-02T11:00:00.000Z'
    },
    {
      id: 'notif_5',
      user_id: 'usr_citizen_1',
      title: 'Violation Verification in Progress',
      message: 'For your submitted illegal dumping report VIO-2026-0089, enforcement officer verification is pending.',
      type: 'violation_alert',
      related_id: 'viol_1',
      is_read: false,
      created_at: '2026-09-04T07:00:00.000Z'
    }
  ];

  public pointTransactions: PointTransaction[] = [
    {
      id: 'pt_1',
      user_id: 'usr_citizen_1',
      amount: 20,
      activity_type: 'valid_report',
      description: 'Approved waste complaint WT-2026-00124 resolution',
      reference_id: 'rep_2',
      created_at: '2026-09-03T17:46:00.000Z'
    },
    {
      id: 'pt_2',
      user_id: 'usr_citizen_1',
      amount: 5,
      activity_type: 'waste_scan',
      description: 'AI Waste Scanner scan of PET Plastic Bottle',
      created_at: '2026-09-03T10:12:00.000Z'
    },
    {
      id: 'pt_3',
      user_id: 'usr_citizen_1',
      amount: 10,
      activity_type: 'correct_disposal',
      description: 'Confirmed blue bin disposal at Central Eco-Recycling Hub',
      created_at: '2026-09-02T15:20:00.000Z'
    },
    {
      id: 'pt_4',
      user_id: 'usr_citizen_1',
      amount: 30,
      activity_type: 'verified_illegal_dumping_report',
      description: 'Photographic evidence submission for illegal dumping incident',
      reference_id: 'viol_1',
      created_at: '2026-09-04T06:30:00.000Z'
    }
  ];

  public rewards: RewardItem[] = [
    {
      id: 'rew_1',
      name: 'Green Citizen Badge',
      badge_title: 'Level 1 Eco Citizen',
      points_required: 200,
      category: 'badge',
      description: 'Official digital civic badge acknowledging active participation in smart waste reporting.',
      icon_name: 'Award',
      unlocked: true
    },
    {
      id: 'rew_2',
      name: 'Waste Warrior Badge',
      badge_title: 'Certified Waste Warrior',
      points_required: 500,
      category: 'badge',
      description: 'Silver honor credential for 25+ verified waste classifications and clean city submissions.',
      icon_name: 'ShieldCheck',
      unlocked: false
    },
    {
      id: 'rew_3',
      name: 'Clean City Champion',
      badge_title: 'Smart City Champion',
      points_required: 1000,
      category: 'badge',
      description: 'Gold municipality citation with priority invitation to city green governance roundtables.',
      icon_name: 'Crown',
      unlocked: false
    },
    {
      id: 'rew_4',
      name: 'Eco Hero Hall of Fame',
      badge_title: 'Diamond Eco Hero',
      points_required: 2000,
      category: 'badge',
      description: 'Permanent mayoral digital honor, city ambassador status, and priority civic recognition.',
      icon_name: 'Sparkles',
      unlocked: false
    },
    {
      id: 'rew_5',
      name: 'Municipal Property Tax Rebate (5%)',
      badge_title: '5% Tax Voucher',
      points_required: 800,
      category: 'municipal_discount',
      description: 'Direct voucher applied toward your annual municipal solid waste management or property tax bill.',
      icon_name: 'Receipt',
      unlocked: false
    },
    {
      id: 'rew_6',
      name: 'Green Metro Transit Pass (1 Month)',
      badge_title: 'Free Transit Pass',
      points_required: 600,
      category: 'transit_pass',
      description: 'Unlimited 30-day electric bus and metro rail transit pass across all municipal zones.',
      icon_name: 'Bus',
      unlocked: false
    },
    {
      id: 'rew_7',
      name: 'Adopt & Plant City Tree',
      badge_title: 'City Tree Plantation',
      points_required: 300,
      category: 'plantation',
      description: 'The municipal parks department plants a geo-tagged native sapling in your name with photo updates.',
      icon_name: 'Trees',
      unlocked: true
    }
  ];

  public violations: ViolationRecord[] = [
    {
      id: 'viol_1',
      case_number: 'VIO-2026-0089',
      reporter_id: 'usr_citizen_1',
      reporter_name: 'Priya Sharma',
      vehicle_number: 'MH12AB1234',
      vehicle_image_url: 'https://images.unsplash.com/photo-1557053910-d9eadeed1c58?w=700&auto=format&fit=crop&q=80',
      waste_image_url: 'https://images.unsplash.com/photo-1605600659873-d808a13e4d2a?w=700&auto=format&fit=crop&q=80',
      location_address: 'Market Road Backside, Near Canal Edge, Ward 12',
      latitude: 18.5195,
      longitude: 73.8530,
      incident_timestamp: '2026-09-04T06:20:00.000Z',
      ocr_confidence: 96.4,
      violation_type: 'Commercial Bulk Waste Dumping from Light Commercial Vehicle',
      status: 'Pending Verification',
      restriction_status: 'Warning',
      penalty_amount: 2500,
      notes: 'Automatic plate OCR extracted MH12AB1234 from high-resolution tailgate photo. Verified unloading of 8 plastic crates of market refuse into open canal bed.',
      created_at: '2026-09-04T06:30:00.000Z'
    },
    {
      id: 'viol_2',
      case_number: 'VIO-2026-0088',
      reporter_id: 'usr_citizen_2',
      reporter_name: 'Rahul Verma',
      vehicle_number: 'MH14CD5521',
      vehicle_image_url: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?w=700&auto=format&fit=crop&q=80',
      waste_image_url: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?w=700&auto=format&fit=crop&q=80',
      location_address: 'Shivaji Nagar Underpass Service Road',
      latitude: 18.5310,
      longitude: 73.8460,
      incident_timestamp: '2026-09-03T23:15:00.000Z',
      ocr_confidence: 92.1,
      violation_type: 'Illegal Construction Debris Offloading',
      status: 'Verified Violation',
      restriction_status: 'Fine Pending',
      penalty_amount: 5000,
      verified_by: 'Inspector Vikram Deshmukh',
      notes: 'Enforcement verified evidence. Driver dumped 2 cubic meters of concrete rubble on pedestrian pathway.',
      created_at: '2026-09-03T23:40:00.000Z'
    }
  ];

  public scans: WasteScanRecord[] = [
    {
      id: 'scan_1',
      user_id: 'usr_citizen_1',
      image_url: 'https://images.unsplash.com/photo-1598880940371-c756e015fea1?w=500&auto=format&fit=crop&q=80',
      detected_category_id: 'cat_plastic',
      detected_item_name: 'Polyethylene Terephthalate (PET) Beverage Bottle',
      confidence_score: 94.2,
      disposal_instructions: 'Rinse cap and bottle. Crush flat and drop into Blue Dry Recyclable Bin.',
      points_awarded: 5,
      scan_timestamp: '2026-09-04T11:20:00.000Z'
    },
    {
      id: 'scan_2',
      user_id: 'usr_citizen_1',
      image_url: 'https://images.unsplash.com/photo-1583321500900-82807e458f3c?w=500&auto=format&fit=crop&q=80',
      detected_category_id: 'cat_paper',
      detected_item_name: 'Corrugated Shipping Delivery Carton',
      confidence_score: 97.8,
      disposal_instructions: 'Remove adhesive packing tapes. Flatten cardboard and keep dry in Paper Recycling collection.',
      points_awarded: 5,
      scan_timestamp: '2026-09-03T15:40:00.000Z'
    }
  ];

  public hotspots: HotspotArea[] = [
    {
      id: 'hot_1',
      zone_name: 'Market Road Commercial Hub',
      risk_level: 'High',
      complaint_count: 42,
      predicted_probability: 88.5,
      primary_waste_type: 'Plastic Packaging & Organic Food Stalls',
      recommended_action: 'Increase compactor truck frequency to twice daily (11 AM & 8 PM); deploy dedicated litter marshals.',
      latitude: 18.5200,
      longitude: 73.8550,
      radius_meters: 400
    },
    {
      id: 'hot_2',
      zone_name: 'Central Railway Station & Intercity Bus Stand',
      risk_level: 'High',
      complaint_count: 38,
      predicted_probability: 84.0,
      primary_waste_type: 'Single-Use Plastic Bottles & Food Packaging',
      recommended_action: 'Install 6 additional solar-powered smart compacting bins and automated reverse-vending bottle kiosks.',
      latitude: 18.5290,
      longitude: 73.8740,
      radius_meters: 500
    },
    {
      id: 'hot_3',
      zone_name: 'Shivaji Nagar Metro Transit Line',
      risk_level: 'Medium',
      complaint_count: 19,
      predicted_probability: 58.2,
      primary_waste_type: 'Construction Debris & Beverage Cans',
      recommended_action: 'Implement overnight CCTV monitoring from 1 AM to 5 AM to prevent clandestine truck dumping.',
      latitude: 18.5330,
      longitude: 73.8450,
      radius_meters: 600
    },
    {
      id: 'hot_4',
      zone_name: 'Model Colony Green Residential Zone',
      risk_level: 'Low',
      complaint_count: 4,
      predicted_probability: 12.0,
      primary_waste_type: 'Pruned Garden Branches & Dry Foliage',
      recommended_action: 'Standard alternate-day door-to-door green waste collection is performing optimally.',
      latitude: 18.5380,
      longitude: 73.8320,
      radius_meters: 350
    }
  ];

  public leaderboard = [
    { rank: 1, name: 'Rahul Verma', points: 2450, green_score: 1420, scans: 48, resolved_reports: 18, badge: 'Eco Hero' },
    { rank: 2, name: 'Amina Khan', points: 2120, green_score: 1310, scans: 41, resolved_reports: 14, badge: 'Clean City Champion' },
    { rank: 3, name: 'Priya Sharma (You)', points: 1980, green_score: 850, scans: 34, resolved_reports: 9, badge: 'Waste Warrior' },
    { rank: 4, name: 'Devendra Patil', points: 1640, green_score: 790, scans: 29, resolved_reports: 8, badge: 'Green Citizen' },
    { rank: 5, name: 'Neha Joshi', points: 1420, green_score: 710, scans: 22, resolved_reports: 6, badge: 'Green Citizen' },
    { rank: 6, name: 'Aditya Kulkarni', points: 1180, green_score: 640, scans: 19, resolved_reports: 4, badge: 'Green Citizen' }
  ];

  // Helper Methods
  public findUserByEmail(email: string): User | undefined {
    return this.users.find(u => u.email.toLowerCase() === email.toLowerCase());
  }

  public findUserById(id: string): User | undefined {
    return this.users.find(u => u.id === id);
  }

  public addReport(data: {
    userId: string;
    categoryId: string;
    description: string;
    imageUrl: string;
    latitude: number;
    longitude: number;
    address: string;
    priority?: 'low' | 'medium' | 'high' | 'critical';
  }): WasteReport {
    const user = this.findUserById(data.userId) || this.users[0];
    const category = this.categories.find(c => c.id === data.categoryId) || this.categories[1];
    const complaintNumber = `WT-2026-${String(this.reports.length + 128).padStart(5, '0')}`;

    const newReport: WasteReport = {
      id: `rep_${Date.now()}`,
      complaint_id: complaintNumber,
      user_id: user.id,
      user_name: user.name,
      user_email: user.email,
      category_id: category.id,
      category_name: category.name,
      description: data.description,
      image_url: data.imageUrl,
      latitude: data.latitude,
      longitude: data.longitude,
      address: data.address,
      priority: data.priority || 'medium',
      status: 'Submitted',
      before_photo_url: data.imageUrl,
      created_at: new Date().toISOString(),
      timeline: [
        {
          status: 'Submitted',
          timestamp: new Date().toISOString(),
          note: `Complaint filed with geo-coordinates (${data.latitude.toFixed(4)}, ${data.longitude.toFixed(4)})`
        }
      ]
    };

    this.reports.unshift(newReport);

    // Award +20 points for filing a valid report
    user.credit_points += 20;
    user.green_score += 15;
    this.pointTransactions.unshift({
      id: `pt_${Date.now()}`,
      user_id: user.id,
      amount: 20,
      activity_type: 'valid_report',
      description: `Submitted waste complaint ${complaintNumber}`,
      reference_id: newReport.id,
      created_at: new Date().toISOString()
    });

    this.notifications.unshift({
      id: `notif_${Date.now()}`,
      user_id: user.id,
      title: 'Waste Report Submitted',
      message: `Your complaint ${complaintNumber} has been logged. Our municipal inspection team will verify it shortly.`,
      type: 'report_status',
      related_id: newReport.id,
      is_read: false,
      created_at: new Date().toISOString()
    });

    return newReport;
  }

  public updateReportStatus(reportId: string, status: ReportStatus, note?: string, verifiedBy?: string): WasteReport | undefined {
    const report = this.reports.find(r => r.id === reportId || r.complaint_id === reportId);
    if (!report) return undefined;

    report.status = status;
    if (verifiedBy) {
      report.verified_by = verifiedBy;
      report.verified_at = new Date().toISOString();
    }
    if (status === 'Resolved') {
      report.resolved_at = new Date().toISOString();
    }

    report.timeline.push({
      status,
      timestamp: new Date().toISOString(),
      note: note || `Status transitioned to ${status}`
    });

    // Notify citizen
    this.notifications.unshift({
      id: `notif_${Date.now()}`,
      user_id: report.user_id,
      title: `Report ${report.complaint_id}: ${status}`,
      message: note || `Your waste complaint status is now ${status}.`,
      type: 'report_status',
      related_id: report.id,
      is_read: false,
      created_at: new Date().toISOString()
    });

    return report;
  }

  public assignWorker(reportId: string, workerId: string): WasteReport | undefined {
    const report = this.reports.find(r => r.id === reportId || r.complaint_id === reportId);
    const worker = this.users.find(u => u.id === workerId && u.role === 'worker') || this.users.find(u => u.role === 'worker');
    if (!report || !worker) return undefined;

    report.assigned_worker_id = worker.id;
    report.assigned_worker_name = worker.name;
    report.status = 'Worker Assigned';

    report.timeline.push({
      status: 'Worker Assigned',
      timestamp: new Date().toISOString(),
      note: `Assigned to Sanitation Worker ${worker.name} (${worker.vehicle_number || 'Unit'})`
    });

    this.notifications.unshift({
      id: `notif_${Date.now()}`,
      user_id: report.user_id,
      title: `Worker Assigned for ${report.complaint_id}`,
      message: `Field technician ${worker.name} has been dispatched to clean ${report.address}.`,
      type: 'worker_dispatch',
      related_id: report.id,
      is_read: false,
      created_at: new Date().toISOString()
    });

    return report;
  }

  public addScan(data: {
    userId: string;
    imageUrl: string;
    categoryId: string;
    itemName: string;
    confidence: number;
    disposal: string;
  }): WasteScanRecord {
    const user = this.findUserById(data.userId) || this.users[0];
    const newScan: WasteScanRecord = {
      id: `scan_${Date.now()}`,
      user_id: user.id,
      image_url: data.imageUrl,
      detected_category_id: data.categoryId,
      detected_item_name: data.itemName,
      confidence_score: data.confidence,
      disposal_instructions: data.disposal,
      points_awarded: 5,
      scan_timestamp: new Date().toISOString()
    };

    this.scans.unshift(newScan);
    user.credit_points += 5;
    user.green_score += 5;

    this.pointTransactions.unshift({
      id: `pt_${Date.now()}`,
      user_id: user.id,
      amount: 5,
      activity_type: 'waste_scan',
      description: `Scanned and identified ${data.itemName}`,
      reference_id: newScan.id,
      created_at: new Date().toISOString()
    });

    return newScan;
  }

  public addViolation(data: {
    reporterId: string;
    vehicleNumber: string;
    vehicleImageUrl: string;
    wasteImageUrl: string;
    locationAddress: string;
    latitude: number;
    longitude: number;
    ocrConfidence: number;
    violationType?: string;
    notes?: string;
  }): ViolationRecord {
    const reporter = this.findUserById(data.reporterId) || this.users[0];
    const caseNum = `VIO-2026-${String(this.violations.length + 90).padStart(4, '0')}`;

    const newViolation: ViolationRecord = {
      id: `viol_${Date.now()}`,
      case_number: caseNum,
      reporter_id: reporter.id,
      reporter_name: reporter.name,
      vehicle_number: data.vehicleNumber.toUpperCase(),
      vehicle_image_url: data.vehicleImageUrl,
      waste_image_url: data.wasteImageUrl,
      location_address: data.locationAddress,
      latitude: data.latitude,
      longitude: data.longitude,
      incident_timestamp: new Date().toISOString(),
      ocr_confidence: data.ocrConfidence,
      violation_type: data.violationType || 'Illegal Solid Waste Dumping in Public Zone',
      status: 'Pending Verification',
      restriction_status: 'Warning',
      penalty_amount: 2500,
      notes: data.notes || `AI Plate OCR extracted ${data.vehicleNumber}. Awaiting enforcement officer review.`,
      created_at: new Date().toISOString()
    };

    this.violations.unshift(newViolation);

    // Reward citizen with +30 green points for reporting dumping
    reporter.credit_points += 30;
    reporter.green_score += 25;
    this.pointTransactions.unshift({
      id: `pt_${Date.now()}`,
      user_id: reporter.id,
      amount: 30,
      activity_type: 'verified_illegal_dumping_report',
      description: `Reported illegal dumping case ${caseNum}`,
      reference_id: newViolation.id,
      created_at: new Date().toISOString()
    });

    this.notifications.unshift({
      id: `notif_${Date.now()}`,
      user_id: reporter.id,
      title: `Illegal Dumping Case ${caseNum} Logged`,
      message: `Evidence with vehicle plate ${data.vehicleNumber} has been received and routed to the municipal enforcement unit.`,
      type: 'violation_alert',
      related_id: newViolation.id,
      is_read: false,
      created_at: new Date().toISOString()
    });

    return newViolation;
  }

  public verifyViolation(violationId: string, action: 'warning' | 'fine' | 'restrict' | 'clear', officerNotes?: string, officerName?: string): ViolationRecord | undefined {
    const v = this.violations.find(viol => viol.id === violationId || viol.case_number === violationId);
    if (!v) return undefined;

    if (action === 'warning') {
      v.status = 'Warning Issued';
      v.restriction_status = 'Warning';
    } else if (action === 'fine') {
      v.status = 'Fine Levied';
      v.restriction_status = 'Fine Pending';
      v.penalty_amount = 3500;
    } else if (action === 'restrict') {
      v.status = 'Restriction Applied';
      v.restriction_status = 'Temporarily Restricted';
      v.penalty_amount = 5000;
    } else if (action === 'clear') {
      v.status = 'Dismissed';
      v.restriction_status = 'Cleared';
      v.penalty_amount = 0;
    }

    v.verified_by = officerName || 'Inspector Vikram Deshmukh';
    if (officerNotes) {
      v.notes = `${v.notes || ''} [Officer Action: ${action.toUpperCase()}] ${officerNotes}`;
    }

    return v;
  }
}

export const store = new MemoryStore();
