import React, { useState } from 'react';
import { WasteCenter, WasteReport, HotspotArea } from '../types.ts';
import {
  MapPin,
  Navigation,
  Clock,
  Phone,
  CheckCircle2,
  AlertTriangle,
  Layers,
  ChevronRight,
  Info,
  ExternalLink,
  Building2,
  Trash2
} from 'lucide-react';

interface InteractiveMapProps {
  centers?: WasteCenter[];
  reports?: WasteReport[];
  hotspots?: HotspotArea[];
  selectedCategory?: string;
  showReports?: boolean;
  onSelectCenter?: (center: WasteCenter) => void;
  onSelectReport?: (report: WasteReport) => void;
  height?: string;
}

export const InteractiveMap: React.FC<InteractiveMapProps> = ({
  centers = [],
  reports = [],
  hotspots = [],
  selectedCategory,
  showReports = false,
  onSelectCenter,
  onSelectReport,
  height = '500px'
}) => {
  const [activeType, setActiveType] = useState<string>('all');
  const [selectedCenter, setSelectedCenter] = useState<WasteCenter | null>(centers[0] || null);
  const [selectedReport, setSelectedReport] = useState<WasteReport | null>(null);
  const [mapZoom, setMapZoom] = useState<number>(1);

  // Center coordinate bounds for Pune Central (roughly 18.51 to 18.54 lat, 73.84 to 73.88 lng)
  const minLat = 18.505;
  const maxLat = 18.545;
  const minLng = 73.835;
  const maxLng = 73.885;

  // Convert lat/lng to percentage coordinates on container
  const getCoordinates = (lat: number, lng: number) => {
    const x = ((lng - minLng) / (maxLng - minLng)) * 88 + 6; // range 6% to 94%
    const y = (1 - (lat - minLat) / (maxLat - minLat)) * 84 + 8; // range 8% to 92%
    return {
      left: `${Math.min(92, Math.max(8, x))}%`,
      top: `${Math.min(90, Math.max(10, y))}%`
    };
  };

  const filteredCenters = centers.filter(c => {
    if (activeType === 'all') return true;
    if (activeType === 'recycling') return c.facility_type === 'Recycling Center' || c.facility_type === 'Dry Waste Collection Point';
    if (activeType === 'ewaste') return c.facility_type === 'E-Waste Center';
    if (activeType === 'smart_bins') return c.facility_type === 'Smart Public Bin';
    if (activeType === 'organic') return c.facility_type === 'Wet Waste Composting Facility';
    return true;
  });

  const getMarkerIconBg = (type: string) => {
    switch (type) {
      case 'Recycling Center': return 'bg-emerald-600 text-white border-emerald-300';
      case 'E-Waste Center': return 'bg-blue-600 text-white border-blue-300';
      case 'Smart Public Bin': return 'bg-teal-600 text-white border-teal-300';
      case 'Wet Waste Composting Facility': return 'bg-amber-600 text-white border-amber-300';
      default: return 'bg-slate-700 text-white border-slate-400';
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-slate-200 overflow-hidden shadow-sm flex flex-col">
      {/* Top Filter Bar */}
      <div className="p-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2">
        <div className="flex items-center gap-1.5 overflow-x-auto py-0.5">
          <span className="text-xs font-semibold text-slate-700 mr-1 flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-slate-500" /> Filters:
          </span>
          {[
            { id: 'all', label: 'All Locations' },
            { id: 'recycling', label: 'Recycling Hubs' },
            { id: 'ewaste', label: 'E-Waste' },
            { id: 'smart_bins', label: 'Smart Bins' },
            { id: 'organic', label: 'Compost' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setActiveType(f.id)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition-colors ${
                activeType === f.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-100'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-3 text-xs text-slate-500">
          <span className="flex items-center gap-1 font-medium">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-500"></span> Centers ({filteredCenters.length})
          </span>
          {showReports && (
            <span className="flex items-center gap-1 font-medium">
              <span className="w-2.5 h-2.5 rounded-full bg-rose-500"></span> Live Reports ({reports.length})
            </span>
          )}
        </div>
      </div>

      {/* Main Map Canvas Area */}
      <div className="grid grid-cols-1 lg:grid-cols-3">
        <div className="lg:col-span-2 relative bg-slate-100 overflow-hidden select-none border-b lg:border-b-0 lg:border-r border-slate-200" style={{ height }}>
          {/* Simulated Map Visual Canvas Background */}
          <div className="absolute inset-0 bg-[#e5ece8] opacity-90">
            {/* Grid roads SVG */}
            <svg className="w-full h-full opacity-40" xmlns="http://www.w3.org/2000/svg">
              <defs>
                <pattern id="grid-roads" width="100" height="100" patternUnits="userSpaceOnUse">
                  <path d="M 100 0 L 0 0 0 100" fill="none" stroke="#cbd5e1" strokeWidth="6" />
                  <path d="M 50 0 L 50 100 M 0 50 L 100 50" fill="none" stroke="#ffffff" strokeWidth="3" />
                  <circle cx="50" cy="50" r="12" fill="#d1fae5" stroke="#94a3b8" strokeWidth="1" />
                </pattern>
              </defs>
              <rect width="100%" height="100%" fill="url(#grid-roads)" />
              {/* River line */}
              <path d="M -50 120 Q 200 180 400 110 T 800 200" fill="none" stroke="#bae6fd" strokeWidth="32" />
              <path d="M -50 120 Q 200 180 400 110 T 800 200" fill="none" stroke="#7dd3fc" strokeWidth="12" />
            </svg>

            {/* City Landmarks labels */}
            <div className="absolute top-[18%] left-[20%] text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-white/70 px-2 py-0.5 rounded shadow-xs pointer-events-none">
              Shivaji Nagar Civic Hub
            </div>
            <div className="absolute top-[48%] left-[45%] text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-white/70 px-2 py-0.5 rounded shadow-xs pointer-events-none">
              Market Road Commercial Area
            </div>
            <div className="absolute top-[68%] left-[70%] text-[10px] font-bold uppercase tracking-wider text-slate-400 bg-white/70 px-2 py-0.5 rounded shadow-xs pointer-events-none">
              Railway Yard Sector
            </div>
          </div>

          {/* Hotspot Risk Circles */}
          {hotspots.map(h => {
            const coords = getCoordinates(h.latitude, h.longitude);
            return (
              <div
                key={h.id}
                style={{ left: coords.left, top: coords.top }}
                className="absolute -translate-x-1/2 -translate-y-1/2 pointer-events-none"
              >
                <div className="w-28 h-28 rounded-full bg-rose-500/15 border border-rose-500/40 animate-ping duration-1000"></div>
                <div className="absolute inset-0 m-auto w-16 h-16 rounded-full bg-rose-500/20 flex items-center justify-center">
                  <span className="text-[9px] font-bold text-rose-800 bg-white/90 px-1 py-0.5 rounded shadow-xs">
                    {h.risk_level} Hotspot
                  </span>
                </div>
              </div>
            );
          })}

          {/* Center Markers */}
          {filteredCenters.map(c => {
            const coords = getCoordinates(c.latitude, c.longitude);
            const isSelected = selectedCenter?.id === c.id;
            return (
              <button
                key={c.id}
                onClick={() => {
                  setSelectedCenter(c);
                  setSelectedReport(null);
                  if (onSelectCenter) onSelectCenter(c);
                }}
                style={{ left: coords.left, top: coords.top }}
                className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group transition-transform ${
                  isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                }`}
                title={c.name}
              >
                <div
                  className={`w-7 h-7 rounded-full shadow-md flex items-center justify-center border-2 ${getMarkerIconBg(
                    c.facility_type
                  )} ${isSelected ? 'ring-4 ring-emerald-500/30 ring-offset-1' : ''}`}
                >
                  <MapPin className="w-3.5 h-3.5" />
                </div>
                {/* Micro Label */}
                <div className="absolute top-8 left-1/2 -translate-x-1/2 whitespace-nowrap bg-slate-900/80 text-white text-[10px] px-1.5 py-0.5 rounded font-medium pointer-events-none opacity-0 group-hover:opacity-100 transition-opacity">
                  {c.name}
                </div>
              </button>
            );
          })}

          {/* Live Reports Markers */}
          {showReports &&
            reports.map(r => {
              const coords = getCoordinates(r.latitude, r.longitude);
              const isSelected = selectedReport?.id === r.id;
              const isHigh = r.priority === 'high' || r.priority === 'critical';
              return (
                <button
                  key={r.id}
                  onClick={() => {
                    setSelectedReport(r);
                    setSelectedCenter(null);
                    if (onSelectReport) onSelectReport(r);
                  }}
                  style={{ left: coords.left, top: coords.top }}
                  className={`absolute -translate-x-1/2 -translate-y-1/2 z-20 group transition-transform ${
                    isSelected ? 'scale-125 z-30' : 'hover:scale-110'
                  }`}
                  title={`${r.complaint_id}: ${r.category_name}`}
                >
                  <div
                    className={`w-7 h-7 rounded-full shadow-md flex items-center justify-center border-2 ${
                      r.status === 'Resolved'
                        ? 'bg-emerald-600 text-white border-emerald-300'
                        : isHigh
                        ? 'bg-rose-600 text-white border-rose-300 animate-pulse'
                        : 'bg-amber-500 text-white border-amber-200'
                    } ${isSelected ? 'ring-4 ring-rose-500/30' : ''}`}
                  >
                    <AlertTriangle className="w-3.5 h-3.5" />
                  </div>
                </button>
              );
            })}

          {/* User Location Marker */}
          <div
            style={{ left: '50%', top: '50%' }}
            className="absolute -translate-x-1/2 -translate-y-1/2 z-10 pointer-events-none"
          >
            <div className="w-8 h-8 rounded-full bg-blue-500/20 animate-ping"></div>
            <div className="absolute inset-0 m-auto w-4 h-4 rounded-full bg-blue-600 border-2 border-white shadow-md"></div>
          </div>

          {/* Map Controls */}
          <div className="absolute bottom-3 right-3 flex flex-col gap-1 z-30">
            <button
              onClick={() => alert('GPS Coordinates centered: Pune Smart Grid (18.5204° N, 73.8567° E)')}
              className="p-2 bg-white rounded-lg shadow-md border border-slate-200 text-slate-700 hover:bg-slate-50 transition-colors"
              title="Locate Me"
            >
              <Navigation className="w-4 h-4 text-emerald-600" />
            </button>
          </div>

          <div className="absolute top-3 left-3 bg-white/90 backdrop-blur-xs px-2.5 py-1.5 rounded-lg border border-slate-200/80 text-[11px] font-medium text-slate-700 shadow-xs">
            📍 Current Municipal Zone: <span className="font-bold text-slate-900">Pune Central Ward 14</span>
          </div>
        </div>

        {/* Right Details Panel */}
        <div className="p-4 bg-white flex flex-col justify-between overflow-y-auto max-h-[500px]">
          {selectedCenter ? (
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                    {selectedCenter.facility_type}
                  </span>
                  <h3 className="text-base font-bold text-slate-900 mt-1">{selectedCenter.name}</h3>
                </div>
                <div className="text-right">
                  <div className="text-sm font-extrabold text-emerald-600">
                    {selectedCenter.distance_km || 1.2} km
                  </div>
                  <div className="text-[10px] text-slate-400">away</div>
                </div>
              </div>

              <p className="text-xs text-slate-600 flex items-start gap-1.5">
                <MapPin className="w-4 h-4 text-slate-400 shrink-0 mt-0.5" />
                {selectedCenter.address}
              </p>

              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="text-slate-400 text-[10px] flex items-center gap-1">
                    <Clock className="w-3 h-3 text-emerald-600" /> Hours
                  </div>
                  <div className="font-semibold text-slate-800 text-[11px] mt-0.5">
                    {selectedCenter.operating_hours}
                  </div>
                </div>

                <div className="p-2 bg-slate-50 rounded-lg border border-slate-100">
                  <div className="text-slate-400 text-[10px] flex items-center gap-1">
                    <Phone className="w-3 h-3 text-emerald-600" /> Contact
                  </div>
                  <div className="font-semibold text-slate-800 text-[11px] mt-0.5">
                    {selectedCenter.contact_phone}
                  </div>
                </div>
              </div>

              <div>
                <div className="text-[11px] font-semibold text-slate-700 mb-1.5">
                  Accepted Waste Materials:
                </div>
                <div className="flex flex-wrap gap-1">
                  {selectedCenter.accepted_categories.map((cat, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 bg-slate-100 text-slate-700 text-[11px] rounded-md border border-slate-200/70"
                    >
                      {cat}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100">
                <button
                  onClick={() => alert(`Opening navigation to ${selectedCenter.name} (${selectedCenter.address})`)}
                  className="w-full flex items-center justify-center gap-2 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors"
                >
                  <Navigation className="w-3.5 h-3.5" />
                  Get Turn-by-Turn Directions
                </button>
              </div>
            </div>
          ) : selectedReport ? (
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <div>
                  <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-rose-50 text-rose-700 border border-rose-200">
                    Complaint #{selectedReport.complaint_id}
                  </span>
                  <h3 className="text-sm font-bold text-slate-900 mt-1">{selectedReport.category_name}</h3>
                </div>
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-full bg-slate-100 text-slate-700">
                  {selectedReport.status}
                </span>
              </div>

              <img
                src={selectedReport.image_url}
                alt="Reported Waste"
                className="w-full h-32 object-cover rounded-xl border border-slate-200"
              />

              <p className="text-xs text-slate-600">{selectedReport.description}</p>
              <p className="text-[11px] text-slate-500">📍 {selectedReport.address}</p>

              <div className="p-2 bg-slate-50 rounded-lg border border-slate-100 text-xs">
                <span className="font-semibold text-slate-700">Priority:</span>{' '}
                <span className="capitalize font-bold text-rose-600">{selectedReport.priority}</span>
              </div>
            </div>
          ) : (
            <div className="text-center py-12 text-slate-400 text-xs">
              <MapPin className="w-8 h-8 mx-auto mb-2 text-slate-300" />
              Select any location pin on the map to see operating details, contact info, and accepted materials.
            </div>
          )}

          {/* Quick list preview at bottom */}
          <div className="mt-4 pt-3 border-t border-slate-100">
            <div className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider mb-2">
              Nearby Drop-off Points
            </div>
            <div className="space-y-1.5 max-h-36 overflow-y-auto">
              {filteredCenters.slice(0, 3).map(c => (
                <div
                  key={c.id}
                  onClick={() => setSelectedCenter(c)}
                  className={`p-2 rounded-lg text-xs cursor-pointer flex items-center justify-between transition-colors ${
                    selectedCenter?.id === c.id ? 'bg-emerald-50 text-emerald-900 font-semibold' : 'hover:bg-slate-50 text-slate-700'
                  }`}
                >
                  <div className="truncate mr-2">
                    <div className="truncate">{c.name}</div>
                    <div className="text-[10px] text-slate-400 font-normal truncate">{c.address}</div>
                  </div>
                  <span className="text-[11px] text-emerald-700 shrink-0 font-bold">{c.distance_km || 1.5} km</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
