import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  User as UserIcon,
  ChevronDown,
  Shield,
  Truck,
  Building2,
  CheckCircle2,
  Menu,
  X,
  Home,
  AlertTriangle,
  FileText,
  ShieldAlert,
  LogOut,
  LogIn
} from 'lucide-react';
import { UserRole } from '../types.ts';

interface NavbarProps {
  onToggleSidebar?: () => void;
  isSidebarOpen?: boolean;
}

export const Navbar: React.FC<NavbarProps> = ({ onToggleSidebar, isSidebarOpen }) => {
  const { user, role, loginAs, logout, currentPage, setCurrentPage } = useAuth();
  const [isRoleMenuOpen, setIsRoleMenuOpen] = useState(false);
  const [isProfileMenuOpen, setIsProfileMenuOpen] = useState(false);

  const roleRef = useRef<HTMLDivElement>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Close menus on outside click
  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (roleRef.current && !roleRef.current.contains(e.target as Node)) setIsRoleMenuOpen(false);
      if (profileRef.current && !profileRef.current.contains(e.target as Node)) setIsProfileMenuOpen(false);
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const roleLabels: Record<UserRole, { label: string; badgeClass: string; icon: any }> = {
    citizen: { label: 'Citizen', badgeClass: 'bg-emerald-100 text-emerald-800 border-emerald-200', icon: UserIcon },
    admin: { label: 'Municipality Admin', badgeClass: 'bg-blue-100 text-blue-800 border-blue-200', icon: Building2 },
    worker: { label: 'Collection Worker', badgeClass: 'bg-amber-100 text-amber-800 border-amber-200', icon: Truck },
    enforcement: { label: 'Enforcement Officer', badgeClass: 'bg-purple-100 text-purple-800 border-purple-200', icon: Shield }
  };

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Left: Brand / Logo */}
        <div className="flex items-center gap-3">
          {onToggleSidebar && (
            <button
              id="btn-sidebar-toggle"
              onClick={onToggleSidebar}
              className="md:hidden p-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg"
              aria-label="Toggle Navigation"
            >
              {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          )}

          <div
            onClick={() => setCurrentPage('landing')}
            className="flex items-center gap-2.5 cursor-pointer group select-none"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-emerald-500 to-teal-700 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform">
              <svg className="w-5 h-5 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z"/>
                <path d="M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12"/>
              </svg>
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="font-extrabold text-xl tracking-tight text-slate-900 font-sans">
                  Eco<span className="text-emerald-600">Track</span>
                </span>
                <span className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-semibold uppercase tracking-wider bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-md">
                  Smart City
                </span>
              </div>
              <p className="hidden md:block text-[10px] text-slate-500 -mt-0.5">Waste Management Portal</p>
            </div>
          </div>
        </div>

        {/* Center: Basic Level Website Main Navigation Links */}
        <nav className="hidden md:flex items-center gap-1">
          <button
            onClick={() => setCurrentPage('landing')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              currentPage === 'landing'
                ? 'bg-emerald-50 text-emerald-800'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            Home
          </button>

          <button
            onClick={() => setCurrentPage('report_waste')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              currentPage === 'report_waste'
                ? 'bg-emerald-50 text-emerald-800'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <AlertTriangle className="w-3.5 h-3.5 text-amber-500" />
            Report Waste
          </button>

          <button
            onClick={() => setCurrentPage('my_reports')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              currentPage === 'my_reports'
                ? 'bg-emerald-50 text-emerald-800'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <FileText className="w-3.5 h-3.5 text-blue-500" />
            Track Status
          </button>

          <button
            onClick={() => setCurrentPage('auth')}
            className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors flex items-center gap-1.5 ${
              currentPage === 'auth'
                ? 'bg-emerald-50 text-emerald-800'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            Official Portals
          </button>
        </nav>

        {/* Right: Role Switcher (when logged in) OR Login & Register (when logged out) */}
        <div className="flex items-center gap-2 sm:gap-3">
          {user ? (
            <>
              {/* Quick Role Switcher Pill for authenticated users */}
              <div className="relative" ref={roleRef}>
                <button
                  id="btn-role-switcher"
                  onClick={() => setIsRoleMenuOpen(!isRoleMenuOpen)}
                  className={`flex items-center gap-1.5 px-2.5 py-1.5 text-xs font-semibold rounded-lg border transition-all ${roleLabels[role].badgeClass}`}
                  title="Switch Active Role"
                >
                  {React.createElement(roleLabels[role].icon, { className: "w-3.5 h-3.5" })}
                  <span className="hidden sm:inline">{roleLabels[role].label}</span>
                  <ChevronDown className="w-3 h-3 ml-0.5 opacity-60" />
                </button>

                {isRoleMenuOpen && (
                  <div className="absolute right-0 mt-2 w-64 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 text-slate-800 animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-2 py-1 text-[11px] font-semibold text-slate-400 uppercase tracking-wider">
                      Select Role Portal
                    </div>
                    <div className="space-y-1 mt-1">
                      {(['citizen', 'admin', 'worker', 'enforcement'] as UserRole[]).map((r) => {
                        const info = roleLabels[r];
                        const Icon = info.icon;
                        const isActive = role === r;
                        return (
                          <button
                            key={r}
                            onClick={() => {
                              loginAs(r);
                              setIsRoleMenuOpen(false);
                            }}
                            className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-xs font-medium transition-colors ${
                              isActive ? 'bg-emerald-50 text-emerald-900 font-semibold' : 'hover:bg-slate-100 text-slate-700'
                            }`}
                          >
                            <div className="flex items-center gap-2.5">
                              <div className={`p-1.5 rounded-md ${isActive ? 'bg-emerald-600 text-white' : 'bg-slate-100 text-slate-600'}`}>
                                <Icon className="w-3.5 h-3.5" />
                              </div>
                              <div className="text-left">
                                <div className="text-slate-900">{info.label}</div>
                                <div className="text-[10px] text-slate-500">
                                  {r === 'citizen' && 'Public User'}
                                  {r === 'admin' && 'Municipality Admin'}
                                  {r === 'worker' && 'Collection Worker'}
                                  {r === 'enforcement' && 'Enforcement Officer'}
                                </div>
                              </div>
                            </div>
                            {isActive && <CheckCircle2 className="w-4 h-4 text-emerald-600" />}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                )}
              </div>

              {/* User Account / Profile */}
              <div className="relative" ref={profileRef}>
                <div className="flex items-center gap-2">
                  <button
                    id="btn-user-menu"
                    onClick={() => setIsProfileMenuOpen(!isProfileMenuOpen)}
                    className="flex items-center gap-2 p-1 rounded-full hover:ring-2 hover:ring-emerald-500/30 transition-all"
                  >
                    <img
                      src={user.profile_photo || 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=150'}
                      alt={user.name}
                      className="w-8 h-8 rounded-full object-cover border border-slate-200"
                    />
                    <span className="hidden lg:inline text-xs font-bold text-slate-700">{user.name}</span>
                  </button>

                  <button
                    onClick={logout}
                    title="Sign Out"
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                  >
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>

                {isProfileMenuOpen && (
                  <div className="absolute right-0 mt-2 w-56 bg-white rounded-xl shadow-xl border border-slate-200 p-2 z-50 text-slate-800 animate-in fade-in zoom-in-95 duration-100">
                    <div className="px-3 py-2 border-b border-slate-100">
                      <p className="text-sm font-semibold text-slate-900 truncate">{user.name}</p>
                      <p className="text-xs text-slate-500 truncate">{user.email}</p>
                      <span className="inline-block mt-1 text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-700">
                        {roleLabels[role].label}
                      </span>
                    </div>

                    <div className="py-1 text-xs">
                      <button
                        onClick={() => {
                          setCurrentPage('profile');
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded-lg flex items-center gap-2 text-slate-700"
                      >
                        <UserIcon className="w-4 h-4 text-slate-500" />
                        My Profile
                      </button>
                      <button
                        onClick={() => {
                          setCurrentPage('report_waste');
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded-lg flex items-center gap-2 text-slate-700"
                      >
                        <AlertTriangle className="w-4 h-4 text-amber-500" />
                        Report Waste
                      </button>
                      <button
                        onClick={() => {
                          setCurrentPage('my_reports');
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-slate-100 rounded-lg flex items-center gap-2 text-slate-700"
                      >
                        <FileText className="w-4 h-4 text-blue-500" />
                        Track My Complaints
                      </button>
                    </div>

                    <div className="border-t border-slate-100 pt-1">
                      <button
                        onClick={() => {
                          logout();
                          setIsProfileMenuOpen(false);
                        }}
                        className="w-full text-left px-3 py-2 hover:bg-rose-50 text-rose-600 rounded-lg text-xs font-semibold flex items-center gap-2"
                      >
                        <LogOut className="w-3.5 h-3.5" />
                        Sign Out
                      </button>
                    </div>
                  </div>
                )}
              </div>
            </>
          ) : (
            <div className="flex items-center gap-2">
              <button
                id="btn-nav-login"
                onClick={() => setCurrentPage('auth')}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
              >
                <LogIn className="w-3.5 h-3.5" />
                <span>Login</span>
              </button>
              <button
                id="btn-nav-register"
                onClick={() => setCurrentPage('auth')}
                className="hidden sm:flex px-3.5 py-2 bg-white hover:bg-slate-50 text-slate-700 border border-slate-300 rounded-xl text-xs font-bold shadow-xs transition-colors items-center gap-1.5"
              >
                <span>Register</span>
              </button>
            </div>
          )}
        </div>
      </div>
    </header>
  );
};
