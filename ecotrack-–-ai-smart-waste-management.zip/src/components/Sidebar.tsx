import React from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  LayoutDashboard,
  Scan,
  BookOpen,
  AlertTriangle,
  FileText,
  MapPin,
  Award,
  Trophy,
  Bell,
  User,
  Bot,
  LogOut,
  ShieldAlert,
  BarChart3,
  Users,
  Layers,
  Map,
  CheckSquare
} from 'lucide-react';

interface SidebarProps {
  isOpen?: boolean;
  onClose?: () => void;
}

interface NavItem {
  key: string;
  label: string;
  icon: any;
  highlight?: boolean;
  isNew?: boolean;
  badge?: string;
}

export const Sidebar: React.FC<SidebarProps> = ({ isOpen, onClose }) => {
  const { role, currentPage, setCurrentPage, logout } = useAuth();

  const handleNav = (pageKey: string) => {
    setCurrentPage(pageKey);
    if (onClose) onClose();
  };

  // Simplified nav items for basic level website
  const citizenItems: NavItem[] = [
    { key: 'citizen_dashboard', label: 'My Dashboard', icon: LayoutDashboard },
    { key: 'report_waste', label: 'Report Waste', icon: AlertTriangle, highlight: true },
    { key: 'my_reports', label: 'Track Complaints', icon: FileText },
    { key: 'waste_scanner', label: 'Scan Waste (Camera)', icon: Scan },
    { key: 'profile', label: 'My Profile', icon: User },
  ];

  const adminItems: NavItem[] = [
    { key: 'admin_dashboard', label: 'Municipality Overview', icon: LayoutDashboard },
    { key: 'violations_enforcement', label: 'Violations & Fines', icon: ShieldAlert },
    { key: 'my_reports', label: 'All Complaints List', icon: FileText },
  ];

  const workerItems: NavItem[] = [
    { key: 'worker_dashboard', label: 'Assigned Collection Tasks', icon: CheckSquare },
    { key: 'nearby_centers', label: 'Route Map & Bins', icon: MapPin },
  ];

  const enforcementItems: NavItem[] = [
    { key: 'violations_enforcement', label: 'Violation Cases & ALPR', icon: ShieldAlert },
  ];

  const navList =
    role === 'admin'
      ? adminItems
      : role === 'worker'
      ? workerItems
      : role === 'enforcement'
      ? enforcementItems
      : citizenItems;

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          onClick={onClose}
          className="fixed inset-0 z-40 bg-slate-900/50 backdrop-blur-xs md:hidden"
        />
      )}

      <aside
        className={`fixed md:sticky top-16 left-0 z-40 h-[calc(100vh-4rem)] w-64 bg-white/95 backdrop-blur-md border-r border-slate-200/80 p-3 flex flex-col justify-between transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="overflow-y-auto space-y-1 py-1">
          <div className="px-3 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-600">
            {role === 'admin' ? 'Municipality Console' : role === 'worker' ? 'Collection Worker Unit' : role === 'enforcement' ? 'Enforcement Portal' : 'Smart Citizen Portal'}
          </div>

          <nav className="space-y-0.5">
            {navList.map(item => {
              const Icon = item.icon;
              const isActive = currentPage === item.key;
              return (
                <button
                  key={item.key}
                  id={`nav-item-${item.key}`}
                  onClick={() => handleNav(item.key)}
                  className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-emerald-600 text-white font-semibold shadow-xs shadow-emerald-600/30'
                      : item.highlight
                      ? 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100'
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
                  }`}
                >
                  <div className="flex items-center gap-2.5">
                    <Icon className={`w-4 h-4 ${isActive ? 'text-white' : item.highlight ? 'text-emerald-600' : 'text-slate-500'}`} />
                    <span>{item.label}</span>
                  </div>
                  {item.isNew && (
                    <span className="text-[9px] font-bold px-1.5 py-0.5 bg-emerald-100 text-emerald-700 rounded-full">
                      AI
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Footer info & Logout */}
        <div className="pt-3 border-t border-slate-200 space-y-2">
          <div className="px-3 py-2 bg-slate-50 rounded-xl border border-slate-200/70 text-[11px] text-slate-600">
            <div className="font-semibold text-slate-800 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              Smart City Grid Active
            </div>
            <div className="text-[10px] text-slate-600 mt-0.5">Ward 14 • Pune Central</div>
          </div>

          <button
            onClick={logout}
            className="w-full flex items-center gap-2 px-3 py-2 text-xs font-medium text-slate-500 hover:text-rose-600 hover:bg-rose-50 rounded-xl transition-colors"
          >
            <LogOut className="w-4 h-4" />
            <span>Sign Out</span>
          </button>
        </div>
      </aside>
    </>
  );
};
