import {
  User,
  WasteCategory,
  WasteReport,
  WasteCenter,
  NotificationItem,
  ViolationRecord,
  WasteScanRecord,
  RewardItem,
  HotspotArea
} from '../types.ts';

const BASE_URL = '/api';

export async function loginUser(email: string, role?: string): Promise<{ user: User; token: string }> {
  const res = await fetch(`${BASE_URL}/auth/login`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ email, role })
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Login failed');
  return res.json();
}

export async function registerUser(userData: Partial<User>): Promise<{ user: User; token: string }> {
  const res = await fetch(`${BASE_URL}/auth/register`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(userData)
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Registration failed');
  return res.json();
}

export async function fetchUserProfile(userId: string): Promise<User> {
  const res = await fetch(`${BASE_URL}/users/profile?userId=${userId}`);
  const data = await res.json();
  return data.user;
}

export async function updateUserProfile(userId: string, updates: Partial<User>): Promise<User> {
  const res = await fetch(`${BASE_URL}/users/profile?userId=${userId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(updates)
  });
  const data = await res.json();
  return data.user;
}

export async function fetchWasteCategories(): Promise<WasteCategory[]> {
  const res = await fetch(`${BASE_URL}/waste/categories`);
  const data = await res.json();
  return data.categories;
}

export async function scanWasteImage(image: string, userId: string, mimeType: string = 'image/jpeg') {
  const res = await fetch(`${BASE_URL}/waste/scan`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ image, userId, mimeType })
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Scan failed');
  return res.json();
}

export async function submitWasteReport(reportData: {
  userId: string;
  categoryId: string;
  description: string;
  imageUrl: string;
  latitude: number;
  longitude: number;
  address: string;
  priority?: string;
}): Promise<{ report: WasteReport; complaintId: string }> {
  const res = await fetch(`${BASE_URL}/reports`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(reportData)
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Failed to submit report');
  return res.json();
}

export async function fetchMyReports(userId: string): Promise<WasteReport[]> {
  const res = await fetch(`${BASE_URL}/reports/my?userId=${userId}`);
  const data = await res.json();
  return data.reports;
}

export async function fetchAllReports(filters?: { status?: string; priority?: string; category?: string; search?: string }): Promise<WasteReport[]> {
  const query = new URLSearchParams(filters as any).toString();
  const res = await fetch(`${BASE_URL}/admin/reports?${query}`);
  const data = await res.json();
  return data.reports;
}

export async function updateReportStatus(reportId: string, status: string, note?: string): Promise<WasteReport> {
  const res = await fetch(`${BASE_URL}/admin/reports/${reportId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, note })
  });
  const data = await res.json();
  return data.report;
}

export async function assignWorkerToReport(reportId: string, workerId: string): Promise<WasteReport> {
  const res = await fetch(`${BASE_URL}/admin/assign-worker`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ reportId, workerId })
  });
  const data = await res.json();
  return data.report;
}

export async function fetchAdminDashboardData() {
  const res = await fetch(`${BASE_URL}/admin/dashboard`);
  return res.json();
}

export async function fetchWorkerTasks(): Promise<any[]> {
  const res = await fetch(`${BASE_URL}/worker/tasks`);
  const data = await res.json();
  return data.tasks;
}

export async function updateWorkerTaskStatus(taskId: string, status: string, note?: string) {
  const res = await fetch(`${BASE_URL}/worker/tasks/${taskId}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ status, note })
  });
  return res.json();
}

export async function uploadCleaningProof(taskId: string, afterPhotoUrl: string, notes?: string) {
  const res = await fetch(`${BASE_URL}/worker/tasks/${taskId}/proof`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ afterPhotoUrl, notes })
  });
  return res.json();
}

export async function fetchPointsSummary(userId: string) {
  const res = await fetch(`${BASE_URL}/points?userId=${userId}`);
  return res.json();
}

export async function redeemReward(userId: string, rewardId: string) {
  const res = await fetch(`${BASE_URL}/points/redeem`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId, rewardId })
  });
  if (!res.ok) throw new Error((await res.json()).error || 'Redemption failed');
  return res.json();
}

export async function fetchLeaderboard() {
  const res = await fetch(`${BASE_URL}/points/leaderboard`);
  const data = await res.json();
  return data.leaderboard;
}

export async function fetchNotifications(userId: string): Promise<{ notifications: NotificationItem[]; unreadCount: number }> {
  const res = await fetch(`${BASE_URL}/notifications?userId=${userId}`);
  return res.json();
}

export async function markNotificationRead(id: string) {
  const res = await fetch(`${BASE_URL}/notifications/${id}/read`, { method: 'PUT' });
  return res.json();
}

export async function markAllNotificationsRead(userId: string) {
  const res = await fetch(`${BASE_URL}/notifications/read-all`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ userId })
  });
  return res.json();
}

export async function fetchWasteCenters(params?: { category?: string; type?: string }): Promise<WasteCenter[]> {
  const query = new URLSearchParams(params as any).toString();
  const res = await fetch(`${BASE_URL}/centers?${query}`);
  const data = await res.json();
  return data.centers;
}

export async function fetchViolations(): Promise<ViolationRecord[]> {
  const res = await fetch(`${BASE_URL}/violations`);
  const data = await res.json();
  return data.violations;
}

export async function submitViolationReport(data: {
  reporterId: string;
  vehicleNumber: string;
  vehicleImageUrl: string;
  wasteImageUrl?: string;
  locationAddress: string;
  latitude: number;
  longitude: number;
  ocrConfidence: number;
  notes?: string;
}) {
  const res = await fetch(`${BASE_URL}/violations`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data)
  });
  return res.json();
}

export async function verifyViolationAction(violationId: string, action: string, officerNotes?: string, officerName?: string) {
  const res = await fetch(`${BASE_URL}/violations/${violationId}/verify`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action, officerNotes, officerName })
  });
  return res.json();
}

export async function ocrPlateImage(image: string, mimeType: string = 'image/jpeg') {
  const res = await fetch(`${BASE_URL}/ai/license-plate`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ image, mimeType })
  });
  return res.json();
}

export async function sendAiChatMessage(messages: { role: string; content: string }[]) {
  const res = await fetch(`${BASE_URL}/ai/chat`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ messages })
  });
  return res.json();
}
