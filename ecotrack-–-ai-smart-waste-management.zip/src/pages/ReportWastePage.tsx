import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  AlertTriangle,
  Camera,
  Upload,
  MapPin,
  CheckCircle2,
  Navigation,
  Sparkles,
  ArrowRight,
  Info
} from 'lucide-react';
import { submitWasteReport, fetchWasteCategories } from '../services/api.ts';
import { WasteCategory } from '../types.ts';

const SAMPLE_GARBAGE_IMAGES = [
  {
    name: 'Overflowing Plastic Bin',
    url: 'https://images.unsplash.com/photo-1604187351574-c75ca79f5807?w=600&auto=format&fit=crop&q=80',
    category: 'cat_plastic',
    desc: 'Public municipal bin overflowing onto pedestrian sidewalk'
  },
  {
    name: 'Roadside Construction Rubble',
    url: 'https://images.unsplash.com/photo-1530587191325-3db32d826c18?w=600&auto=format&fit=crop&q=80',
    category: 'cat_construction',
    desc: 'Concrete blocks and rubble dumped along service road'
  },
  {
    name: 'Illegal Organic Waste Pile',
    url: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=600&auto=format&fit=crop&q=80',
    category: 'cat_organic',
    desc: 'Rotting vegetable heaps near vegetable market gate'
  }
];

export const ReportWastePage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();
  const [categories, setCategories] = useState<WasteCategory[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('cat_plastic');
  const [description, setDescription] = useState('');
  const [imageUrl, setImageUrl] = useState<string>('');
  const [latitude, setLatitude] = useState<number>(18.5204);
  const [longitude, setLongitude] = useState<number>(73.8567);
  const [address, setAddress] = useState('Market Yard Gate 3, Pune Central');
  const [landmark, setLandmark] = useState('Opposite City General Hospital');
  const [priority, setPriority] = useState<'low' | 'medium' | 'high' | 'critical'>('medium');
  const [submitting, setSubmitting] = useState(false);
  const [submittedReport, setSubmittedReport] = useState<any>(null);

  useEffect(() => {
    fetchWasteCategories().then(cats => {
      setCategories(cats || []);
      if (cats?.length > 0) setSelectedCategory(cats[0].id);
    });
  }, []);

  const handleGetLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        pos => {
          setLatitude(Number(pos.coords.latitude.toFixed(6)));
          setLongitude(Number(pos.coords.longitude.toFixed(6)));
          setAddress(`GPS Coords: ${pos.coords.latitude.toFixed(4)}, ${pos.coords.longitude.toFixed(4)} (Verified)`);
        },
        () => {
          // Fallback to municipal default
          setLatitude(18.5204);
          setLongitude(73.8567);
          setAddress('Market Yard Gate 3, Pune Central');
        }
      );
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      setImageUrl(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!imageUrl) {
      alert('Please upload or select a photo of the waste problem');
      return;
    }
    if (!description) {
      alert('Please provide a brief description of the issue');
      return;
    }

    setSubmitting(true);
    try {
      const fullAddress = landmark ? `${address} (Near ${landmark})` : address;
      const res = await submitWasteReport({
        userId: user?.id || 'usr_citizen_1',
        categoryId: selectedCategory,
        description,
        imageUrl,
        latitude,
        longitude,
        address: fullAddress,
        priority
      });

      setSubmittedReport(res);
    } catch (err: any) {
      alert(err.message || 'Error filing waste report');
    } finally {
      setSubmitting(false);
    }
  };

  if (submittedReport) {
    return (
      <div className="max-w-2xl mx-auto py-12 text-center space-y-6">
        <div className="w-16 h-16 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-md">
          <CheckCircle2 className="w-8 h-8" />
        </div>
        <div>
          <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-200">
            Complaint Registered Successfully
          </span>
          <h1 className="text-2xl sm:text-3xl font-black text-slate-900 mt-2">
            Complaint #{submittedReport.complaintId}
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-2 max-w-md mx-auto">
            Your complaint has been geo-tagged, queued in the municipal dispatch registry, and assigned to Ward 14 Sanitation Unit.
          </p>
        </div>

        <div className="p-4 bg-white rounded-2xl border border-slate-200 shadow-xs max-w-md mx-auto text-left space-y-2 text-xs">
          <div className="flex justify-between">
            <span className="text-slate-500">Status:</span>
            <span className="font-bold text-amber-700 bg-amber-50 px-2 py-0.5 rounded">Submitted (Pending Verification)</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Location:</span>
            <span className="font-medium text-slate-800 truncate max-w-[240px]">{submittedReport.report?.address}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Estimated Resolution:</span>
            <span className="font-bold text-emerald-700">Within 24 Hours</span>
          </div>
          <div className="flex justify-between">
            <span className="text-slate-500">Earned Points:</span>
            <span className="font-bold text-emerald-700">+20 pts (upon verified clean-up)</span>
          </div>
        </div>

        <div className="flex items-center justify-center gap-3 pt-2">
          <button
            onClick={() => setCurrentPage('my_reports')}
            className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition-colors flex items-center gap-1.5"
          >
            Track Status in My Reports <ArrowRight className="w-4 h-4" />
          </button>
          <button
            onClick={() => {
              setSubmittedReport(null);
              setImageUrl('');
              setDescription('');
            }}
            className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-xl text-xs transition-colors"
          >
            Report Another Issue
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-semibold mb-2">
          <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
          Public Sanitation Grievance Redressal
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Report a Garbage or Waste Problem
        </h1>
        <p className="text-slate-600 text-xs sm:text-sm mt-1">
          Provide photos and GPS coordinates of roadside trash or uncollected bins for municipal compactor truck dispatch.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
        {/* Section 1: Photo Upload */}
        <div>
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
            1. Waste Problem Photo <span className="text-rose-500">*</span>
          </label>

          {imageUrl ? (
            <div className="relative rounded-2xl overflow-hidden border border-slate-200 aspect-video max-h-64 shadow-xs">
              <img src={imageUrl} alt="Uploaded Waste" className="w-full h-full object-cover" />
              <button
                type="button"
                onClick={() => setImageUrl('')}
                className="absolute top-2 right-2 px-2.5 py-1 bg-slate-900/80 hover:bg-slate-900 text-white text-xs rounded-lg backdrop-blur-xs transition-colors"
              >
                Change Photo
              </button>
            </div>
          ) : (
            <div className="space-y-3">
              <label className="border-2 border-dashed border-slate-300 hover:border-emerald-500 bg-slate-50/50 hover:bg-emerald-50/30 rounded-2xl p-6 sm:p-8 text-center cursor-pointer transition-all flex flex-col items-center justify-center block">
                <Upload className="w-8 h-8 text-slate-400 mb-2" />
                <span className="text-xs font-bold text-slate-700">Click to upload photo or take picture</span>
                <span className="text-[10px] text-slate-400 mt-0.5">JPEG, PNG from device camera</span>
                <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
              </label>

              {/* Sample Photos for Quick Testing */}
              <div>
                <span className="text-[11px] font-semibold text-slate-500 uppercase tracking-wider">
                  Or select a sample garbage photo:
                </span>
                <div className="grid grid-cols-3 gap-2 mt-1.5">
                  {SAMPLE_GARBAGE_IMAGES.map((sample, idx) => (
                    <div
                      key={idx}
                      onClick={() => {
                        setImageUrl(sample.url);
                        setSelectedCategory(sample.category);
                        setDescription(sample.desc);
                      }}
                      className="p-1.5 rounded-xl border border-slate-200 hover:border-emerald-500 cursor-pointer transition-all bg-slate-50 text-center"
                    >
                      <img src={sample.url} alt={sample.name} className="w-full h-14 object-cover rounded-lg mb-1" />
                      <div className="text-[10px] font-semibold text-slate-800 truncate">{sample.name}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Section 2: Category & Priority */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              2. Waste Category <span className="text-rose-500">*</span>
            </label>
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 font-medium text-slate-800"
            >
              {categories.map(cat => (
                <option key={cat.id} value={cat.id}>
                  {cat.name} ({cat.classification})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
              Priority Urgency
            </label>
            <div className="grid grid-cols-4 gap-1.5">
              {(['low', 'medium', 'high', 'critical'] as const).map(p => (
                <button
                  key={p}
                  type="button"
                  onClick={() => setPriority(p)}
                  className={`py-2 text-xs font-bold uppercase rounded-xl transition-all ${
                    priority === p
                      ? p === 'critical'
                        ? 'bg-rose-600 text-white shadow-xs'
                        : p === 'high'
                        ? 'bg-amber-600 text-white shadow-xs'
                        : 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {p}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Section 3: Description */}
        <div>
          <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
            3. Issue Description <span className="text-rose-500">*</span>
          </label>
          <textarea
            rows={3}
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Describe the waste situation (e.g. Broken glass and plastic bags spilled on walking path, blocking drainage gutter...)"
            className="w-full p-3 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800 leading-relaxed"
          />
        </div>

        {/* Section 4: Location & GPS */}
        <div className="space-y-3">
          <div className="flex items-center justify-between">
            <label className="block text-xs font-bold text-slate-900 uppercase tracking-wider">
              4. Incident Location & Geo-Coordinates <span className="text-rose-500">*</span>
            </label>
            <button
              type="button"
              onClick={handleGetLocation}
              className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
            >
              <Navigation className="w-3.5 h-3.5" /> Auto-Detect GPS Location
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <input
                type="text"
                value={address}
                onChange={(e) => setAddress(e.target.value)}
                placeholder="Street Address or Area Name"
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
              />
            </div>
            <div>
              <input
                type="text"
                value={landmark}
                onChange={(e) => setLandmark(e.target.value)}
                placeholder="Nearby Landmark (e.g. Opposite Post Office)"
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-xl border border-slate-200/70 flex items-center justify-between text-xs text-slate-500">
            <span className="flex items-center gap-1.5 font-mono">
              <MapPin className="w-3.5 h-3.5 text-emerald-600" />
              Lat: {latitude} | Long: {longitude}
            </span>
            <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
              GPS Verified
            </span>
          </div>
        </div>

        {/* Submit CTA */}
        <div className="pt-2">
          <button
            type="submit"
            disabled={submitting}
            className="w-full py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl text-xs font-bold shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
          >
            {submitting ? 'Submitting & Geo-Tagging...' : 'File Municipal Report & Generate Complaint ID'}
          </button>
        </div>
      </form>
    </div>
  );
};
