import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Building2,
  Users,
  FileText,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  MapPin,
  Truck,
  ShieldAlert,
  Search,
  Filter,
  BarChart3,
  Calendar,
  Layers,
  ArrowUpRight,
  UserCheck,
  Flame,
  X
} from 'lucide-react';
import {
  fetchAdminDashboardData,
  fetchAllReports,
  updateReportStatus,
  assignWorkerToReport
} from '../services/api.ts';
import { InteractiveMap } from '../components/InteractiveMap.tsx';
import { WasteReport } from '../types.ts';

const MUNICIPAL_WORKERS = [
  { id: 'usr_worker_1', name: 'Suresh Kumar (Truck MH12-9844)' },
  { id: 'usr_worker_2', name: 'Ramesh Patil (Compactor MH12-3310)' },
  { id: 'usr_worker_3', name: 'Anita Gaikwad (Sweeping Unit Ward 14)' },
  { id: 'usr_worker_4', name: 'Vikas Shinde (Rapid Response Eco-Van)' },
];

export const AdminDashboard: React.FC = () => {
  const { setCurrentPage } = useAuth();
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [reports, setReports] = useState<WasteReport[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [priorityFilter, setPriorityFilter] = useState('all');
  const [assigningReport, setAssigningReport] = useState<WasteReport | null>(null);
  const [selectedWorkerId, setSelectedWorkerId] = useState(MUNICIPAL_WORKERS[0].id);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [dash, reps] = await Promise.all([
        fetchAdminDashboardData(),
        fetchAllReports()
      ]);
      setDashboardData(dash);
      setReports(reps || []);
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusChange = async (reportId: string, newStatus: string) => {
    try {
      await updateReportStatus(reportId, newStatus, `Municipality admin updated status to ${newStatus}`);
      loadData();
    } catch (e) {
      console.error(e);
    }
  };

  const handleAssignWorker = async () => {
    if (!assigningReport) return;
    try {
      await assignWorkerToReport(assigningReport.id, selectedWorkerId);
      setAssigningReport(null);
      loadData();
    } catch (e) {
      alert('Error assigning worker');
    }
  };

  const filteredReports = reports.filter(r => {
    const matchesSearch =
      r.complaint_id.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      r.category_name.toLowerCase().includes(searchQuery.toLowerCase());

    const matchesStatus = statusFilter === 'all' || r.status.toLowerCase() === statusFilter.toLowerCase();
    const matchesPriority = priorityFilter === 'all' || r.priority.toLowerCase() === priorityFilter.toLowerCase();

    return matchesSearch && matchesStatus && matchesPriority;
  });

  const kpis = dashboardData?.kpis || {
    totalUsers: 5245,
    totalScans: 12484,
    totalReports: 2349,
    pendingReports: 3,
    inProgressReports: 2,
    resolvedReports: 2038,
    resolutionRate: 87.2,
    verifiedViolations: 2
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-blue-50 text-blue-800 border border-blue-200 text-xs font-semibold mb-2">
            <Building2 className="w-3.5 h-3.5 text-blue-600" />
            Pune Municipal Solid Waste Command Center
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Municipality Operations & Waste Monitoring
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Real-time citizen grievance dispatch, automated worker allocation, and predictive illegal dumping analytics.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setCurrentPage('violations_enforcement')}
            className="px-4 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
          >
            <ShieldAlert className="w-4 h-4" /> ALPR Violations
          </button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-8 gap-3">
        {[
          { label: 'Citizens Enrolled', val: kpis.totalUsers.toLocaleString(), color: 'text-blue-600', bg: 'bg-blue-50' },
          { label: 'AI Waste Scans', val: kpis.totalScans.toLocaleString(), color: 'text-emerald-600', bg: 'bg-emerald-50' },
          { label: 'Complaints Logged', val: kpis.totalReports.toLocaleString(), color: 'text-slate-800', bg: 'bg-slate-50' },
          { label: 'Under Review', val: kpis.pendingReports, color: 'text-amber-600', bg: 'bg-amber-50' },
          { label: 'Trucks Dispatched', val: kpis.inProgressReports, color: 'text-indigo-600', bg: 'bg-indigo-50' },
          { label: 'Piles Cleared', val: kpis.resolvedReports.toLocaleString(), color: 'text-emerald-700', bg: 'bg-emerald-50' },
          { label: 'Resolution Rate', val: `${kpis.resolutionRate}%`, color: 'text-teal-700', bg: 'bg-teal-50' },
          { label: 'Violations Verified', val: kpis.verifiedViolations, color: 'text-purple-700', bg: 'bg-purple-50' },
        ].map((kpi, idx) => (
          <div key={idx} className="bg-white p-3.5 rounded-2xl border border-slate-200 shadow-xs text-center">
            <div className={`text-lg sm:text-xl font-black ${kpi.color}`}>{kpi.val}</div>
            <div className="text-[10px] text-slate-500 font-semibold mt-1 leading-tight">{kpi.label}</div>
          </div>
        ))}
      </div>

      {/* Live Map & Predictive Hotspots Row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live City Reports Map (2 cols) */}
        <div className="lg:col-span-2 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider flex items-center gap-2">
              <MapPin className="w-4 h-4 text-emerald-600" /> Live Geo-Tagged City Grievance Map
            </h3>
            <span className="text-xs text-slate-500 font-medium">🔴 High Priority • 🟠 Pending • 🟢 Resolved</span>
          </div>
          <InteractiveMap
            reports={reports}
            hotspots={dashboardData?.hotspots || []}
            showReports={true}
            height="420px"
          />
        </div>

        {/* Predictive AI Hotspots (1 col) */}
        <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-sm font-bold text-slate-900 flex items-center gap-1.5">
                <Flame className="w-4 h-4 text-rose-500" /> AI Waste Hotspots
              </h3>
              <span className="text-[10px] font-bold uppercase bg-rose-50 text-rose-700 px-2 py-0.5 rounded border border-rose-200">
                Predictive Risk
              </span>
            </div>
            <p className="text-xs text-slate-500 mb-4">
              Algorithms predict future litter accumulation zones based on historical complaints and commercial footfall.
            </p>

            <div className="space-y-3">
              {(dashboardData?.hotspots || []).map((h: any) => (
                <div key={h.id} className="p-3 bg-slate-50 rounded-xl border border-slate-200 text-xs space-y-1">
                  <div className="flex items-center justify-between font-bold">
                    <span className="text-slate-900">{h.zone_name}</span>
                    <span className="text-rose-700 bg-rose-50 px-1.5 py-0.2 rounded border border-rose-200 text-[10px]">
                      {h.risk_level} Risk ({h.predicted_probability * 100}%)
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500">
                    Complaints: <strong className="text-slate-800">{h.complaint_count}</strong> • Waste: <strong className="text-slate-800">{h.primary_waste_type}</strong>
                  </div>
                  <div className="text-[11px] text-emerald-800 font-medium pt-1">
                    Action: {h.recommended_action}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <button
              onClick={() => alert('Dispatched additional nighttime sweepers to Market Road Sector 4.')}
              className="w-full py-2 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Deploy Preventative Sweeper Route
            </button>
          </div>
        </div>
      </div>

      {/* Complaint Redressal Management Table */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900">Complaints Management Registry</h3>
            <p className="text-xs text-slate-500">Verify reports, assign sanitation workers, and audit photographic proof</p>
          </div>

          {/* Table Filters */}
          <div className="flex flex-wrap items-center gap-2">
            <div className="relative">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                placeholder="Search ID, address..."
                className="pl-8 pr-3 py-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:border-emerald-500"
              />
            </div>

            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="p-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700"
            >
              <option value="all">All Statuses</option>
              <option value="submitted">Submitted</option>
              <option value="under verification">Under Verification</option>
              <option value="worker assigned">Worker Assigned</option>
              <option value="in progress">In Progress</option>
              <option value="resolved">Resolved</option>
            </select>

            <select
              value={priorityFilter}
              onChange={(e) => setPriorityFilter(e.target.value)}
              className="p-1.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-700"
            >
              <option value="all">All Priorities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
        </div>

        {/* Table */}
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 text-slate-500 uppercase tracking-wider font-semibold border-y border-slate-200 text-[10px]">
              <tr>
                <th className="py-3 px-3">Complaint ID</th>
                <th className="py-3 px-3">Citizen & Location</th>
                <th className="py-3 px-3">Category</th>
                <th className="py-3 px-3">Priority</th>
                <th className="py-3 px-3">Status</th>
                <th className="py-3 px-3">Assigned Worker</th>
                <th className="py-3 px-3 text-right">Admin Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredReports.map(report => (
                <tr key={report.id} className="hover:bg-slate-50/70 transition-colors">
                  <td className="py-3.5 px-3 font-mono font-bold text-slate-900 whitespace-nowrap">
                    #{report.complaint_id}
                  </td>
                  <td className="py-3.5 px-3 max-w-xs">
                    <div className="font-semibold text-slate-800">{report.user_name}</div>
                    <div className="text-[11px] text-slate-500 truncate">{report.address}</div>
                  </td>
                  <td className="py-3.5 px-3 whitespace-nowrap font-medium text-slate-700">
                    {report.category_name}
                  </td>
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        report.priority === 'critical'
                          ? 'bg-rose-100 text-rose-800'
                          : report.priority === 'high'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {report.priority}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 whitespace-nowrap">
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                        report.status === 'Resolved'
                          ? 'bg-emerald-100 text-emerald-800 border-emerald-200'
                          : report.status === 'In Progress' || report.status === 'Worker Assigned'
                          ? 'bg-blue-100 text-blue-800 border-blue-200'
                          : 'bg-amber-100 text-amber-800 border-amber-200'
                      }`}
                    >
                      {report.status}
                    </span>
                  </td>
                  <td className="py-3.5 px-3 text-slate-600 whitespace-nowrap">
                    {report.assigned_worker_name || 'Unassigned'}
                  </td>
                  <td className="py-3.5 px-3 text-right whitespace-nowrap space-x-1.5">
                    {report.status !== 'Resolved' && (
                      <>
                        <button
                          onClick={() => setAssigningReport(report)}
                          className="px-2.5 py-1 bg-emerald-50 hover:bg-emerald-100 text-emerald-800 rounded-lg font-semibold text-[11px] transition-colors"
                        >
                          Assign Worker
                        </button>
                        <button
                          onClick={() => handleStatusChange(report.id, 'Resolved')}
                          className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-semibold text-[11px] transition-colors"
                        >
                          Mark Cleaned
                        </button>
                      </>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Assign Worker Modal */}
      {assigningReport && (
        <div className="fixed inset-0 z-50 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl border border-slate-200 p-6 max-w-md w-full shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">
                  Assign Sanitation Worker
                </h3>
                <span className="text-xs text-slate-500 font-mono">
                  Complaint #{assigningReport.complaint_id}
                </span>
              </div>
              <button
                onClick={() => setAssigningReport(null)}
                className="p-1 rounded-lg hover:bg-slate-100 text-slate-400"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <p className="text-xs text-slate-600">
              Select a municipal sanitation worker or compaction vehicle to dispatch to{' '}
              <strong className="text-slate-900">{assigningReport.address}</strong>.
            </p>

            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                Available Sanitation Teams
              </label>
              <select
                value={selectedWorkerId}
                onChange={(e) => setSelectedWorkerId(e.target.value)}
                className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl font-medium text-slate-800"
              >
                {MUNICIPAL_WORKERS.map(w => (
                  <option key={w.id} value={w.id}>{w.name}</option>
                ))}
              </select>
            </div>

            <div className="flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setAssigningReport(null)}
                className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-semibold"
              >
                Cancel
              </button>
              <button
                onClick={handleAssignWorker}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs"
              >
                Confirm Dispatch
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
