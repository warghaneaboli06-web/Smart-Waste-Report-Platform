import React from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  AlertTriangle,
  FileText,
  Building2,
  Truck,
  ShieldAlert,
  Users,
  CheckCircle2,
  ArrowRight,
  Sparkles,
  Recycle,
  BarChart2,
  Camera,
  MapPin,
  Clock,
  LogIn,
  UserPlus
} from 'lucide-react';
import { UserRole } from '../types.ts';

export const LandingPage: React.FC = () => {
  const { loginAs, setCurrentPage } = useAuth();

  const handleRoleSelect = (role: UserRole) => {
    loginAs(role);
  };

  return (
    <div className="min-h-screen text-slate-900 pb-16">
      {/* Hero Welcome Section */}
      <section className="relative overflow-hidden pt-12 pb-16 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="relative z-10 text-center max-w-3xl mx-auto">
          <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-emerald-100/90 border border-emerald-300 text-emerald-900 text-xs font-bold mb-6 shadow-xs">
            <Sparkles className="w-3.5 h-3.5 text-emerald-700" />
            Welcome to EcoTrack • Municipal Smart Waste Portal
          </div>

          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black text-slate-900 tracking-tight leading-tight">
            Clean City. Healthy Future.{' '}
            <span className="bg-gradient-to-r from-emerald-600 to-teal-700 bg-clip-text text-transparent block sm:inline">
              Welcome to EcoTrack.
            </span>
          </h1>

          <p className="mt-5 text-base sm:text-lg text-slate-700 max-w-2xl mx-auto leading-relaxed font-medium">
            Welcome to the civic waste management system. Please sign in to your account to report garbage piles, track municipal collection routes, and keep our neighborhoods clean.
          </p>

          {/* Primary Action Buttons: Sign In / Register / Report / Track */}
          <div className="mt-8 flex flex-wrap items-center justify-center gap-3.5">
            <button
              id="btn-hero-login"
              onClick={() => setCurrentPage('auth')}
              className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-bold text-sm shadow-lg shadow-emerald-600/30 flex items-center gap-2.5 transition-all hover:scale-105"
            >
              <LogIn className="w-4 h-4 text-emerald-200" />
              Sign In to Your Account
            </button>

            <button
              id="btn-hero-register"
              onClick={() => setCurrentPage('auth')}
              className="px-6 py-3.5 bg-white hover:bg-slate-50 text-slate-800 border border-slate-300 rounded-2xl font-bold text-sm shadow-xs flex items-center gap-2.5 transition-all hover:scale-105"
            >
              <UserPlus className="w-4 h-4 text-emerald-600" />
              Register New Citizen
            </button>

            <button
              id="btn-hero-report"
              onClick={() => setCurrentPage('report_waste')}
              className="px-6 py-3.5 bg-amber-50 hover:bg-amber-100 text-amber-900 border border-amber-300 rounded-2xl font-bold text-sm shadow-xs flex items-center gap-2.5 transition-all hover:scale-105"
            >
              <AlertTriangle className="w-4 h-4 text-amber-600" />
              Report Waste
            </button>

            <button
              id="btn-hero-track"
              onClick={() => setCurrentPage('my_reports')}
              className="px-6 py-3.5 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-bold text-sm shadow-md flex items-center gap-2.5 transition-all hover:scale-105"
            >
              <FileText className="w-4 h-4 text-blue-400" />
              Track Complaint Status
            </button>
          </div>
        </div>

        {/* Live Counters */}
        <div className="mt-14 grid grid-cols-2 sm:grid-cols-4 gap-4 max-w-4xl mx-auto">
          {[
            { label: 'Garbage Reports Filed', count: '12,450+', icon: AlertTriangle, color: 'text-amber-600', bg: 'bg-amber-50' },
            { label: 'Active Citizens', count: '5,240', icon: Users, color: 'text-blue-600', bg: 'bg-blue-50' },
            { label: 'Spots Cleaned', count: '10,890', icon: CheckCircle2, color: 'text-emerald-600', bg: 'bg-emerald-50' },
            { label: 'Average Cleanup Time', count: '< 4 Hours', icon: Clock, color: 'text-purple-600', bg: 'bg-purple-50' },
          ].map((stat, idx) => {
            const Icon = stat.icon;
            return (
              <div key={idx} className="bg-white/90 backdrop-blur-sm p-4 sm:p-5 rounded-2xl border border-slate-200 shadow-xs text-center">
                <div className={`w-10 h-10 mx-auto mb-2 rounded-xl ${stat.bg} flex items-center justify-center ${stat.color}`}>
                  <Icon className="w-5 h-5" />
                </div>
                <div className="text-xl sm:text-2xl font-black text-slate-900">{stat.count}</div>
                <div className="text-xs text-slate-500 font-medium mt-0.5">{stat.label}</div>
              </div>
            );
          })}
        </div>
      </section>

      {/* How it Works - 3 Simple Steps */}
      <section className="py-12 bg-white/80 backdrop-blur-sm border-y border-slate-200/80 px-4 sm:px-6 lg:px-8">
        <div className="max-w-6xl mx-auto">
          <div className="text-center max-w-xl mx-auto mb-10">
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-700 bg-emerald-100/70 px-3 py-1 rounded-full">
              Easy 3-Step Process
            </span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
              How Waste Management Works
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 mt-1">
              From complaint registration to field truck dispatch and verified clean spot.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Step 1 */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center font-black text-lg mb-4 shadow-md shadow-emerald-500/20">
                1
              </div>
              <h3 className="font-bold text-base text-slate-900">Report the Waste</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Take a quick photo, select waste category, and provide the street location or GPS pin.
              </p>
            </div>

            {/* Step 2 */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-blue-600 text-white flex items-center justify-center font-black text-lg mb-4 shadow-md shadow-blue-500/20">
                2
              </div>
              <h3 className="font-bold text-base text-slate-900">Worker Dispatched</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Municipality Admin reviews the alert and automatically assigns the nearest Collection Worker truck.
              </p>
            </div>

            {/* Step 3 */}
            <div className="bg-slate-50 p-6 rounded-2xl border border-slate-200 flex flex-col items-center text-center">
              <div className="w-12 h-12 rounded-2xl bg-teal-600 text-white flex items-center justify-center font-black text-lg mb-4 shadow-md shadow-teal-500/20">
                3
              </div>
              <h3 className="font-bold text-base text-slate-900">Spot Cleaned & Verified</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Collection Worker clears the garbage, uploads an After Photo, and the complaint is marked Resolved.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Role-Based Official Portals Section */}
      <section className="py-14 px-4 sm:px-6 lg:px-8 max-w-7xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <span className="text-xs font-bold uppercase tracking-wider text-slate-700 bg-slate-200/80 px-3 py-1 rounded-full">
            Municipal Operation Portals
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mt-2">
            Sign In to Your Specific Portal
          </h2>
          <p className="text-xs sm:text-sm text-slate-600 mt-1">
            Access dedicated dashboards designed for citizens and official municipal roles.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {/* Citizen */}
          <div className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-emerald-300 transition-all flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4">
                <Users className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">1. Citizen Portal</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Sign in with your email or create an account to report garbage piles, track cleanup progress, and earn rewards.
              </p>
            </div>
            <button
              onClick={() => setCurrentPage('auth')}
              className="mt-6 w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              Citizen Login / Register <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Admin / Municipality */}
          <div className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-blue-300 transition-all flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-blue-100 text-blue-700 flex items-center justify-center mb-4">
                <Building2 className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">2. Municipality Admin</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Command center for reviewing incoming citizen complaints, dispatching trucks, and tracking resolution.
              </p>
            </div>
            <button
              onClick={() => handleRoleSelect('admin')}
              className="mt-6 w-full py-2.5 bg-blue-600 hover:bg-blue-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              Admin Portal Login <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Collection Worker */}
          <div className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-amber-300 transition-all flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-amber-100 text-amber-700 flex items-center justify-center mb-4">
                <Truck className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">3. Collection Worker</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Field task board. View assigned collection routes, navigate to spots, and submit cleaning proof photos.
              </p>
            </div>
            <button
              onClick={() => handleRoleSelect('worker')}
              className="mt-6 w-full py-2.5 bg-amber-600 hover:bg-amber-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              Worker Portal Login <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>

          {/* Enforcement Officer */}
          <div className="bg-white/95 backdrop-blur-sm p-6 rounded-2xl border border-slate-200 shadow-sm hover:shadow-md hover:border-purple-300 transition-all flex flex-col justify-between">
            <div>
              <div className="w-12 h-12 rounded-xl bg-purple-100 text-purple-700 flex items-center justify-center mb-4">
                <ShieldAlert className="w-6 h-6" />
              </div>
              <h3 className="text-base font-bold text-slate-900">4. Enforcement Officer</h3>
              <p className="text-xs text-slate-600 mt-2 leading-relaxed">
                Investigate illegal dumping spots, scan violator vehicle plates (ALPR), and issue municipal penalty challans.
              </p>
            </div>
            <button
              onClick={() => handleRoleSelect('enforcement')}
              className="mt-6 w-full py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold transition-colors flex items-center justify-center gap-1.5 shadow-sm"
            >
              Enforcement Portal Login <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
};
