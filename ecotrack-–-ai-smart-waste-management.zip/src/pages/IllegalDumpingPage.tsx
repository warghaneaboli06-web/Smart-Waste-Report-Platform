import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  ShieldAlert,
  Camera,
  Upload,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  FileText,
  MapPin,
  Clock,
  Car,
  Filter,
  Eye,
  XCircle,
  Award
} from 'lucide-react';
import {
  fetchViolations,
  submitViolationReport,
  verifyViolationAction,
  ocrPlateImage
} from '../services/api.ts';
import { ViolationRecord } from '../types.ts';

const SAMPLE_TRUCK_PHOTOS = [
  {
    name: 'Tata Ace Mini-Truck dumping rubble',
    url: 'https://images.unsplash.com/photo-1601584115197-04ecc0da31d7?w=600&auto=format&fit=crop&q=80',
    plate: 'MH12AB1234',
    location: 'Hadapsar Bypass Road Sector 9'
  },
  {
    name: 'Commercial Flatbed with plastic waste',
    url: 'https://images.unsplash.com/photo-1519003722824-194d4455a60c?w=600&auto=format&fit=crop&q=80',
    plate: 'MH14DE5678',
    location: 'Old Pune-Mumbai Highway Service Lane'
  }
];

export const IllegalDumpingPage: React.FC = () => {
  const { user, role, updateUserContext } = useAuth();
  const [violations, setViolations] = useState<ViolationRecord[]>([]);
  const [selectedViolation, setSelectedViolation] = useState<ViolationRecord | null>(null);
  const [activeTab, setActiveTab] = useState<'queue' | 'report'>('queue');
  const [loading, setLoading] = useState(true);

  // New report form state
  const [vehicleImageUrl, setVehicleImageUrl] = useState('');
  const [wasteImageUrl, setWasteImageUrl] = useState('');
  const [vehicleNumber, setVehicleNumber] = useState('');
  const [locationAddress, setLocationAddress] = useState('Hadapsar Bypass Road, Sector 9');
  const [notes, setNotes] = useState('');
  const [ocrConfidence, setOcrConfidence] = useState(96.4);
  const [isOcrRunning, setIsOcrRunning] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [officerNote, setOfficerNote] = useState('');

  const isOfficerOrAdmin = role === 'admin' || role === 'enforcement';

  useEffect(() => {
    loadViolations();
  }, []);

  const loadViolations = async () => {
    try {
      setLoading(true);
      const data = await fetchViolations();
      setViolations(data || []);
      if (data?.length > 0 && !selectedViolation) {
        setSelectedViolation(data[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleRunOcr = async (imgUrl: string) => {
    setIsOcrRunning(true);
    try {
      const res = await ocrPlateImage(imgUrl);
      if (res.license_plate) {
        setVehicleNumber(res.license_plate);
        setOcrConfidence(res.confidence);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setIsOcrRunning(false);
    }
  };

  const handleSelectSampleTruck = (sample: typeof SAMPLE_TRUCK_PHOTOS[0]) => {
    setVehicleImageUrl(sample.url);
    setWasteImageUrl(sample.url);
    setLocationAddress(sample.location);
    handleRunOcr(sample.url);
  };

  const handleSubmitReport = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!vehicleImageUrl || !vehicleNumber) {
      alert('Vehicle image and detected plate number are required');
      return;
    }

    setSubmitting(true);
    try {
      await submitViolationReport({
        reporterId: user?.id || 'usr_citizen_1',
        vehicleNumber,
        vehicleImageUrl,
        wasteImageUrl: wasteImageUrl || vehicleImageUrl,
        locationAddress,
        latitude: 18.5195,
        longitude: 73.8530,
        ocrConfidence,
        notes
      });

      alert('Violation report successfully filed for municipal officer verification! Earn +30 points once verified.');
      if (user) {
        updateUserContext({ credit_points: (user.credit_points || 340) + 10 });
      }
      setActiveTab('queue');
      loadViolations();
    } catch (err: any) {
      alert(err.message || 'Failed to submit report');
    } finally {
      setSubmitting(false);
    }
  };

  const handleOfficerAction = async (action: 'warning' | 'fine' | 'restrict' | 'clear') => {
    if (!selectedViolation) return;
    try {
      const res = await verifyViolationAction(
        selectedViolation.id,
        action,
        officerNote || `Officer applied ${action}`,
        user?.name || 'Municipal Enforcement Officer'
      );
      setSelectedViolation(res.violation);
      setOfficerNote('');
      loadViolations();
    } catch (err: any) {
      alert(err.message);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-purple-50 text-purple-800 border border-purple-200 text-xs font-semibold mb-2">
            <ShieldAlert className="w-3.5 h-3.5 text-purple-600" />
            Solid Waste Bylaw Enforcement & ALPR
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            Illegal Dumping Enforcement & License Plate OCR
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Combat unauthorized commercial dumping with AI vehicle recognition, evidentiary audit trails, and legal penalties.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveTab('queue')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
              activeTab === 'queue'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            Evidence Queue ({violations.length})
          </button>
          <button
            onClick={() => setActiveTab('report')}
            className={`px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
              activeTab === 'report'
                ? 'bg-purple-600 text-white shadow-xs'
                : 'bg-white text-slate-700 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            + File Violation Report
          </button>
        </div>
      </div>

      {/* Tab 1: Evidence Queue & Officer Actions */}
      {activeTab === 'queue' && (
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Violations List */}
          <div className="space-y-3 max-h-[720px] overflow-y-auto pr-1">
            {violations.map(v => {
              const isSelected = selectedViolation?.id === v.id;
              return (
                <div
                  key={v.id}
                  onClick={() => setSelectedViolation(v)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-purple-500 bg-purple-50/40 shadow-xs ring-1 ring-purple-500/30'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono text-xs font-black text-slate-900 bg-slate-100 px-2 py-0.5 rounded">
                      {v.vehicle_number}
                    </span>
                    <span
                      className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${
                        v.status.includes('Fine')
                          ? 'bg-rose-100 text-rose-800 border-rose-200'
                          : v.status.includes('Warning')
                          ? 'bg-amber-100 text-amber-800 border-amber-200'
                          : 'bg-purple-100 text-purple-800 border-purple-200'
                      }`}
                    >
                      {v.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 mt-3">
                    <img
                      src={v.vehicle_image_url}
                      alt="Vehicle"
                      className="w-16 h-12 rounded-lg object-cover border border-slate-200 shrink-0"
                    />
                    <div className="truncate">
                      <div className="text-xs font-bold text-slate-800 truncate">
                        {v.location_address}
                      </div>
                      <div className="text-[10px] text-slate-500 mt-0.5">
                        OCR Confidence: <strong className="text-emerald-700">{v.ocr_confidence}%</strong>
                      </div>
                      <div className="text-[10px] text-slate-400 mt-0.5">
                        Case: #{v.case_number}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Detailed Evidence & Verification Console */}
          <div className="lg:col-span-2">
            {selectedViolation ? (
              <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
                {/* Header */}
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-mono text-sm font-black bg-slate-900 text-white px-2.5 py-1 rounded-lg">
                        {selectedViolation.vehicle_number}
                      </span>
                      <span className="text-xs font-bold uppercase text-purple-700 bg-purple-50 px-2 py-0.5 rounded border border-purple-200">
                        Case #{selectedViolation.case_number}
                      </span>
                    </div>
                    <p className="text-xs text-slate-600 mt-2 flex items-center gap-1.5">
                      <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                      {selectedViolation.location_address}
                    </p>
                  </div>

                  <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-right text-xs">
                    <div className="text-slate-400 text-[10px]">Restriction Standing</div>
                    <div className="font-extrabold text-slate-900 mt-0.5">
                      {selectedViolation.restriction_status}
                    </div>
                    {selectedViolation.penalty_amount > 0 && (
                      <div className="text-xs font-black text-rose-600 mt-0.5">
                        Penalty: ₹{selectedViolation.penalty_amount.toLocaleString()}
                      </div>
                    )}
                  </div>
                </div>

                {/* High-Resolution Side-by-Side Photo Evidence */}
                <div>
                  <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                    Evidentiary Image Logs
                  </h3>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-700">1. Vehicle & License Crop</span>
                        <span className="text-[10px] text-emerald-700 font-bold bg-emerald-50 px-1.5 py-0.5 rounded">
                          ALPR OCR {selectedViolation.ocr_confidence}%
                        </span>
                      </div>
                      <div className="rounded-2xl overflow-hidden border border-slate-200 aspect-video bg-slate-100">
                        <img
                          src={selectedViolation.vehicle_image_url}
                          alt="Vehicle"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>

                    <div className="space-y-1.5">
                      <div className="flex items-center justify-between text-xs">
                        <span className="font-bold text-slate-700">2. Waste Pile Debris Scene</span>
                        <span className="text-[10px] text-slate-400">Timestamp Matched</span>
                      </div>
                      <div className="rounded-2xl overflow-hidden border border-slate-200 aspect-video bg-slate-100">
                        <img
                          src={selectedViolation.waste_image_url}
                          alt="Waste Pile"
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  </div>
                </div>

                {/* Legal & Incident Summary */}
                <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200/80 grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div>
                    <span className="text-slate-400 text-[10px]">Reported By:</span>
                    <div className="font-bold text-slate-800 mt-0.5">{selectedViolation.reporter_name}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">Violation Type:</span>
                    <div className="font-bold text-slate-800 mt-0.5">{selectedViolation.violation_type}</div>
                  </div>
                  <div>
                    <span className="text-slate-400 text-[10px]">Verified By Officer:</span>
                    <div className="font-bold text-slate-800 mt-0.5">{selectedViolation.verified_by || 'Awaiting Review'}</div>
                  </div>
                </div>

                {/* Officer Authorized Action Panel */}
                <div className="pt-4 border-t border-slate-200 space-y-3">
                  <div className="flex items-center justify-between">
                    <h4 className="text-xs font-bold text-slate-900 uppercase tracking-wider flex items-center gap-1.5">
                      <ShieldAlert className="w-4 h-4 text-purple-600" />
                      Authorized Municipal Officer Actions
                    </h4>
                    <span className="text-[11px] text-purple-700 font-semibold">
                      Enforcement Officer or Admin Only
                    </span>
                  </div>

                  <input
                    type="text"
                    value={officerNote}
                    onChange={(e) => setOfficerNote(e.target.value)}
                    placeholder="Enter official enforcement remark (e.g. Commercial dumper caught dumping in residential zone...)"
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-purple-500/20 focus:border-purple-500 text-slate-800"
                  />

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    <button
                      onClick={() => handleOfficerAction('warning')}
                      className="py-2.5 bg-amber-500 hover:bg-amber-600 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                    >
                      Issue Warning
                    </button>
                    <button
                      onClick={() => handleOfficerAction('fine')}
                      className="py-2.5 bg-rose-600 hover:bg-rose-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                    >
                      Levy ₹2,000 Fine
                    </button>
                    <button
                      onClick={() => handleOfficerAction('restrict')}
                      className="py-2.5 bg-purple-700 hover:bg-purple-800 text-white rounded-xl text-xs font-bold shadow-xs transition-colors"
                    >
                      Restrict Municipal Entry
                    </button>
                    <button
                      onClick={() => handleOfficerAction('clear')}
                      className="py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl text-xs font-bold transition-colors"
                    >
                      Clear / Dismiss
                    </button>
                  </div>
                </div>
              </div>
            ) : null}
          </div>
        </div>
      )}

      {/* Tab 2: File New Violation Report with AI OCR */}
      {activeTab === 'report' && (
        <form
          onSubmit={handleSubmitReport}
          className="max-w-3xl mx-auto bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6"
        >
          <div>
            <h3 className="text-base font-bold text-slate-900">
              Submit Illegal Waste Dumping Photographic Evidence
            </h3>
            <p className="text-xs text-slate-500 mt-1">
              Our automated License Plate Recognition (ALPR) system extracts vehicle numbers from photos automatically.
            </p>
          </div>

          {/* Quick Sample Selector for Easy Testing */}
          <div className="p-3 bg-purple-50/60 rounded-2xl border border-purple-100">
            <span className="text-xs font-bold text-purple-900">
              Quick Test: Select sample violator commercial truck photo:
            </span>
            <div className="grid grid-cols-2 gap-3 mt-2">
              {SAMPLE_TRUCK_PHOTOS.map((sample, idx) => (
                <div
                  key={idx}
                  onClick={() => handleSelectSampleTruck(sample)}
                  className="p-2 bg-white rounded-xl border border-purple-200 hover:border-purple-500 cursor-pointer transition-all flex items-center gap-2.5"
                >
                  <img src={sample.url} alt={sample.name} className="w-14 h-10 object-cover rounded-lg" />
                  <div className="text-left truncate">
                    <div className="text-xs font-bold text-slate-800 truncate">{sample.name}</div>
                    <div className="text-[10px] text-purple-700 font-mono font-bold">{sample.plate}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Photo Preview & OCR Output */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-2">
                Truck / Vehicle Photo <span className="text-rose-500">*</span>
              </label>
              {vehicleImageUrl ? (
                <div className="relative rounded-2xl overflow-hidden border border-slate-200 aspect-video">
                  <img src={vehicleImageUrl} alt="Truck" className="w-full h-full object-cover" />
                  <button
                    type="button"
                    onClick={() => setVehicleImageUrl('')}
                    className="absolute top-2 right-2 bg-slate-900/80 text-white text-[11px] px-2 py-0.5 rounded-md"
                  >
                    Change
                  </button>
                </div>
              ) : (
                <div className="border-2 border-dashed border-slate-300 rounded-2xl p-6 text-center text-xs text-slate-500">
                  Select a sample above or paste an image URL
                </div>
              )}
            </div>

            <div className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  AI-Extracted License Plate
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={vehicleNumber}
                    onChange={(e) => setVehicleNumber(e.target.value)}
                    placeholder="e.g. MH12AB1234"
                    className="w-full p-2.5 font-mono text-sm font-extrabold uppercase bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-purple-500/20"
                  />
                  <button
                    type="button"
                    onClick={() => vehicleImageUrl && handleRunOcr(vehicleImageUrl)}
                    disabled={isOcrRunning || !vehicleImageUrl}
                    className="px-3 py-2.5 bg-purple-600 hover:bg-purple-700 text-white rounded-xl text-xs font-bold shrink-0 disabled:opacity-50"
                  >
                    {isOcrRunning ? 'OCR...' : 'Run OCR'}
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
                  Incident Location Address
                </label>
                <input
                  type="text"
                  value={locationAddress}
                  onChange={(e) => setLocationAddress(e.target.value)}
                  className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1">
              Additional Evidence Observations
            </label>
            <textarea
              rows={2}
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              placeholder="Dumped construction debris on vacant land, driver fled when approached..."
              className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
            />
          </div>

          <div className="pt-2">
            <button
              type="submit"
              disabled={submitting}
              className="w-full py-3 bg-purple-600 hover:bg-purple-700 text-white font-bold rounded-2xl text-xs shadow-md shadow-purple-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
            >
              {submitting ? 'Submitting Case...' : 'Submit Evidence File to Municipal Enforcement'}
            </button>
          </div>
        </form>
      )}
    </div>
  );
};
