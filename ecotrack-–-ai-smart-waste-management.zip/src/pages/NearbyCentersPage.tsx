import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  MapPin,
  Navigation,
  Clock,
  Phone,
  Layers,
  Search,
  CheckCircle2,
  AlertCircle,
  Building2,
  Trash2,
  Filter
} from 'lucide-react';
import { InteractiveMap } from '../components/InteractiveMap.tsx';
import { fetchWasteCenters } from '../services/api.ts';
import { WasteCenter } from '../types.ts';

export const NearbyCentersPage: React.FC = () => {
  const [centers, setCenters] = useState<WasteCenter[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCenters();
  }, []);

  const loadCenters = async () => {
    try {
      setLoading(true);
      const data = await fetchWasteCenters();
      setCenters(data || []);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = centers.filter(c => {
    const matchesSearch =
      c.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.address.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.accepted_categories.some(cat => cat.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesType =
      selectedType === 'all' ||
      (selectedType === 'recycling' && (c.facility_type === 'Recycling Center' || c.facility_type === 'Dry Waste Collection Point')) ||
      (selectedType === 'ewaste' && c.facility_type === 'E-Waste Center') ||
      (selectedType === 'smart_bins' && c.facility_type === 'Smart Public Bin') ||
      (selectedType === 'composting' && c.facility_type === 'Wet Waste Composting Facility');

    return matchesSearch && matchesType;
  });

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold mb-2">
          <MapPin className="w-3.5 h-3.5 text-emerald-600" />
          Smart City Geolocation Grid
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Nearby Waste & Recycling Centers
        </h1>
        <p className="text-slate-600 text-xs sm:text-sm mt-1">
          Locate municipal recycling hubs, e-waste drop kiosks, composting depots, and smart solar compactor bins.
        </p>
      </div>

      {/* Interactive Map Component */}
      <InteractiveMap centers={filtered} height="460px" />

      {/* Directory Search & Filters */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by center name, street, or accepted waste..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto py-0.5">
          <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Facility:
          </span>
          {[
            { id: 'all', label: 'All (6)' },
            { id: 'recycling', label: 'Recycling Centers' },
            { id: 'ewaste', label: 'E-Waste Depots' },
            { id: 'smart_bins', label: 'Smart Public Bins' },
            { id: 'composting', label: 'Composting' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setSelectedType(f.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                selectedType === f.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Directory Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {filtered.map(c => (
          <div
            key={c.id}
            className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs hover:border-emerald-300 hover:shadow-md transition-all flex flex-col justify-between"
          >
            <div className="space-y-3">
              <div className="flex items-start justify-between gap-2">
                <span className="text-[10px] font-bold uppercase tracking-wider px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-700 border border-emerald-200">
                  {c.facility_type}
                </span>
                <span className="text-xs font-black text-emerald-600">
                  {c.distance_km || 1.2} km
                </span>
              </div>

              <div>
                <h3 className="text-sm font-bold text-slate-900">{c.name}</h3>
                <p className="text-xs text-slate-500 mt-1 flex items-start gap-1">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0 mt-0.5" />
                  {c.address}
                </p>
              </div>

              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 grid grid-cols-2 gap-2 text-xs">
                <div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-emerald-600" /> Timing
                  </div>
                  <div className="font-semibold text-slate-800 text-[11px] mt-0.5 truncate">{c.operating_hours}</div>
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 flex items-center gap-1">
                    <Phone className="w-3 h-3 text-emerald-600" /> Phone
                  </div>
                  <div className="font-semibold text-slate-800 text-[11px] mt-0.5 truncate">{c.contact_phone}</div>
                </div>
              </div>

              <div>
                <div className="text-[10px] font-bold text-slate-400 uppercase tracking-wider mb-1">
                  Accepted Materials:
                </div>
                <div className="flex flex-wrap gap-1">
                  {c.accepted_categories.map((cat, idx) => (
                    <span
                      key={idx}
                      className="px-2 py-0.5 bg-slate-100 text-slate-700 text-[10px] font-medium rounded-md"
                    >
                      {cat}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
              <span className="text-[11px] text-slate-500 flex items-center gap-1">
                <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
                Capacity: Normal
              </span>
              <button
                onClick={() => alert(`Starting GPS navigation to ${c.name} (${c.address})`)}
                className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold flex items-center gap-1 transition-colors"
              >
                <Navigation className="w-3 h-3" /> Navigate
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
