import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Award,
  Scan,
  AlertTriangle,
  CheckCircle2,
  TrendingUp,
  MapPin,
  Bot,
  Clock,
  ArrowRight,
  Sparkles,
  ShieldCheck,
  ChevronRight,
  Recycle
} from 'lucide-react';
import { fetchMyReports, fetchPointsSummary, fetchWasteCenters } from '../services/api.ts';
import { WasteReport, WasteCenter } from '../types.ts';

export const CitizenDashboard: React.FC = () => {
  const { user, setCurrentPage, setSelectedCategoryForInfo } = useAuth();
  const [reports, setReports] = useState<WasteReport[]>([]);
  const [centers, setCenters] = useState<WasteCenter[]>([]);
  const [pointsData, setPointsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) {
      loadData();
    }
  }, [user]);

  const loadData = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const [reps, pts, cntrs] = await Promise.all([
        fetchMyReports(user.id),
        fetchPointsSummary(user.id),
        fetchWasteCenters()
      ]);
      setReports(reps || []);
      setPointsData(pts);
      setCenters(cntrs || []);
    } catch (err) {
      console.error('Error loading dashboard data', err);
    } finally {
      setLoading(false);
    }
  };

  const resolvedCount = reports.filter(r => r.status === 'Resolved').length;
  const pendingCount = reports.filter(r => r.status !== 'Resolved' && r.status !== 'Rejected').length;

  return (
    <div className="space-y-6 pb-12">
      {/* Welcome Banner */}
      <div className="relative overflow-hidden bg-gradient-to-r from-emerald-700 via-teal-700 to-emerald-900 rounded-3xl p-6 sm:p-8 text-white shadow-lg shadow-emerald-950/10">
        <div className="relative z-10 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/20 text-emerald-200 border border-emerald-400/30 text-xs font-semibold mb-3">
            <Sparkles className="w-3.5 h-3.5 text-emerald-300" />
            Citizen Smart Portal • Pune Municipal Corporation
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold tracking-tight">
            Welcome back, {user?.name || 'Citizen'}!
          </h1>
          <p className="mt-2 text-emerald-100 text-xs sm:text-sm leading-relaxed max-w-xl">
            Your active waste segregation and prompt reporting have kept <strong className="text-white">12.4 kg</strong> of recyclables out of municipal landfills this month.
          </p>

          <div className="mt-5 flex flex-wrap items-center gap-3">
            <button
              id="dash-btn-scan"
              onClick={() => setCurrentPage('waste_scanner')}
              className="px-4 py-2.5 bg-white hover:bg-emerald-50 text-emerald-800 rounded-xl text-xs font-bold shadow-md transition-all flex items-center gap-2"
            >
              <Scan className="w-4 h-4 text-emerald-600" />
              Scan Waste with AI
            </button>
            <button
              id="dash-btn-report"
              onClick={() => setCurrentPage('report_waste')}
              className="px-4 py-2.5 bg-emerald-600/60 hover:bg-emerald-600 text-white border border-emerald-400/30 rounded-xl text-xs font-semibold transition-all flex items-center gap-2"
            >
              <AlertTriangle className="w-4 h-4 text-amber-300" />
              Report Trash Pile
            </button>
          </div>
        </div>

        {/* Decorative background vectors */}
        <div className="absolute right-0 bottom-0 translate-x-12 translate-y-12 w-64 h-64 rounded-full bg-emerald-500/10 pointer-events-none"></div>
        <div className="absolute right-24 top-0 -translate-y-12 w-48 h-48 rounded-full bg-teal-400/10 pointer-events-none"></div>
      </div>

      {/* Top 6 Metric Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3 sm:gap-4">
        {/* Green Score */}
        <div
          onClick={() => setCurrentPage('credit_points')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs cursor-pointer hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-emerald-600">
            <Award className="w-5 h-5" />
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
              +15% mo
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            {user?.green_score || 850}
          </div>
          <div className="text-xs text-slate-500 font-medium">Green Score</div>
        </div>

        {/* Available Points */}
        <div
          onClick={() => setCurrentPage('credit_points')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs cursor-pointer hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-teal-600">
            <TrendingUp className="w-5 h-5" />
            <span className="text-[10px] font-bold text-teal-700 bg-teal-50 px-1.5 py-0.5 rounded">
              Redeem
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            {user?.credit_points || 340}
          </div>
          <div className="text-xs text-slate-500 font-medium">Credit Points</div>
        </div>

        {/* Total Scans */}
        <div
          onClick={() => setCurrentPage('waste_scanner')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs cursor-pointer hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-blue-600">
            <Scan className="w-5 h-5" />
            <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded">
              +5 pts ea
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            34
          </div>
          <div className="text-xs text-slate-500 font-medium">AI Waste Scans</div>
        </div>

        {/* Reports Submitted */}
        <div
          onClick={() => setCurrentPage('my_reports')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs cursor-pointer hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-amber-500">
            <AlertTriangle className="w-5 h-5" />
            <span className="text-[10px] font-bold text-slate-500">Total</span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            {reports.length || 3}
          </div>
          <div className="text-xs text-slate-500 font-medium">Reports Filed</div>
        </div>

        {/* Reports Resolved */}
        <div
          onClick={() => setCurrentPage('my_reports')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs cursor-pointer hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-emerald-600">
            <CheckCircle2 className="w-5 h-5" />
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
              Verified
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            {resolvedCount || 2}
          </div>
          <div className="text-xs text-slate-500 font-medium">Cleaned & Closed</div>
        </div>

        {/* Violations / Standing */}
        <div
          onClick={() => setCurrentPage('illegal_dumping')}
          className="bg-white p-4 rounded-2xl border border-slate-200/90 shadow-xs cursor-pointer hover:border-emerald-400 transition-all"
        >
          <div className="flex items-center justify-between text-emerald-600">
            <ShieldCheck className="w-5 h-5" />
            <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-1.5 py-0.5 rounded">
              0 Fine
            </span>
          </div>
          <div className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
            Clean
          </div>
          <div className="text-xs text-slate-500 font-medium">Civic Standing</div>
        </div>
      </div>

      {/* Main Grid: Quick Actions, Recent Reports, Waste Breakdown, Nearby Center */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 2 Cols: Quick Actions & Recent Complaints */}
        <div className="lg:col-span-2 space-y-6">
          {/* 3 Quick Action Banners */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div
              onClick={() => setCurrentPage('waste_scanner')}
              className="p-4 bg-gradient-to-br from-emerald-50 to-teal-50/50 border border-emerald-200/80 rounded-2xl cursor-pointer hover:shadow-md transition-all group"
            >
              <div className="w-9 h-9 rounded-xl bg-emerald-600 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <Scan className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">Scan Waste Item</h4>
              <p className="text-xs text-slate-500 mt-1">
                Point camera to identify recycling rules & earn +5 points.
              </p>
            </div>

            <div
              onClick={() => setCurrentPage('report_waste')}
              className="p-4 bg-gradient-to-br from-amber-50 to-orange-50/50 border border-amber-200/80 rounded-2xl cursor-pointer hover:shadow-md transition-all group"
            >
              <div className="w-9 h-9 rounded-xl bg-amber-500 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <AlertTriangle className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">Report Litter Pile</h4>
              <p className="text-xs text-slate-500 mt-1">
                Geo-tag unattended garbage for municipal truck dispatch.
              </p>
            </div>

            <div
              onClick={() => setCurrentPage('ai_assistant')}
              className="p-4 bg-gradient-to-br from-blue-50 to-indigo-50/50 border border-blue-200/80 rounded-2xl cursor-pointer hover:shadow-md transition-all group"
            >
              <div className="w-9 h-9 rounded-xl bg-blue-600 text-white flex items-center justify-center mb-3 group-hover:scale-105 transition-transform">
                <Bot className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-sm text-slate-900">EcoTrack AI Bot</h4>
              <p className="text-xs text-slate-500 mt-1">
                Ask how to dispose of batteries, electronics, or toxic chemicals.
              </p>
            </div>
          </div>

          {/* Recent Reports Timeline */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-4">
              <div>
                <h3 className="text-base font-bold text-slate-900">My Recent Reports</h3>
                <p className="text-xs text-slate-500">Live progress of your municipal complaints</p>
              </div>
              <button
                onClick={() => setCurrentPage('my_reports')}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
              >
                View all ({reports.length}) <ChevronRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="space-y-3">
              {reports.slice(0, 3).map(report => (
                <div
                  key={report.id}
                  onClick={() => setCurrentPage('my_reports')}
                  className="p-3.5 rounded-xl border border-slate-100 hover:border-slate-200 hover:bg-slate-50/50 transition-colors cursor-pointer flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3"
                >
                  <div className="flex items-center gap-3">
                    <img
                      src={report.image_url}
                      alt="Waste"
                      className="w-12 h-12 rounded-lg object-cover border border-slate-200 shrink-0"
                    />
                    <div>
                      <div className="flex items-center gap-2">
                        <span className="text-xs font-bold text-slate-900">{report.category_name}</span>
                        <span className="text-[10px] text-slate-400">#{report.complaint_id}</span>
                      </div>
                      <p className="text-xs text-slate-500 line-clamp-1 mt-0.5">{report.address}</p>
                      <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                        <Clock className="w-3 h-3" />
                        {new Date(report.created_at).toLocaleDateString()}
                      </div>
                    </div>
                  </div>

                  <div className="flex items-center gap-3 self-end sm:self-center">
                    <span
                      className={`text-[11px] font-bold px-2.5 py-1 rounded-full ${
                        report.status === 'Resolved'
                          ? 'bg-emerald-100 text-emerald-800'
                          : report.status === 'In Progress' || report.status === 'Worker Assigned'
                          ? 'bg-blue-100 text-blue-800'
                          : 'bg-amber-100 text-amber-800'
                      }`}
                    >
                      {report.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Waste Categories Quick Exploration */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <div>
                <h3 className="text-base font-bold text-slate-900">Waste Segregation Guide</h3>
                <p className="text-xs text-slate-500">Learn color codes and disposal instructions</p>
              </div>
              <button
                onClick={() => setCurrentPage('waste_info')}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold flex items-center gap-1"
              >
                Browse All 10 Categories <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
              {[
                { id: 'cat_organic', name: 'Organic / Wet', color: 'bg-emerald-100 text-emerald-800 border-emerald-200', desc: 'Green Bin' },
                { id: 'cat_plastic', name: 'Dry Plastic', color: 'bg-blue-100 text-blue-800 border-blue-200', desc: 'Blue Bin' },
                { id: 'cat_ewaste', name: 'E-Waste', color: 'bg-purple-100 text-purple-800 border-purple-200', desc: 'Special Drop' },
                { id: 'cat_hazardous', name: 'Hazardous', color: 'bg-rose-100 text-rose-800 border-rose-200', desc: 'Depot Only' },
              ].map(cat => (
                <div
                  key={cat.id}
                  onClick={() => {
                    setSelectedCategoryForInfo(cat.id);
                    setCurrentPage('waste_info');
                  }}
                  className={`p-3 rounded-xl border cursor-pointer hover:scale-102 transition-transform ${cat.color}`}
                >
                  <div className="text-xs font-bold">{cat.name}</div>
                  <div className="text-[10px] opacity-75 mt-0.5">{cat.desc}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Nearest Drop-off & Green Rewards Preview */}
        <div className="space-y-6">
          {/* Nearest Center Widget */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-3">
              <h3 className="text-base font-bold text-slate-900">Nearest Recycling Hub</h3>
              <button
                onClick={() => setCurrentPage('nearby_centers')}
                className="text-xs text-emerald-600 hover:text-emerald-700 font-semibold"
              >
                View Map
              </button>
            </div>

            {centers[0] ? (
              <div className="space-y-3">
                <div className="p-3 bg-emerald-50/60 rounded-xl border border-emerald-100">
                  <div className="flex items-start justify-between">
                    <div>
                      <span className="text-[10px] font-bold text-emerald-800 uppercase tracking-wider bg-white px-2 py-0.5 rounded border border-emerald-200">
                        {centers[0].facility_type}
                      </span>
                      <h4 className="font-bold text-sm text-slate-900 mt-1.5">{centers[0].name}</h4>
                    </div>
                    <span className="text-xs font-extrabold text-emerald-700">1.2 km</span>
                  </div>
                  <p className="text-xs text-slate-500 mt-1">{centers[0].address}</p>
                  <div className="mt-2 text-[11px] text-slate-600 flex items-center gap-1 font-medium">
                    <Clock className="w-3 h-3 text-emerald-600" />
                    Open: {centers[0].operating_hours}
                  </div>
                </div>

                <button
                  onClick={() => setCurrentPage('nearby_centers')}
                  className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs transition-colors flex items-center justify-center gap-1.5"
                >
                  <MapPin className="w-3.5 h-3.5" /> Open Smart Map
                </button>
              </div>
            ) : null}
          </div>

          {/* Green Score Tier Progress */}
          <div className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs">
            <div className="flex items-center justify-between mb-2">
              <h3 className="text-sm font-bold text-slate-900">Green Score Tier</h3>
              <span className="text-xs font-extrabold text-emerald-600">Waste Warrior</span>
            </div>

            <p className="text-xs text-slate-500">
              You are <strong className="text-slate-800">150 points</strong> away from reaching <strong className="text-emerald-700">Clean City Champion</strong>!
            </p>

            <div className="mt-3">
              <div className="w-full bg-slate-100 h-2.5 rounded-full overflow-hidden">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-500"
                  style={{ width: '85%' }}
                ></div>
              </div>
              <div className="flex justify-between text-[10px] text-slate-400 font-semibold mt-1">
                <span>500 pts</span>
                <span>850 / 1000 pts</span>
              </div>
            </div>

            <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="text-slate-600">Municipal Tax Rebate</span>
              <button
                onClick={() => setCurrentPage('credit_points')}
                className="text-emerald-700 font-bold hover:underline"
              >
                Claim (500 pts) →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
