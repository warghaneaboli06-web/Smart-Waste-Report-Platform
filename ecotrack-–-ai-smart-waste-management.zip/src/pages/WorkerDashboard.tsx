import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Truck,
  CheckSquare,
  Navigation,
  Camera,
  Upload,
  CheckCircle2,
  Clock,
  MapPin,
  AlertTriangle,
  ArrowRight,
  ShieldCheck,
  Calendar
} from 'lucide-react';
import {
  fetchWorkerTasks,
  updateWorkerTaskStatus,
  uploadCleaningProof
} from '../services/api.ts';

const SAMPLE_CLEANED_PHOTOS = [
  'https://images.unsplash.com/photo-1542601906990-b4d3fb778b09?w=600&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1518495973542-4542c06a5843?w=600&auto=format&fit=crop&q=80',
  'https://images.unsplash.com/photo-1513836279014-a89f7a76ae86?w=600&auto=format&fit=crop&q=80'
];

export const WorkerDashboard: React.FC = () => {
  const { user } = useAuth();
  const [tasks, setTasks] = useState<any[]>([]);
  const [selectedTask, setSelectedTask] = useState<any | null>(null);
  const [afterPhotoUrl, setAfterPhotoUrl] = useState('');
  const [workerNotes, setWorkerNotes] = useState('');
  const [uploading, setUploading] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTasks();
  }, []);

  const loadTasks = async () => {
    try {
      setLoading(true);
      const data = await fetchWorkerTasks();
      setTasks(data || []);
      if (data?.length > 0 && !selectedTask) {
        setSelectedTask(data[0]);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  };

  const handleStatusUpdate = async (status: string) => {
    if (!selectedTask) return;
    try {
      await updateWorkerTaskStatus(selectedTask.id, status, `Worker set task to ${status}`);
      loadTasks();
    } catch (e) {
      console.error(e);
    }
  };

  const handleUploadProof = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedTask || !afterPhotoUrl) {
      alert('Please upload or select an after-cleaning proof photo');
      return;
    }

    setUploading(true);
    try {
      await uploadCleaningProof(selectedTask.id, afterPhotoUrl, workerNotes || 'Area swept, waste lifted to compactor truck.');
      alert('Cleaning proof submitted successfully! Report marked Resolved.');
      setAfterPhotoUrl('');
      setWorkerNotes('');
      loadTasks();
    } catch (err: any) {
      alert(err.message || 'Failed to upload proof');
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-amber-50 text-amber-800 border border-amber-200 text-xs font-semibold mb-2">
          <Truck className="w-3.5 h-3.5 text-amber-600" />
          Field Sanitation & Compactor Unit
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Assigned Waste Clearance Tasks
        </h1>
        <p className="text-slate-600 text-xs sm:text-sm mt-1">
          Review dispatched complaint locations, update progress, and upload photographic verification after clearing.
        </p>
      </div>

      {/* Main Grid: Task Cards & Action Console */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Task Cards List */}
        <div className="space-y-3 max-h-[720px] overflow-y-auto pr-1">
          {tasks.map(task => {
            const isSelected = selectedTask?.id === task.id;
            return (
              <div
                key={task.id}
                onClick={() => setSelectedTask(task)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-amber-500 bg-amber-50/40 shadow-xs ring-1 ring-amber-500/30'
                    : 'border-slate-200 bg-white hover:border-slate-300'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <span className="font-mono text-xs font-black text-slate-800 bg-slate-100 px-2 py-0.5 rounded">
                    #{task.complaint_id}
                  </span>
                  <span
                    className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                      task.status === 'Completed'
                        ? 'bg-emerald-100 text-emerald-800'
                        : task.status === 'Cleaning'
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-blue-100 text-blue-800'
                    }`}
                  >
                    {task.status}
                  </span>
                </div>

                <div className="flex items-center gap-3 mt-3">
                  <img
                    src={task.before_photo_url}
                    alt="Task"
                    className="w-14 h-14 rounded-xl object-cover border border-slate-200 shrink-0"
                  />
                  <div className="truncate">
                    <div className="text-xs font-bold text-slate-900 truncate">{task.category_name}</div>
                    <p className="text-[11px] text-slate-500 truncate mt-0.5">{task.address}</p>
                    <span
                      className={`text-[9px] font-bold uppercase px-1.5 py-0.2 rounded mt-1 inline-block ${
                        task.priority === 'critical' ? 'bg-rose-100 text-rose-800' : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {task.priority} Priority
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* Task Details & Clean-up Verification Console */}
        <div className="lg:col-span-2">
          {selectedTask ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-bold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                      Complaint #{selectedTask.complaint_id}
                    </span>
                    <span className="text-xs font-bold uppercase px-2.5 py-0.5 rounded bg-amber-100 text-amber-800">
                      {selectedTask.status}
                    </span>
                  </div>
                  <h2 className="text-xl font-black text-slate-900 mt-2">
                    {selectedTask.category_name}
                  </h2>
                  <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    {selectedTask.address}
                  </p>
                </div>

                <button
                  onClick={() => alert(`Navigating via GPS to ${selectedTask.address}`)}
                  className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs flex items-center gap-1.5 transition-colors self-start"
                >
                  <Navigation className="w-3.5 h-3.5" /> Start Navigation
                </button>
              </div>

              {/* Status Stepper Actions */}
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-2">
                  Update Task Progression
                </h3>
                <div className="grid grid-cols-3 gap-2">
                  <button
                    onClick={() => handleStatusUpdate('Accepted')}
                    className="py-2 bg-blue-50 hover:bg-blue-100 text-blue-800 rounded-xl text-xs font-bold border border-blue-200 transition-colors"
                  >
                    1. Accept Task
                  </button>
                  <button
                    onClick={() => handleStatusUpdate('On the Way')}
                    className="py-2 bg-indigo-50 hover:bg-indigo-100 text-indigo-800 rounded-xl text-xs font-bold border border-indigo-200 transition-colors"
                  >
                    2. En Route / On the Way
                  </button>
                  <button
                    onClick={() => handleStatusUpdate('Cleaning')}
                    className="py-2 bg-amber-50 hover:bg-amber-100 text-amber-800 rounded-xl text-xs font-bold border border-amber-200 transition-colors"
                  >
                    3. On Site Cleaning
                  </button>
                </div>
              </div>

              {/* Photos: Before & Upload After */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2 border-t border-slate-100">
                <div>
                  <span className="text-xs font-bold text-slate-700 block mb-1.5">
                    Before Cleaning (Reported Pile)
                  </span>
                  <div className="rounded-2xl overflow-hidden border border-slate-200 aspect-video bg-slate-100">
                    <img
                      src={selectedTask.before_photo_url}
                      alt="Before"
                      className="w-full h-full object-cover"
                    />
                  </div>
                </div>

                <div>
                  <span className="text-xs font-bold text-slate-700 block mb-1.5">
                    After Cleaning Photo (Required Proof)
                  </span>
                  {selectedTask.after_photo_url ? (
                    <div className="rounded-2xl overflow-hidden border border-emerald-300 aspect-video bg-slate-100">
                      <img
                        src={selectedTask.after_photo_url}
                        alt="Cleaned"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ) : afterPhotoUrl ? (
                    <div className="relative rounded-2xl overflow-hidden border border-emerald-400 aspect-video">
                      <img src={afterPhotoUrl} alt="After Proof" className="w-full h-full object-cover" />
                      <button
                        type="button"
                        onClick={() => setAfterPhotoUrl('')}
                        className="absolute top-2 right-2 bg-slate-900/80 text-white text-[10px] px-2 py-0.5 rounded-md"
                      >
                        Retake
                      </button>
                    </div>
                  ) : (
                    <div className="border-2 border-dashed border-slate-300 rounded-2xl p-4 text-center aspect-video flex flex-col items-center justify-center space-y-2">
                      <Camera className="w-6 h-6 text-slate-400" />
                      <span className="text-xs text-slate-500">Pick sample cleaned proof below</span>
                      <div className="flex gap-1.5 mt-1">
                        {SAMPLE_CLEANED_PHOTOS.map((url, i) => (
                          <img
                            key={i}
                            src={url}
                            onClick={() => setAfterPhotoUrl(url)}
                            alt="Sample"
                            className="w-10 h-10 object-cover rounded-lg border border-slate-300 cursor-pointer hover:border-emerald-500"
                          />
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {/* Submit Cleaned Proof Form */}
              {selectedTask.status !== 'Completed' && (
                <form onSubmit={handleUploadProof} className="pt-2 border-t border-slate-100 space-y-3">
                  <input
                    type="text"
                    value={workerNotes}
                    onChange={(e) => setWorkerNotes(e.target.value)}
                    placeholder="Worker notes (e.g. Cleared 45kg plastic waste with Compactor #14, sanitized pavement...)"
                    className="w-full p-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl text-slate-800"
                  />
                  <button
                    type="submit"
                    disabled={uploading || !afterPhotoUrl}
                    className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-xs shadow-md shadow-emerald-600/20 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                  >
                    {uploading ? 'Verifying Proof...' : 'Submit Verification Photo & Mark Job Resolved'}
                  </button>
                </form>
              )}
            </div>
          ) : null}
        </div>
      </div>
    </div>
  );
};
