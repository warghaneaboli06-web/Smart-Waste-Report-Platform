import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Recycle,
  User,
  Building2,
  Truck,
  ShieldAlert,
  ArrowRight,
  Lock,
  Mail,
  Phone,
  UserPlus,
  LogIn,
  CheckCircle2,
  ShieldCheck,
  ChevronRight
} from 'lucide-react';
import { UserRole } from '../types.ts';

interface AuthPagesProps {
  initialMode?: 'login' | 'register';
}

// Dedicated Official Municipal Roles (Municipality Admin, Collection Worker, Enforcement Officer)
const MUNICIPAL_OFFICIAL_ROLES = [
  {
    role: 'admin' as UserRole,
    title: 'Municipality Admin',
    badge: 'Municipal Command Center',
    name: 'Rajesh Verma (Officer In-Charge)',
    email: 'admin@ecotrack.city',
    desc: 'City-wide overview, grievance dispatching, predictive AI litter hotspots, and complaint resolution.',
    icon: Building2,
    badgeColor: 'bg-blue-100 text-blue-800 border-blue-200',
    headerBg: 'bg-blue-600',
    buttonColor: 'bg-blue-600 hover:bg-blue-700 text-white',
    ringColor: 'hover:border-blue-500 hover:ring-2 hover:ring-blue-500/20'
  },
  {
    role: 'worker' as UserRole,
    title: 'Collection Worker',
    badge: 'Sanitation Fleet Unit',
    name: 'Suresh Kumar (Route Lead - Truck MH12)',
    email: 'worker@ecotrack.city',
    desc: 'Daily waste collection routes, geo-located task board, and after-cleaning photographic proof submission.',
    icon: Truck,
    badgeColor: 'bg-amber-100 text-amber-800 border-amber-200',
    headerBg: 'bg-amber-600',
    buttonColor: 'bg-amber-600 hover:bg-amber-700 text-white',
    ringColor: 'hover:border-amber-500 hover:ring-2 hover:ring-amber-500/20'
  },
  {
    role: 'enforcement' as UserRole,
    title: 'Enforcement Officer',
    badge: 'Municipal Law Enforcement',
    name: 'Inspector Vikram Deshmukh',
    email: 'enforcement@ecotrack.city',
    desc: 'Automated License Plate Recognition (ALPR), evidence audit, illegal dumping penalization, and fine collection.',
    icon: ShieldAlert,
    badgeColor: 'bg-purple-100 text-purple-800 border-purple-200',
    headerBg: 'bg-purple-600',
    buttonColor: 'bg-purple-600 hover:bg-purple-700 text-white',
    ringColor: 'hover:border-purple-500 hover:ring-2 hover:ring-purple-500/20'
  }
];

export const AuthPages: React.FC<AuthPagesProps> = ({ initialMode = 'login' }) => {
  const { login, register, switchRole, setCurrentPage } = useAuth();
  const [activeTab, setActiveTab] = useState<'citizen' | 'officials'>('citizen');
  const [citizenMode, setCitizenMode] = useState<'login' | 'register'>(initialMode);
  
  // Clean inputs with NO pre-filled citizen data (the citizen enters their own details)
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleCitizenSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!email.trim()) {
      setError('Please enter your email address');
      return;
    }
    if (!password.trim()) {
      setError('Please enter your password');
      return;
    }

    setLoading(true);
    try {
      if (citizenMode === 'login') {
        await login(email.trim(), password);
      } else {
        if (!name.trim()) {
          setError('Please enter your full name');
          setLoading(false);
          return;
        }
        await register({
          name: name.trim(),
          email: email.trim(),
          phone: phone.trim(),
          password,
          role: 'citizen'
        });
      }
    } catch (err: any) {
      setError(err.message || 'Authentication failed. Please check your credentials.');
    } finally {
      setLoading(false);
    }
  };

  const handleOfficialLogin = (official: typeof MUNICIPAL_OFFICIAL_ROLES[0]) => {
    switchRole(official.role);
    setCurrentPage(
      official.role === 'admin'
        ? 'admin_dashboard'
        : official.role === 'worker'
        ? 'worker_dashboard'
        : 'violations_enforcement'
    );
  };

  return (
    <div
      className="relative min-h-[calc(100vh-4rem)] flex flex-col justify-center py-12 px-4 sm:px-6 lg:px-8 bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `url('https://images.unsplash.com/photo-1477959858617-67f30bc75b82?w=1920&auto=format&fit=crop&q=80')`
      }}
    >
      {/* Atmospheric Dark & Emerald Overlay for contrast & legibility */}
      <div className="absolute inset-0 bg-gradient-to-b from-slate-950/85 via-slate-900/80 to-slate-950/90 backdrop-blur-[2px]" />

      <div className="relative z-10 max-w-4xl mx-auto w-full">
        {/* Back to Home Page */}
        <div className="mb-4 text-center">
          <button
            type="button"
            onClick={() => setCurrentPage('landing')}
            className="inline-flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/15 hover:bg-white/25 text-white text-xs font-bold backdrop-blur-md transition-all border border-white/20 shadow-xs"
          >
            ← Back to Welcome Page
          </button>
        </div>

        {/* Brand & Header */}
        <div className="text-center space-y-2 mb-8">
          <div className="w-12 h-12 rounded-2xl bg-emerald-600 text-white flex items-center justify-center mx-auto shadow-lg shadow-emerald-500/30 border border-emerald-400/30">
            <Recycle className="w-6 h-6" />
          </div>
          <h1 className="text-2xl sm:text-3xl font-black text-white tracking-tight drop-shadow-sm">
            Sign In to EcoTrack Smart City
          </h1>
          <p className="text-xs sm:text-sm text-slate-200 max-w-md mx-auto drop-shadow-xs">
            Integrated Municipal Platform for Citizens, Administration, Collection Workers, and Enforcement Officers.
          </p>
        </div>

        {/* Primary Navigation Tabs between Citizen Portal and Municipal Officials */}
        <div className="flex bg-slate-900/80 backdrop-blur-md p-1.5 rounded-2xl max-w-xl mx-auto mb-6 border border-white/15 shadow-xl">
          <button
            type="button"
            onClick={() => {
              setActiveTab('citizen');
              setError(null);
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeTab === 'citizen'
                ? 'bg-emerald-600 text-white shadow-md shadow-emerald-600/30'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <User className="w-4 h-4" />
            Citizen Portal
          </button>
          <button
            type="button"
            onClick={() => {
              setActiveTab('officials');
              setError(null);
            }}
            className={`flex-1 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 ${
              activeTab === 'officials'
                ? 'bg-blue-600 text-white shadow-md shadow-blue-600/30'
                : 'text-slate-300 hover:text-white'
            }`}
          >
            <ShieldCheck className="w-4 h-4" />
            Municipal Officials Staff
          </button>
        </div>

        {/* TAB 1: CITIZEN PORTAL (No pre-filled citizen; citizen registers or signs in) */}
        {activeTab === 'citizen' && (
          <div className="max-w-xl mx-auto bg-white/95 backdrop-blur-md rounded-3xl border border-white/40 shadow-2xl p-6 sm:p-8 space-y-5 animate-in fade-in zoom-in-95 duration-150">
            <div className="flex bg-slate-100 p-1 rounded-2xl">
              <button
                type="button"
                onClick={() => {
                  setCitizenMode('login');
                  setError(null);
                }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  citizenMode === 'login'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <LogIn className="w-3.5 h-3.5" /> Citizen Sign In
              </button>
              <button
                type="button"
                onClick={() => {
                  setCitizenMode('register');
                  setError(null);
                }}
                className={`flex-1 py-2 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                  citizenMode === 'register'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <UserPlus className="w-3.5 h-3.5" /> Register New Citizen
              </button>
            </div>

            <div className="text-center px-2">
              <p className="text-xs text-slate-500">
                {citizenMode === 'login'
                  ? 'Sign in with your personal credentials to view your reports, points & rewards.'
                  : 'Register your details to report litter, scan waste, and earn civic green credits.'}
              </p>
            </div>

            {error && (
              <div className="p-3.5 rounded-xl bg-rose-50 border border-rose-200 text-xs text-rose-800 font-medium">
                {error}
              </div>
            )}

            <form onSubmit={handleCitizenSubmit} className="space-y-4">
              {citizenMode === 'register' && (
                <>
                  <div>
                    <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
                      Full Name <span className="text-rose-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="text"
                        required
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                        placeholder="Enter your full name"
                        className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
                      Mobile Number
                    </label>
                    <div className="relative">
                      <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                      <input
                        type="tel"
                        value={phone}
                        onChange={(e) => setPhone(e.target.value)}
                        placeholder="+91 98765 43210"
                        className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
                      />
                    </div>
                  </div>
                </>
              )}

              {/* Clean, blank input fields for citizen */}
              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
                  Email Address <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="Enter your email"
                    className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-800 uppercase tracking-wider mb-1.5">
                  Password <span className="text-rose-500">*</span>
                </label>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full pl-9 pr-3.5 py-2.5 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-slate-800"
                  />
                </div>
              </div>

              <div className="pt-2">
                <button
                  type="submit"
                  disabled={loading}
                  className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-md shadow-emerald-600/25 transition-all flex items-center justify-center gap-2 disabled:opacity-50"
                >
                  {loading
                    ? 'Authenticating...'
                    : citizenMode === 'login'
                    ? 'Sign In as Citizen'
                    : 'Complete Registration & Start'}{' '}
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </form>

            {/* Quick link to switch to municipal official staff */}
            <div className="pt-4 border-t border-slate-100 text-center">
              <p className="text-xs text-slate-500">
                Are you a municipal official or sanitation crew?{' '}
                <button
                  type="button"
                  onClick={() => setActiveTab('officials')}
                  className="text-blue-600 hover:text-blue-700 font-bold hover:underline"
                >
                  Switch to Staff Portal →
                </button>
              </p>
            </div>
          </div>
        )}

        {/* TAB 2: MUNICIPAL OFFICIALS (Municipality Admin, Collection Worker, Enforcement Officer) */}
        {activeTab === 'officials' && (
          <div className="space-y-4 animate-in fade-in zoom-in-95 duration-150">
            <div className="text-center mb-2">
              <span className="text-xs font-bold uppercase tracking-wider text-blue-300 bg-blue-900/60 px-3 py-1 rounded-full border border-blue-400/30 inline-block">
                Authorized Municipal Operations Login
              </span>
              <p className="text-xs text-slate-300 mt-2 max-w-lg mx-auto">
                Select your designated municipal role to access city operations, field collection routing, or enforcement management.
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              {MUNICIPAL_OFFICIAL_ROLES.map((official) => {
                const Icon = official.icon;
                return (
                  <div
                    key={official.role}
                    className={`bg-white/95 backdrop-blur-md rounded-3xl border border-white/30 p-6 flex flex-col justify-between shadow-xl transition-all duration-200 ${official.ringColor}`}
                  >
                    <div className="space-y-3">
                      {/* Badge & Icon */}
                      <div className="flex items-center justify-between">
                        <div className={`p-3 rounded-2xl ${official.headerBg} text-white shadow-md`}>
                          <Icon className="w-6 h-6" />
                        </div>
                        <span className={`text-[10px] font-bold px-2 py-0.5 rounded-full border ${official.badgeColor}`}>
                          {official.badge}
                        </span>
                      </div>

                      {/* Title & Official name */}
                      <div>
                        <h3 className="text-base font-extrabold text-slate-900">{official.title}</h3>
                        <p className="text-xs font-semibold text-slate-600">{official.name}</p>
                        <p className="text-[11px] font-mono text-slate-400 mt-0.5">{official.email}</p>
                      </div>

                      {/* Description */}
                      <p className="text-xs text-slate-600 leading-relaxed">
                        {official.desc}
                      </p>
                    </div>

                    {/* Direct Action Button */}
                    <div className="pt-5 mt-4 border-t border-slate-100">
                      <button
                        type="button"
                        onClick={() => handleOfficialLogin(official)}
                        className={`w-full py-2.5 rounded-xl text-xs font-bold shadow-md transition-all flex items-center justify-center gap-1.5 ${official.buttonColor}`}
                      >
                        <span>Access {official.title}</span>
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>

            {/* Quick link back to citizen */}
            <div className="text-center pt-2">
              <button
                type="button"
                onClick={() => setActiveTab('citizen')}
                className="text-xs text-slate-300 hover:text-white font-medium hover:underline"
              >
                ← Return to Citizen Login
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
