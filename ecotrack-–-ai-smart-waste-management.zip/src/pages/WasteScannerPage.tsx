import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Camera,
  Upload,
  RefreshCw,
  Sparkles,
  CheckCircle2,
  AlertTriangle,
  MapPin,
  BookOpen,
  Award,
  ChevronRight,
  ShieldCheck,
  Zap,
  Info
} from 'lucide-react';
import { scanWasteImage } from '../services/api.ts';
import { WasteAnalysisResult } from '../../server/gemini.ts';

// Pre-packaged high quality sample waste photos so reviewers can test immediately without searching for trash
const SAMPLE_WASTE_ITEMS = [
  {
    id: 'sample_plastic',
    name: 'PET Water Bottle',
    category: 'Plastic',
    thumbnail: 'https://images.unsplash.com/photo-1563861826100-9cb868fdbe1c?w=400&auto=format&fit=crop&q=80',
    description: 'Clean plastic mineral water bottle'
  },
  {
    id: 'sample_cardboard',
    name: 'Cardboard Box',
    category: 'Paper',
    thumbnail: 'https://images.unsplash.com/photo-1589939705384-5185137a7f0f?w=400&auto=format&fit=crop&q=80',
    description: 'Corrugated postal packaging box'
  },
  {
    id: 'sample_organic',
    name: 'Vegetable Scraps',
    category: 'Organic',
    thumbnail: 'https://images.unsplash.com/photo-1540420773420-3366772f4999?w=400&auto=format&fit=crop&q=80',
    description: 'Fresh kitchen organic vegetable peels'
  },
  {
    id: 'sample_battery',
    name: 'Lithium Battery',
    category: 'E-Waste',
    thumbnail: 'https://images.unsplash.com/photo-1619725002198-6a689b72f41d?w=400&auto=format&fit=crop&q=80',
    description: 'Discarded rechargeable lithium battery'
  },
  {
    id: 'sample_can',
    name: 'Aluminum Soda Can',
    category: 'Metal',
    thumbnail: 'https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?w=400&auto=format&fit=crop&q=80',
    description: 'Crushed aluminum beverage container'
  }
];

export const WasteScannerPage: React.FC = () => {
  const { user, setCurrentPage, setSelectedCategoryForInfo, updateUserContext } = useAuth();
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [isScanning, setIsScanning] = useState(false);
  const [result, setResult] = useState<WasteAnalysisResult | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [pointsCelebration, setPointsCelebration] = useState(false);

  const videoRef = useRef<HTMLVideoElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const startCamera = async () => {
    setCameraError(null);
    try {
      setCameraActive(true);
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } }
      });
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }
    } catch (err: any) {
      console.warn('Camera stream error:', err);
      setCameraError('Camera access was blocked or is unavailable in this environment. Please choose an image file or test with sample items below.');
      setCameraActive(false);
    }
  };

  const stopCamera = () => {
    if (videoRef.current && videoRef.current.srcObject) {
      const stream = videoRef.current.srcObject as MediaStream;
      stream.getTracks().forEach(t => t.stop());
      videoRef.current.srcObject = null;
    }
    setCameraActive(false);
  };

  const captureFrame = () => {
    if (!videoRef.current) return;
    const canvas = document.createElement('canvas');
    canvas.width = videoRef.current.videoWidth || 640;
    canvas.height = videoRef.current.videoHeight || 480;
    const ctx = canvas.getContext('2d');
    if (ctx) {
      ctx.drawImage(videoRef.current, 0, 0, canvas.width, canvas.height);
      const dataUrl = canvas.toDataURL('image/jpeg', 0.85);
      stopCamera();
      processImage(dataUrl);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const dataUrl = reader.result as string;
      processImage(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const selectSample = (sample: typeof SAMPLE_WASTE_ITEMS[0]) => {
    processImage(sample.thumbnail);
  };

  const processImage = async (imageSrc: string) => {
    setSelectedImage(imageSrc);
    setIsScanning(true);
    setResult(null);
    setPointsCelebration(false);

    try {
      const data = await scanWasteImage(imageSrc, user?.id || 'usr_citizen_1');
      setResult(data.analysis);
      setPointsCelebration(true);

      // Award points locally in AuthContext
      if (user) {
        updateUserContext({
          credit_points: (user.credit_points || 340) + 5,
          green_score: (user.green_score || 850) + 5
        });
      }
    } catch (err: any) {
      console.error('Scan error:', err);
    } finally {
      setIsScanning(false);
    }
  };

  const resetScanner = () => {
    stopCamera();
    setSelectedImage(null);
    setResult(null);
    setPointsCelebration(false);
  };

  return (
    <div className="max-w-4xl mx-auto space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold mb-2">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            Gemini Vision Smart Waste Model
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            AI Waste Scanner & Classifier
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Capture or upload a photo of any discarded item to detect its composition, proper bin color, and earn +5 Green Points.
          </p>
        </div>

        {result && (
          <button
            onClick={resetScanner}
            className="px-4 py-2 text-xs font-semibold bg-white border border-slate-200 rounded-xl hover:bg-slate-50 flex items-center gap-2 self-start sm:self-auto shadow-xs"
          >
            <RefreshCw className="w-3.5 h-3.5 text-slate-600" /> Scan Another Item
          </button>
        )}
      </div>

      {/* Main Scanner Container */}
      <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-sm overflow-hidden">
        {!selectedImage && !cameraActive && (
          <div className="space-y-6">
            {/* Primary Dropzone / Action Area */}
            <div
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-emerald-300 hover:border-emerald-500 bg-emerald-50/30 hover:bg-emerald-50/60 rounded-2xl p-8 sm:p-12 text-center cursor-pointer transition-all flex flex-col items-center justify-center group"
            >
              <div className="w-16 h-16 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform shadow-xs">
                <Upload className="w-8 h-8" />
              </div>
              <h3 className="text-base font-bold text-slate-900">
                Upload or Drag & Drop a Waste Photo
              </h3>
              <p className="text-xs text-slate-500 mt-1 max-w-sm">
                Supports JPG, PNG, WEBP from your camera roll or device
              </p>
              <span className="mt-4 px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-semibold shadow-xs">
                Select Photo from Computer
              </span>
            </div>

            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileUpload}
              accept="image/*"
              className="hidden"
            />

            {/* Live Camera Option */}
            <div className="flex items-center justify-center gap-3">
              <button
                id="btn-use-live-camera"
                onClick={startCamera}
                className="px-5 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-xs transition-colors"
              >
                <Camera className="w-4 h-4 text-emerald-400" />
                Use Live Camera
              </button>
            </div>

            {cameraError && (
              <div className="p-3 bg-amber-50 border border-amber-200 rounded-xl text-xs text-amber-800 text-center">
                {cameraError}
              </div>
            )}

            {/* Quick-Test Sample Items (Instant Evaluation) */}
            <div className="pt-4 border-t border-slate-100">
              <div className="flex items-center justify-between mb-3">
                <span className="text-xs font-bold text-slate-700 uppercase tracking-wider">
                  Or Test with Sample Waste Items:
                </span>
                <span className="text-[11px] text-slate-400">Click any card to analyze instantly</span>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-5 gap-3">
                {SAMPLE_WASTE_ITEMS.map(sample => (
                  <div
                    key={sample.id}
                    onClick={() => selectSample(sample)}
                    className="p-2.5 rounded-xl border border-slate-200 hover:border-emerald-500 hover:shadow-md cursor-pointer transition-all bg-white group text-center"
                  >
                    <img
                      src={sample.thumbnail}
                      alt={sample.name}
                      className="w-full h-20 object-cover rounded-lg mb-2 group-hover:scale-102 transition-transform"
                    />
                    <div className="font-bold text-xs text-slate-900 truncate">{sample.name}</div>
                    <div className="text-[10px] text-emerald-700 font-semibold mt-0.5">{sample.category}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* Camera Live Stream View */}
        {cameraActive && (
          <div className="space-y-4">
            <div className="relative bg-black rounded-2xl overflow-hidden aspect-video max-h-96 flex items-center justify-center">
              <video
                ref={videoRef}
                autoPlay
                playsInline
                muted
                className="w-full h-full object-cover"
              />
              {/* Camera Targeting Reticle */}
              <div className="absolute inset-0 border-2 border-dashed border-white/50 m-8 rounded-2xl pointer-events-none flex items-center justify-center">
                <div className="w-12 h-12 border-t-2 border-l-2 border-emerald-400 absolute top-4 left-4"></div>
                <div className="w-12 h-12 border-t-2 border-r-2 border-emerald-400 absolute top-4 right-4"></div>
                <div className="w-12 h-12 border-b-2 border-l-2 border-emerald-400 absolute bottom-4 left-4"></div>
                <div className="w-12 h-12 border-b-2 border-r-2 border-emerald-400 absolute bottom-4 right-4"></div>
                <span className="text-white/80 text-xs bg-black/60 px-3 py-1 rounded-full backdrop-blur-xs">
                  Center waste item in viewfinder
                </span>
              </div>
            </div>

            <div className="flex items-center justify-center gap-3">
              <button
                onClick={captureFrame}
                className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-2xl text-xs flex items-center gap-2 shadow-md transition-all hover:scale-105"
              >
                <Camera className="w-4 h-4" /> Capture & Classify
              </button>
              <button
                onClick={stopCamera}
                className="px-4 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-semibold rounded-2xl text-xs transition-colors"
              >
                Cancel
              </button>
            </div>
          </div>
        )}

        {/* Analyzing / Scanning State */}
        {selectedImage && isScanning && (
          <div className="py-12 flex flex-col items-center justify-center text-center space-y-4">
            <div className="relative w-48 h-48 rounded-2xl overflow-hidden border-2 border-emerald-500 shadow-xl">
              <img src={selectedImage} alt="Scanning" className="w-full h-full object-cover" />
              {/* Laser Scanning Animation Bar */}
              <div className="absolute inset-x-0 h-1.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_12px_#10b981] animate-bounce top-1/2"></div>
            </div>
            <div>
              <h3 className="text-base font-bold text-slate-900 flex items-center justify-center gap-2">
                <RefreshCw className="w-4 h-4 text-emerald-600 animate-spin" />
                EcoTrack AI Vision Analyzing Material...
              </h3>
              <p className="text-xs text-slate-500 mt-1">
                Classifying polymer structure, toxicity level, and municipal disposal guidelines
              </p>
            </div>
          </div>
        )}

        {/* Scan Result Breakdown */}
        {selectedImage && !isScanning && result && (
          <div className="space-y-6">
            {/* Celebration Badge for Points */}
            {pointsCelebration && (
              <div className="p-3 bg-emerald-100/90 border border-emerald-300 rounded-2xl flex items-center justify-between gap-3 text-emerald-900 animate-in fade-in zoom-in-95">
                <div className="flex items-center gap-2.5">
                  <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center font-extrabold text-sm shadow-xs">
                    +5
                  </div>
                  <div>
                    <div className="font-extrabold text-xs">Green Credit Points Awarded!</div>
                    <div className="text-[11px] text-emerald-700">Scan logged to your civic environmental record.</div>
                  </div>
                </div>
                <span className="text-[10px] font-bold uppercase bg-white px-2.5 py-1 rounded-lg border border-emerald-200">
                  Total: {user?.green_score || 850} pts
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Image Preview & Core Status */}
              <div className="space-y-3">
                <div className="relative rounded-2xl overflow-hidden border border-slate-200 aspect-square shadow-xs">
                  <img src={selectedImage} alt="Detected Item" className="w-full h-full object-cover" />
                  <div className="absolute bottom-2 left-2 bg-slate-950/80 backdrop-blur-xs text-white text-[11px] font-bold px-2.5 py-1 rounded-lg">
                    {result.confidence}% Confidence
                  </div>
                </div>

                <div className="p-3 bg-slate-50 rounded-xl border border-slate-100 text-center">
                  <div className="text-[10px] text-slate-600 font-bold uppercase">Estimated Degradation</div>
                  <div className="text-sm font-extrabold text-slate-800 mt-0.5">{result.degradation_estimate}</div>
                </div>
              </div>

              {/* Classification Details */}
              <div className="md:col-span-2 space-y-4">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="px-2.5 py-0.5 text-xs font-bold uppercase rounded-md bg-emerald-100 text-emerald-800 border border-emerald-200">
                      {result.category_name}
                    </span>
                    <span
                      className={`px-2.5 py-0.5 text-xs font-bold uppercase rounded-md ${
                        result.classification === 'Recyclable'
                          ? 'bg-blue-100 text-blue-800 border border-blue-200'
                          : result.classification === 'Biodegradable'
                          ? 'bg-emerald-100 text-emerald-800 border border-emerald-200'
                          : result.classification === 'Hazardous'
                          ? 'bg-rose-100 text-rose-800 border border-rose-200'
                          : 'bg-amber-100 text-amber-800 border border-amber-200'
                      }`}
                    >
                      {result.classification}
                    </span>
                  </div>

                  <h2 className="text-xl sm:text-2xl font-black text-slate-900 mt-2">
                    {result.waste_type}
                  </h2>
                  <p className="text-xs text-slate-600 mt-1">
                    Composition: <strong className="text-slate-800">{result.material_breakdown}</strong>
                  </p>
                </div>

                {/* Disposal Instructions Box */}
                <div className="p-4 bg-emerald-50/70 border border-emerald-200 rounded-2xl">
                  <div className="flex items-center gap-2 text-emerald-900 font-bold text-xs mb-1">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Official Municipal Disposal Instructions:
                  </div>
                  <p className="text-xs text-emerald-950 font-medium leading-relaxed">
                    {result.disposal_instructions}
                  </p>
                </div>

                {/* Environmental Impact & Safety Note */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                  <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-xl">
                    <div className="font-bold text-slate-800 flex items-center gap-1.5 text-[11px] mb-1">
                      <Zap className="w-3.5 h-3.5 text-amber-500" /> Environmental Impact:
                    </div>
                    <p className="text-slate-600 text-[11px] leading-relaxed">
                      {result.environmental_impact}
                    </p>
                  </div>

                  <div className="p-3 bg-amber-50/60 border border-amber-200 rounded-xl">
                    <div className="font-bold text-amber-900 flex items-center gap-1.5 text-[11px] mb-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-amber-600" /> Safety Precaution:
                    </div>
                    <p className="text-amber-900 text-[11px] leading-relaxed">
                      {result.safety_note}
                    </p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="pt-2 flex flex-wrap items-center gap-3">
                  <button
                    onClick={() => {
                      setCurrentPage('nearby_centers');
                    }}
                    className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5"
                  >
                    <MapPin className="w-3.5 h-3.5" /> Find Nearby Drop-off Center
                  </button>

                  <button
                    onClick={() => {
                      setSelectedCategoryForInfo(result.category_id);
                      setCurrentPage('waste_info');
                    }}
                    className="px-4 py-2.5 bg-slate-100 hover:bg-slate-200 text-slate-800 rounded-xl text-xs font-semibold transition-colors flex items-center gap-1.5"
                  >
                    <BookOpen className="w-3.5 h-3.5 text-slate-500" /> Full Category Guide
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
