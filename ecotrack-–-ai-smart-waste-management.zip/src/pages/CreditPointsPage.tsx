import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Award,
  TrendingUp,
  Gift,
  Trophy,
  CheckCircle2,
  Clock,
  ArrowUpRight,
  Sparkles,
  Zap,
  Tag,
  TreeDeciduous,
  Bus,
  Home
} from 'lucide-react';
import { fetchPointsSummary, redeemReward, fetchLeaderboard } from '../services/api.ts';
import { RewardItem, PointTransaction } from '../types.ts';

export const CreditPointsPage: React.FC = () => {
  const { user, updateUserContext } = useAuth();
  const [pointsData, setPointsData] = useState<any>(null);
  const [leaderboard, setLeaderboard] = useState<any[]>([]);
  const [activeTab, setActiveTab] = useState<'rewards' | 'history' | 'leaderboard'>('rewards');
  const [leaderboardScope, setLeaderboardScope] = useState<'weekly' | 'monthly' | 'overall'>('monthly');
  const [redeemingId, setRedeemingId] = useState<string | null>(null);
  const [successMessage, setSuccessMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  useEffect(() => {
    if (user) {
      loadPoints();
      loadLeaderboard();
    }
  }, [user]);

  const loadPoints = async () => {
    if (!user) return;
    try {
      const data = await fetchPointsSummary(user.id);
      setPointsData(data);
    } catch (e) {
      console.error(e);
    }
  };

  const loadLeaderboard = async () => {
    try {
      const data = await fetchLeaderboard();
      setLeaderboard(data || []);
    } catch (e) {
      console.error(e);
    }
  };

  const handleRedeem = async (reward: RewardItem) => {
    if (!user) return;
    setErrorMessage(null);
    setSuccessMessage(null);
    setRedeemingId(reward.id);

    try {
      const res = await redeemReward(user.id, reward.id);
      setSuccessMessage(res.message);
      updateUserContext({ credit_points: res.newBalance });
      loadPoints();
    } catch (err: any) {
      setErrorMessage(err.message || 'Redemption failed');
    } finally {
      setRedeemingId(null);
    }
  };

  const getRewardIcon = (category: string) => {
    switch (category) {
      case 'transit_pass': return Bus;
      case 'plantation': return TreeDeciduous;
      case 'eco_merchandise': return Home;
      default: return Tag;
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold mb-2">
          <Award className="w-3.5 h-3.5 text-emerald-600" />
          Smart City Civic Environmental Credits
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Credit Points, Rewards & Leaderboard
        </h1>
        <p className="text-slate-600 text-xs sm:text-sm mt-1">
          Earn Green Score points by scanning waste and reporting problems. Redeem for municipal tax discounts and transit passes.
        </p>
      </div>

      {/* Top Banner: Green Score Tier & Balance Card */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
        {/* Available Points Balance */}
        <div className="bg-gradient-to-br from-emerald-600 to-teal-700 rounded-3xl p-6 text-white shadow-md flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <span className="text-xs uppercase font-bold tracking-wider text-emerald-100">
                Available Green Credits
              </span>
              <Award className="w-5 h-5 text-emerald-200" />
            </div>
            <div className="text-4xl font-black mt-3">
              {user?.credit_points || 340} <span className="text-lg font-semibold text-emerald-200">pts</span>
            </div>
            <p className="text-xs text-emerald-100 mt-2">
              Worth up to 5% municipal property rebate or free transit travel.
            </p>
          </div>

          <div className="mt-6 pt-4 border-t border-emerald-500/50 flex items-center justify-between text-xs">
            <span>Lifetime Earned:</span>
            <span className="font-bold">{user?.green_score || 850} pts</span>
          </div>
        </div>

        {/* Tier Progress Gauge */}
        <div className="md:col-span-2 bg-white rounded-3xl border border-slate-200 p-6 shadow-xs flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
                  Current Civic Tier
                </span>
                <h3 className="text-xl font-black text-slate-900 mt-0.5">
                  Waste Warrior <span className="text-xs font-semibold text-emerald-600">(Level 3)</span>
                </h3>
              </div>
              <div className="w-12 h-12 rounded-2xl bg-emerald-100 text-emerald-700 flex items-center justify-center font-black text-lg">
                #3
              </div>
            </div>

            <div className="mt-4">
              <div className="flex justify-between text-xs text-slate-600 mb-1.5">
                <span>Progress to <strong className="text-slate-900">Clean City Champion</strong></span>
                <span className="font-bold text-emerald-700">850 / 1000 pts (85%)</span>
              </div>
              <div className="w-full bg-slate-100 h-3 rounded-full overflow-hidden p-0.5">
                <div
                  className="bg-gradient-to-r from-emerald-500 to-teal-500 h-full rounded-full transition-all duration-700"
                  style={{ width: '85%' }}
                ></div>
              </div>
            </div>

            <div className="mt-4 grid grid-cols-4 gap-2 text-center text-[10px]">
              <div className="p-2 bg-slate-50 rounded-xl border border-slate-100">
                <div className="font-bold text-slate-800">Eco Starter</div>
                <div className="text-slate-400">0 - 200 pts</div>
              </div>
              <div className="p-2 bg-slate-50 rounded-xl border border-slate-100">
                <div className="font-bold text-slate-800">Green Citizen</div>
                <div className="text-slate-400">200 - 500 pts</div>
              </div>
              <div className="p-2 bg-emerald-50 rounded-xl border border-emerald-300 font-bold text-emerald-900">
                <div>Waste Warrior</div>
                <div className="text-emerald-700">500 - 1000 pts</div>
              </div>
              <div className="p-2 bg-slate-50 rounded-xl border border-slate-100 opacity-60">
                <div className="font-bold text-slate-800">Clean Champion</div>
                <div className="text-slate-400">1000+ pts</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-slate-200 pb-2">
        {[
          { id: 'rewards', label: 'Municipal Rewards Catalog', icon: Gift },
          { id: 'history', label: 'Points Activity Ledger', icon: Clock },
          { id: 'leaderboard', label: 'City Leaderboard', icon: Trophy },
        ].map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-colors ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
              }`}
            >
              <Icon className="w-4 h-4" />
              {tab.label}
            </button>
          );
        })}
      </div>

      {/* Messages */}
      {successMessage && (
        <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-2xl text-xs text-emerald-900 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600" />
            <span className="font-semibold">{successMessage}</span>
          </div>
          <button onClick={() => setSuccessMessage(null)} className="text-emerald-700 font-bold">×</button>
        </div>
      )}

      {errorMessage && (
        <div className="p-4 bg-rose-50 border border-rose-200 rounded-2xl text-xs text-rose-900 flex items-center justify-between">
          <span className="font-semibold">{errorMessage}</span>
          <button onClick={() => setErrorMessage(null)} className="text-rose-700 font-bold">×</button>
        </div>
      )}

      {/* Tab 1: Rewards Catalog */}
      {activeTab === 'rewards' && (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {(pointsData?.rewards || []).map((reward: RewardItem) => {
            const Icon = getRewardIcon(reward.category);
            const userCredits = user?.credit_points || 340;
            const canAfford = userCredits >= reward.points_required;
            const isRedeeming = redeemingId === reward.id;

            return (
              <div
                key={reward.id}
                className="bg-white rounded-2xl border border-slate-200 p-5 shadow-xs flex flex-col justify-between hover:shadow-md transition-all"
              >
                <div>
                  <div className="flex items-start justify-between">
                    <div className="w-12 h-12 rounded-2xl bg-emerald-50 text-emerald-700 flex items-center justify-center">
                      <Icon className="w-6 h-6" />
                    </div>
                    <span className="text-sm font-black text-emerald-700 bg-emerald-50 px-2.5 py-1 rounded-xl border border-emerald-200">
                      {reward.points_required} pts
                    </span>
                  </div>

                  <h3 className="text-base font-bold text-slate-900 mt-3">{reward.name}</h3>
                  <p className="text-xs text-slate-500 mt-1 leading-relaxed">{reward.description}</p>
                </div>

                <div className="mt-5 pt-3 border-t border-slate-100">
                  <button
                    onClick={() => handleRedeem(reward)}
                    disabled={!canAfford || isRedeeming}
                    className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 ${
                      canAfford
                        ? 'bg-emerald-600 hover:bg-emerald-700 text-white shadow-xs'
                        : 'bg-slate-100 text-slate-400 cursor-not-allowed'
                    }`}
                  >
                    {isRedeeming ? 'Redeeming...' : canAfford ? 'Redeem Voucher' : `Need ${reward.points_required - userCredits} more pts`}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {/* Tab 2: Points History Ledger */}
      {activeTab === 'history' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs overflow-hidden">
          <h3 className="text-sm font-bold text-slate-900 uppercase tracking-wider mb-4">
            Recent Environmental Activity Ledger
          </h3>

          <div className="divide-y divide-slate-100">
            {(pointsData?.transactions || []).map((t: PointTransaction) => (
              <div key={t.id} className="py-3 flex items-center justify-between text-xs">
                <div>
                  <div className="font-bold text-slate-900">{t.description}</div>
                  <div className="text-[11px] text-slate-400 mt-0.5 flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {new Date(t.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })}
                  </div>
                </div>
                <span
                  className={`font-black text-sm ${
                    t.amount > 0 ? 'text-emerald-600' : 'text-rose-600'
                  }`}
                >
                  {t.amount > 0 ? `+${t.amount}` : t.amount} pts
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: City Leaderboard */}
      {activeTab === 'leaderboard' && (
        <div className="bg-white rounded-3xl border border-slate-200 p-6 shadow-xs space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
            <div>
              <h3 className="text-base font-bold text-slate-900">Pune Smart City Green Leaderboard</h3>
              <p className="text-xs text-slate-500">Top citizens leading municipal waste segregation and reporting</p>
            </div>

            <div className="flex items-center gap-1 bg-slate-100 p-1 rounded-xl">
              {(['weekly', 'monthly', 'overall'] as const).map(s => (
                <button
                  key={s}
                  onClick={() => setLeaderboardScope(s)}
                  className={`px-3 py-1 rounded-lg text-xs font-semibold capitalize transition-colors ${
                    leaderboardScope === s ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
                  }`}
                >
                  {s}
                </button>
              ))}
            </div>
          </div>

          <div className="divide-y divide-slate-100">
            {leaderboard.map(citizen => (
              <div
                key={citizen.rank}
                className={`py-3.5 px-3 rounded-2xl flex items-center justify-between transition-colors ${
                  citizen.name.includes('Priya') ? 'bg-emerald-50/60 font-semibold' : 'hover:bg-slate-50'
                }`}
              >
                <div className="flex items-center gap-3">
                  <div
                    className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-black ${
                      citizen.rank === 1
                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                        : citizen.rank === 2
                        ? 'bg-slate-200 text-slate-700'
                        : citizen.rank === 3
                        ? 'bg-amber-50 text-amber-700'
                        : 'text-slate-400'
                    }`}
                  >
                    #{citizen.rank}
                  </div>
                  <div>
                    <div className="text-xs font-bold text-slate-900">{citizen.name}</div>
                    <div className="text-[10px] text-slate-400">{citizen.badge}</div>
                  </div>
                </div>

                <div className="text-right">
                  <div className="text-sm font-black text-emerald-700">{citizen.points} pts</div>
                  <div className="text-[10px] text-slate-400">{citizen.reports_resolved} piles cleared</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
