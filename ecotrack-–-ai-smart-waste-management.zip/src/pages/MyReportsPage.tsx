import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  FileText,
  Clock,
  CheckCircle2,
  AlertTriangle,
  MapPin,
  Truck,
  Eye,
  ChevronRight,
  ShieldCheck,
  UserCheck,
  Calendar,
  XCircle,
  Plus
} from 'lucide-react';
import { fetchMyReports } from '../services/api.ts';
import { WasteReport, ReportStatus } from '../types.ts';

const STATUS_STEPS: ReportStatus[] = [
  'Submitted',
  'Under Verification',
  'Verified',
  'Worker Assigned',
  'In Progress',
  'Resolved'
];

export const MyReportsPage: React.FC = () => {
  const { user, setCurrentPage } = useAuth();
  const [reports, setReports] = useState<WasteReport[]>([]);
  const [selectedReport, setSelectedReport] = useState<WasteReport | null>(null);
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) loadReports();
  }, [user]);

  const loadReports = async () => {
    if (!user) return;
    try {
      setLoading(true);
      const data = await fetchMyReports(user.id);
      setReports(data || []);
      if (data?.length > 0 && !selectedReport) {
        setSelectedReport(data[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const filtered = reports.filter(r => {
    if (activeFilter === 'all') return true;
    if (activeFilter === 'resolved') return r.status === 'Resolved';
    if (activeFilter === 'in_progress') return r.status === 'In Progress' || r.status === 'Worker Assigned';
    if (activeFilter === 'pending') return r.status === 'Submitted' || r.status === 'Under Verification';
    return true;
  });

  const getStatusBadge = (status: ReportStatus) => {
    switch (status) {
      case 'Resolved': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'In Progress': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Worker Assigned': return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Verified': return 'bg-teal-100 text-teal-800 border-teal-200';
      case 'Under Verification': return 'bg-amber-100 text-amber-800 border-amber-200';
      case 'Rejected': return 'bg-rose-100 text-rose-800 border-rose-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  const getStepIndex = (status: ReportStatus) => {
    const idx = STATUS_STEPS.indexOf(status);
    return idx === -1 ? 0 : idx;
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold mb-2">
            <FileText className="w-3.5 h-3.5 text-emerald-600" />
            Live Citizen Grievance Tracker
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
            My Waste Reports & Complaints
          </h1>
          <p className="text-slate-600 text-xs sm:text-sm mt-1">
            Track real-time status, field worker assignments, and municipal before & after verification proof.
          </p>
        </div>

        <button
          onClick={() => setCurrentPage('report_waste')}
          className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start sm:self-auto"
        >
          <Plus className="w-4 h-4" /> File New Report
        </button>
      </div>

      {/* Filter Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {[
          { id: 'all', label: `All Reports (${reports.length})` },
          { id: 'pending', label: 'Pending Verification' },
          { id: 'in_progress', label: 'In Progress & Assigned' },
          { id: 'resolved', label: 'Resolved & Cleaned' },
        ].map(f => (
          <button
            key={f.id}
            onClick={() => setActiveFilter(f.id)}
            className={`px-3 py-1.5 rounded-xl text-xs font-semibold whitespace-nowrap transition-colors ${
              activeFilter === f.id
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'bg-white text-slate-600 border border-slate-200 hover:bg-slate-50'
            }`}
          >
            {f.label}
          </button>
        ))}
      </div>

      {/* Main Grid: Reports List (1 col) + Timeline & Verification Inspector (2 cols) */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Reports List */}
        <div className="space-y-3 max-h-[700px] overflow-y-auto pr-1">
          {filtered.length === 0 ? (
            <div className="bg-white rounded-2xl border border-slate-200 p-8 text-center text-slate-400 text-xs">
              No reports found matching this filter.
            </div>
          ) : (
            filtered.map(report => {
              const isSelected = selectedReport?.id === report.id;
              return (
                <div
                  key={report.id}
                  onClick={() => setSelectedReport(report)}
                  className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                    isSelected
                      ? 'border-emerald-500 bg-emerald-50/40 shadow-xs ring-1 ring-emerald-500/30'
                      : 'border-slate-200 bg-white hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <span className="font-mono text-[11px] font-bold text-slate-500">
                      #{report.complaint_id}
                    </span>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${getStatusBadge(report.status)}`}>
                      {report.status}
                    </span>
                  </div>

                  <div className="flex items-center gap-3 mt-2.5">
                    <img
                      src={report.image_url}
                      alt="Waste"
                      className="w-14 h-14 rounded-xl object-cover border border-slate-200 shrink-0"
                    />
                    <div className="truncate">
                      <div className="font-bold text-xs text-slate-900 truncate">
                        {report.category_name}
                      </div>
                      <p className="text-[11px] text-slate-500 truncate mt-0.5">
                        {report.address}
                      </p>
                      <div className="text-[10px] text-slate-400 mt-1 flex items-center gap-1">
                        <Calendar className="w-3 h-3" />
                        {new Date(report.created_at).toLocaleDateString(undefined, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Timeline & Details Inspector */}
        <div className="lg:col-span-2">
          {selectedReport ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-xs space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-3 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-xs font-extrabold text-slate-700 bg-slate-100 px-2 py-0.5 rounded">
                      Complaint #{selectedReport.complaint_id}
                    </span>
                    <span className={`text-xs font-bold uppercase px-2.5 py-0.5 rounded border ${getStatusBadge(selectedReport.status)}`}>
                      {selectedReport.status}
                    </span>
                  </div>
                  <h2 className="text-xl font-black text-slate-900 mt-2">
                    {selectedReport.category_name}
                  </h2>
                  <p className="text-xs text-slate-600 mt-1 flex items-center gap-1.5">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    {selectedReport.address}
                  </p>
                </div>

                <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-100 text-xs text-right">
                  <div className="text-slate-400 text-[10px]">Priority Level</div>
                  <div className="font-bold uppercase text-slate-800 mt-0.5">{selectedReport.priority}</div>
                </div>
              </div>

              {/* Progress Timeline Stepper */}
              <div>
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider mb-4">
                  Municipal Resolution Stepper
                </h3>

                <div className="relative">
                  <div className="grid grid-cols-6 gap-2 text-center">
                    {STATUS_STEPS.map((step, idx) => {
                      const currentIdx = getStepIndex(selectedReport.status);
                      const isComplete = idx <= currentIdx && selectedReport.status !== 'Rejected';
                      const isCurrent = idx === currentIdx;

                      return (
                        <div key={step} className="flex flex-col items-center">
                          <div
                            className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold mb-1.5 transition-colors ${
                              isComplete
                                ? 'bg-emerald-600 text-white shadow-xs'
                                : 'bg-slate-100 text-slate-400 border border-slate-200'
                            }`}
                          >
                            {isComplete ? <CheckCircle2 className="w-4 h-4" /> : idx + 1}
                          </div>
                          <span
                            className={`text-[10px] font-semibold leading-tight ${
                              isCurrent
                                ? 'text-emerald-700 font-bold'
                                : isComplete
                                ? 'text-slate-800'
                                : 'text-slate-400'
                            }`}
                          >
                            {step}
                          </span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Photos Comparison (Before / After Proof) */}
              <div className="space-y-2 pt-2 border-t border-slate-100">
                <h3 className="text-xs font-bold text-slate-900 uppercase tracking-wider">
                  Verification Photographic Evidence
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {/* Before Photo */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-700">Before Cleaning</span>
                      <span className="text-[10px] text-slate-400">Citizen Upload</span>
                    </div>
                    <div className="rounded-2xl overflow-hidden border border-slate-200 aspect-video bg-slate-100">
                      <img
                        src={selectedReport.before_photo_url || selectedReport.image_url}
                        alt="Before"
                        className="w-full h-full object-cover"
                      />
                    </div>
                  </div>

                  {/* After Photo */}
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <span className="font-bold text-slate-700">After Cleaning Proof</span>
                      {selectedReport.after_photo_url ? (
                        <span className="text-[10px] font-bold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded">
                          Worker Verified
                        </span>
                      ) : (
                        <span className="text-[10px] text-amber-600">Pending Field Clearance</span>
                      )}
                    </div>

                    <div className="rounded-2xl overflow-hidden border border-slate-200 aspect-video bg-slate-100 flex items-center justify-center">
                      {selectedReport.after_photo_url ? (
                        <img
                          src={selectedReport.after_photo_url}
                          alt="After Cleaning"
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="text-center p-4 text-slate-400 text-xs">
                          <Truck className="w-8 h-8 mx-auto mb-1.5 text-slate-300" />
                          Collection team dispatched. Cleaned photo will appear once job is finished.
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Assignment & Audit Trail Notes */}
              <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2 text-xs">
                <div className="flex justify-between">
                  <span className="text-slate-500">Assigned Field Worker:</span>
                  <span className="font-bold text-slate-800">
                    {selectedReport.assigned_worker_name || 'Sanitation Truck #14 (Auto-Allocated)'}
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-slate-500">Citizen Description:</span>
                  <span className="text-slate-700 text-right max-w-sm">{selectedReport.description}</span>
                </div>
                {selectedReport.timeline && selectedReport.timeline.length > 0 && (
                  <div className="pt-2 border-t border-slate-200">
                    <div className="text-[10px] font-bold text-slate-400 uppercase mb-1">Audit Trail Log</div>
                    <div className="space-y-1">
                      {selectedReport.timeline.map((item, idx) => (
                        <div key={idx} className="flex justify-between text-[11px] text-slate-600">
                          <span>• {item.note}</span>
                          <span className="text-slate-400 text-[10px]">
                            {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400 text-xs">
              Select a report from the list to view its complete audit timeline.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
