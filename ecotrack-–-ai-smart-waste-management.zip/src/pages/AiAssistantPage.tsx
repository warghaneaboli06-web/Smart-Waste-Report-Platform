import React, { useState, useRef, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Bot,
  Send,
  Sparkles,
  User,
  Trash2,
  MapPin,
  Award,
  BookOpen,
  ArrowRight
} from 'lucide-react';
import { sendAiChatMessage } from '../services/api.ts';

interface Message {
  role: 'user' | 'model';
  content: string;
  time: string;
}

const SUGGESTED_PROMPTS = [
  'Where do I safely dispose of a lithium-ion battery?',
  'Can greasy cardboard pizza boxes be recycled?',
  'How do I segregate wet food waste vs. dry waste at home?',
  'Where is the nearest municipal electronic waste center?',
  'How do I earn Green Credit points for waste reporting?'
];

export const AiAssistantPage: React.FC = () => {
  const { setCurrentPage } = useAuth();
  const [messages, setMessages] = useState<Message[]>([
    {
      role: 'model',
      content:
        'Hello! I am your **EcoTrack AI Waste Assistant** powered by Gemini. You can ask me how to classify items, where to drop off hazardous materials, how to segregate wet vs. dry waste, or how to earn Green Score points. How can I assist your green journey today?',
      time: 'Just now'
    }
  ]);
  const [input, setInput] = useState('');
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  const handleSend = async (textToSend?: string) => {
    const query = textToSend || input;
    if (!query.trim()) return;

    const userMsg: Message = {
      role: 'user',
      content: query,
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
    };

    setMessages(prev => [...prev, userMsg]);
    if (!textToSend) setInput('');
    setIsTyping(true);

    try {
      const history = [...messages, userMsg].map(m => ({
        role: m.role,
        content: m.content
      }));

      const res = await sendAiChatMessage(history);
      const modelMsg: Message = {
        role: 'model',
        content: res.reply || 'I am ready to help you with any waste segregation questions.',
        time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
      };
      setMessages(prev => [...prev, modelMsg]);
    } catch (err) {
      setMessages(prev => [
        ...prev,
        {
          role: 'model',
          content: 'Unable to reach the assistant at this time. Please try again shortly.',
          time: 'Now'
        }
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-4 pb-8 h-[calc(100vh-6.5rem)] flex flex-col">
      {/* Header */}
      <div className="shrink-0 flex items-center justify-between">
        <div>
          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold mb-1">
            <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
            Gemini 3.8 Flash Smart Municipal Advisor
          </div>
          <h1 className="text-xl sm:text-2xl font-extrabold text-slate-900 tracking-tight">
            AI Waste & Recycling Assistant
          </h1>
        </div>
      </div>

      {/* Chat Messages Frame */}
      <div className="flex-1 bg-white rounded-3xl border border-slate-200 p-4 sm:p-6 shadow-xs overflow-y-auto space-y-4 flex flex-col">
        {messages.map((m, idx) => {
          const isUser = m.role === 'user';
          return (
            <div
              key={idx}
              className={`flex items-start gap-3 max-w-[85%] ${
                isUser ? 'ml-auto flex-row-reverse' : 'mr-auto'
              }`}
            >
              <div
                className={`w-8 h-8 rounded-xl flex items-center justify-center shrink-0 text-xs ${
                  isUser
                    ? 'bg-slate-900 text-white'
                    : 'bg-emerald-600 text-white shadow-xs'
                }`}
              >
                {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
              </div>

              <div
                className={`p-4 rounded-2xl text-xs sm:text-sm leading-relaxed ${
                  isUser
                    ? 'bg-emerald-600 text-white rounded-tr-xs'
                    : 'bg-slate-50 border border-slate-200/80 text-slate-800 rounded-tl-xs whitespace-pre-line'
                }`}
              >
                <div>{m.content}</div>
                <div
                  className={`text-[10px] mt-1.5 font-medium ${
                    isUser ? 'text-emerald-100 text-right' : 'text-slate-400'
                  }`}
                >
                  {m.time}
                </div>
              </div>
            </div>
          );
        })}

        {isTyping && (
          <div className="flex items-center gap-3 mr-auto">
            <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 text-xs">
              <Bot className="w-4 h-4" />
            </div>
            <div className="p-3 bg-slate-50 border border-slate-200/80 rounded-2xl rounded-tl-xs text-xs text-slate-500 flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
              <span>Consulting municipal solid waste knowledge base...</span>
            </div>
          </div>
        )}

        <div ref={messagesEndRef} />
      </div>

      {/* Suggested Prompt Chips */}
      <div className="shrink-0 flex items-center gap-1.5 overflow-x-auto py-1 text-xs">
        <span className="text-[11px] font-semibold text-slate-400 shrink-0">Try asking:</span>
        {SUGGESTED_PROMPTS.map((prompt, i) => (
          <button
            key={i}
            onClick={() => handleSend(prompt)}
            className="px-3 py-1 bg-slate-100 hover:bg-emerald-50 hover:text-emerald-800 text-slate-700 rounded-full border border-slate-200/70 whitespace-nowrap text-xs transition-colors shrink-0"
          >
            {prompt}
          </button>
        ))}
      </div>

      {/* Input Box */}
      <div className="shrink-0 bg-white p-2 rounded-2xl border border-slate-200 shadow-xs flex items-center gap-2">
        <input
          type="text"
          value={input}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleSend();
            }
          }}
          placeholder="Ask anything about waste segregation, recycling rules, or disposal..."
          className="flex-1 px-3 py-2 text-xs sm:text-sm bg-transparent focus:outline-none text-slate-800 placeholder:text-slate-400"
        />
        <button
          onClick={() => handleSend()}
          disabled={!input.trim() || isTyping}
          className="p-2.5 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-40 text-white rounded-xl shadow-xs transition-colors"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
