import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext.tsx';
import {
  Search,
  BookOpen,
  CheckCircle2,
  AlertTriangle,
  MapPin,
  Clock,
  ShieldAlert,
  ArrowRight,
  Filter,
  Recycle,
  Trash2,
  X
} from 'lucide-react';
import { fetchWasteCategories } from '../services/api.ts';
import { WasteCategory } from '../types.ts';

export const WasteInfoPage: React.FC = () => {
  const { setCurrentPage, selectedCategoryForInfo, setSelectedCategoryForInfo } = useAuth();
  const [categories, setCategories] = useState<WasteCategory[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [selectedCategory, setSelectedCategory] = useState<WasteCategory | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadCategories();
  }, []);

  useEffect(() => {
    if (selectedCategoryForInfo && categories.length > 0) {
      const match = categories.find(c => c.id === selectedCategoryForInfo);
      if (match) setSelectedCategory(match);
    }
  }, [selectedCategoryForInfo, categories]);

  const loadCategories = async () => {
    try {
      setLoading(true);
      const data = await fetchWasteCategories();
      setCategories(data || []);
      if (!selectedCategory && data?.length > 0) {
        setSelectedCategory(data[0]);
      }
    } catch (err) {
      console.error('Failed to load categories', err);
    } finally {
      setLoading(false);
    }
  };

  const filteredCategories = categories.filter(cat => {
    const matchesSearch =
      cat.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cat.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      cat.examples.some(ex => ex.toLowerCase().includes(searchQuery.toLowerCase()));

    const matchesFilter =
      activeFilter === 'all' ||
      cat.classification.toLowerCase().replace(/ /g, '_') === activeFilter.toLowerCase();

    return matchesSearch && matchesFilter;
  });

  const getClassificationBadgeClass = (classification: string) => {
    switch (classification) {
      case 'Recyclable': return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Biodegradable': return 'bg-emerald-100 text-emerald-800 border-emerald-200';
      case 'Hazardous': return 'bg-rose-100 text-rose-800 border-rose-200';
      case 'Special Disposal': return 'bg-purple-100 text-purple-800 border-purple-200';
      default: return 'bg-slate-100 text-slate-800 border-slate-200';
    }
  };

  return (
    <div className="space-y-6 pb-12">
      {/* Page Header */}
      <div>
        <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200 text-xs font-semibold mb-2">
          <BookOpen className="w-3.5 h-3.5 text-emerald-600" />
          Municipal Solid Waste Bylaws & Knowledge Base
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">
          Waste Information & Segregation Guide
        </h1>
        <p className="text-slate-600 text-xs sm:text-sm mt-1">
          Explore all 10 waste categories, their environmental lifecycle, safety guidelines, and municipal color codes.
        </p>
      </div>

      {/* Search & Filter Bar */}
      <div className="bg-white p-4 rounded-2xl border border-slate-200 shadow-xs flex flex-col sm:flex-row items-center justify-between gap-3">
        <div className="relative w-full sm:w-80">
          <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search plastic, battery, cardboard..."
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all text-slate-700"
          />
        </div>

        <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto py-0.5">
          <span className="text-xs font-semibold text-slate-500 mr-1 flex items-center gap-1">
            <Filter className="w-3 h-3" /> Class:
          </span>
          {[
            { id: 'all', label: 'All (10)' },
            { id: 'recyclable', label: 'Recyclable' },
            { id: 'biodegradable', label: 'Biodegradable' },
            { id: 'hazardous', label: 'Hazardous' },
            { id: 'special_disposal', label: 'Special' },
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setActiveFilter(f.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition-colors ${
                activeFilter === f.id
                  ? 'bg-emerald-600 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Content Grid: Left List, Right Expanded Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Left 1 Col: Cards List */}
        <div className="space-y-3 max-h-[750px] overflow-y-auto pr-1">
          {filteredCategories.map(cat => {
            const isSelected = selectedCategory?.id === cat.id;
            return (
              <div
                key={cat.id}
                onClick={() => setSelectedCategory(cat)}
                className={`p-4 rounded-2xl border cursor-pointer transition-all ${
                  isSelected
                    ? 'border-emerald-500 bg-emerald-50/40 shadow-sm ring-1 ring-emerald-500/30'
                    : 'border-slate-200 bg-white hover:border-slate-300 hover:shadow-xs'
                }`}
              >
                <div className="flex items-start justify-between gap-2">
                  <div>
                    <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded border ${getClassificationBadgeClass(cat.classification)}`}>
                      {cat.classification}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900 mt-1.5">{cat.name}</h3>
                  </div>
                  <div
                    className="w-4 h-4 rounded-full border-2 border-white shadow-xs shrink-0"
                    style={{ backgroundColor: cat.color_code }}
                    title={`Designated bin color: ${cat.color_code}`}
                  ></div>
                </div>

                <p className="text-xs text-slate-500 mt-1 line-clamp-2">{cat.description}</p>

                <div className="mt-3 flex items-center justify-between text-[11px] text-slate-400 pt-2 border-t border-slate-100">
                  <span>Reward: <strong className="text-emerald-700">+{cat.points_reward} pts</strong></span>
                  <span className="text-emerald-600 font-semibold flex items-center gap-0.5">
                    Inspect Guide <ArrowRight className="w-3 h-3" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>

        {/* Right 2 Cols: Detailed Inspector */}
        <div className="lg:col-span-2">
          {selectedCategory ? (
            <div className="bg-white rounded-3xl border border-slate-200 p-6 sm:p-8 shadow-sm space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4 pb-4 border-b border-slate-100">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-xs font-bold uppercase px-2.5 py-0.5 rounded border ${getClassificationBadgeClass(selectedCategory.classification)}`}>
                      {selectedCategory.classification}
                    </span>
                    <span className="text-xs text-slate-500 font-medium">
                      Reward: <strong className="text-emerald-700 font-bold">+{selectedCategory.points_reward} Green Points</strong>
                    </span>
                  </div>
                  <h2 className="text-2xl font-black text-slate-900 mt-1.5 flex items-center gap-2.5">
                    <div
                      className="w-4 h-4 rounded-full border border-slate-200 inline-block shrink-0"
                      style={{ backgroundColor: selectedCategory.color_code }}
                    ></div>
                    {selectedCategory.name}
                  </h2>
                  <p className="text-xs text-slate-600 mt-1">{selectedCategory.description}</p>
                </div>

                <button
                  onClick={() => {
                    setCurrentPage('nearby_centers');
                  }}
                  className="px-4 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold shadow-xs transition-colors flex items-center gap-1.5 self-start shrink-0"
                >
                  <MapPin className="w-3.5 h-3.5" /> Find Drop-off Centers
                </button>
              </div>

              {/* Core Guidance Blocks */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Correct Disposal */}
                <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200">
                  <div className="flex items-center gap-2 font-bold text-xs text-emerald-900 mb-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    Correct Municipal Disposal
                  </div>
                  <p className="text-xs text-emerald-950 leading-relaxed font-medium">
                    {selectedCategory.correct_disposal}
                  </p>
                </div>

                {/* Recycling Info */}
                <div className="p-4 rounded-2xl bg-blue-50/80 border border-blue-200">
                  <div className="flex items-center gap-2 font-bold text-xs text-blue-900 mb-1.5">
                    <Recycle className="w-4 h-4 text-blue-600" />
                    Recycling & Resource Recovery
                  </div>
                  <p className="text-xs text-blue-950 leading-relaxed font-medium">
                    {selectedCategory.recycling_info}
                  </p>
                </div>
              </div>

              {/* Environmental Impact & Safety Precautions */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200">
                  <div className="font-bold text-xs text-slate-800 mb-1">
                    Environmental Impact & Lifetime
                  </div>
                  <p className="text-xs text-slate-600 leading-relaxed">
                    {selectedCategory.environmental_impact}
                  </p>
                  <div className="mt-3 text-[11px] text-slate-500 font-semibold">
                    ⏳ Degradation Time: <span className="text-slate-900">{selectedCategory.degradation_period}</span>
                  </div>
                </div>

                <div className="p-4 rounded-2xl bg-amber-50/70 border border-amber-200">
                  <div className="font-bold text-xs text-amber-900 mb-1 flex items-center gap-1.5">
                    <ShieldAlert className="w-3.5 h-3.5 text-amber-600" />
                    Safety Precautions & Handling
                  </div>
                  <p className="text-xs text-amber-950 leading-relaxed font-medium">
                    {selectedCategory.safety_precautions}
                  </p>
                </div>
              </div>

              {/* Examples Chips */}
              <div>
                <h4 className="text-xs font-bold text-slate-900 mb-2">Common Household Examples:</h4>
                <div className="flex flex-wrap gap-2">
                  {selectedCategory.examples.map((ex, i) => (
                    <span
                      key={i}
                      className="px-3 py-1 bg-slate-100 text-slate-800 rounded-lg text-xs font-medium border border-slate-200/70"
                    >
                      {ex}
                    </span>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            <div className="bg-white rounded-3xl border border-slate-200 p-12 text-center text-slate-400">
              Select a category to view its complete disposal guidelines.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
