import React from 'react';
import { AuthProvider, useAuth } from './context/AuthContext.tsx';
import { Navbar } from './components/Navbar.tsx';
import { Sidebar } from './components/Sidebar.tsx';
import { LandingPage } from './pages/LandingPage.tsx';
import { CitizenDashboard } from './pages/CitizenDashboard.tsx';
import { WasteScannerPage } from './pages/WasteScannerPage.tsx';
import { WasteInfoPage } from './pages/WasteInfoPage.tsx';
import { ReportWastePage } from './pages/ReportWastePage.tsx';
import { MyReportsPage } from './pages/MyReportsPage.tsx';
import { NearbyCentersPage } from './pages/NearbyCentersPage.tsx';
import { CreditPointsPage } from './pages/CreditPointsPage.tsx';
import { AiAssistantPage } from './pages/AiAssistantPage.tsx';
import { IllegalDumpingPage } from './pages/IllegalDumpingPage.tsx';
import { AdminDashboard } from './pages/AdminDashboard.tsx';
import { WorkerDashboard } from './pages/WorkerDashboard.tsx';
import { ProfilePage } from './pages/ProfilePage.tsx';
import { AuthPages } from './pages/AuthPages.tsx';

const MainLayout: React.FC = () => {
  const { currentPage, user } = useAuth();

  const renderContent = () => {
    switch (currentPage) {
      case 'landing':
        return <LandingPage />;
      case 'citizen_dashboard':
        return <CitizenDashboard />;
      case 'waste_scanner':
        return <WasteScannerPage />;
      case 'waste_info':
        return <WasteInfoPage />;
      case 'report_waste':
        return <ReportWastePage />;
      case 'my_reports':
        return <MyReportsPage />;
      case 'nearby_centers':
        return <NearbyCentersPage />;
      case 'credit_points':
        return <CreditPointsPage />;
      case 'ai_assistant':
        return <AiAssistantPage />;
      case 'violations_enforcement':
        return <IllegalDumpingPage />;
      case 'admin_dashboard':
        return <AdminDashboard />;
      case 'worker_dashboard':
        return <WorkerDashboard />;
      case 'profile':
        return <ProfilePage />;
      case 'auth':
        return <AuthPages />;
      default:
        return <CitizenDashboard />;
    }
  };

  // If unauthenticated or on landing / auth page, render full screen without the dashboard sidebar
  const isFullScreen = !user || currentPage === 'landing' || currentPage === 'auth';

  return (
    <div className="relative min-h-screen text-slate-900 flex flex-col font-sans">
      {/* Smart City Background Photo for ALL roles & dashboards */}
      <div
        className="fixed inset-0 z-0 bg-cover bg-center bg-no-repeat bg-fixed pointer-events-none"
        style={{
          backgroundImage: `url('https://images.unsplash.com/photo-1477959858617-67f30bc75b82?w=1920&auto=format&fit=crop&q=80')`
        }}
      />
      {/* Light translucent smart city overlay so content has high contrast and readability */}
      <div className="fixed inset-0 z-0 bg-slate-100/90 backdrop-blur-[1px] pointer-events-none" />

      <div className="relative z-10 flex flex-col min-h-screen">
        <Navbar />

        <div className="flex-1 flex overflow-hidden">
          {!isFullScreen && <Sidebar />}

          <main className={`flex-1 overflow-y-auto ${isFullScreen ? 'p-0' : 'p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto w-full'}`}>
            {renderContent()}
          </main>
        </div>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <AuthProvider>
      <MainLayout />
    </AuthProvider>
  );
}
