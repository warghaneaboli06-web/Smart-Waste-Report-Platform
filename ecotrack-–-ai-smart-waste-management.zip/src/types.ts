export type UserRole = 'citizen' | 'admin' | 'worker' | 'enforcement';

export type AccountStatus = 'active' | 'warning' | 'fine_pending' | 'temporarily_restricted' | 'suspended';

export interface User {
  id: string;
  name: string;
  email: string;
  mobile_number: string;
  phone?: string;
  address?: string;
  role: UserRole;
  profile_photo: string;
  avatar_url?: string;
  vehicle_number?: string;
  license_number?: string;
  credit_points: number;
  green_score: number;
  account_status: AccountStatus;
  created_at: string;
}

export interface WasteCategory {
  id: string;
  name: string;
  classification: 'Recyclable' | 'Biodegradable' | 'Hazardous' | 'Special Disposal' | 'Non-Recyclable';
  description: string;
  environmental_impact: string;
  correct_disposal: string;
  recycling_info: string;
  safety_precautions: string;
  color_code: string;
  icon_name: string;
  degradation_period: string;
  points_reward: number;
  examples: string[];
}

export type ReportStatus =
  | 'Submitted'
  | 'Under Verification'
  | 'Verified'
  | 'Worker Assigned'
  | 'In Progress'
  | 'Resolved'
  | 'Rejected';

export type Priority = 'low' | 'medium' | 'high' | 'critical';

export interface WasteReport {
  id: string;
  complaint_id: string;
  user_id: string;
  user_name: string;
  user_email: string;
  category_id: string;
  category_name: string;
  description: string;
  image_url: string;
  latitude: number;
  longitude: number;
  address: string;
  priority: Priority;
  status: ReportStatus;
  assigned_worker_id?: string;
  assigned_worker_name?: string;
  before_photo_url?: string;
  after_photo_url?: string;
  rejection_reason?: string;
  verified_by?: string;
  verified_at?: string;
  resolved_at?: string;
  created_at: string;
  timeline: {
    status: ReportStatus;
    timestamp: string;
    note: string;
  }[];
}

export interface WasteCenter {
  id: string;
  name: string;
  facility_type: 'Recycling Center' | 'E-Waste Center' | 'Dry Waste Collection Point' | 'Wet Waste Composting Facility' | 'Hazardous Waste Depot' | 'Smart Public Bin';
  address: string;
  latitude: number;
  longitude: number;
  contact_phone: string;
  operating_hours: string;
  accepted_categories: string[];
  capacity_status: 'normal' | 'high' | 'full';
  distance_km?: number;
}

export interface NotificationItem {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: 'report_status' | 'points_earned' | 'violation_alert' | 'general_announcement' | 'worker_dispatch';
  related_id?: string;
  is_read: boolean;
  created_at: string;
}

export interface PointTransaction {
  id: string;
  user_id: string;
  amount: number;
  activity_type: string;
  description: string;
  reference_id?: string;
  created_at: string;
}

export interface RewardItem {
  id: string;
  name: string;
  badge_title: string;
  points_required: number;
  category: 'badge' | 'municipal_discount' | 'transit_pass' | 'eco_merchandise' | 'plantation';
  description: string;
  icon_name: string;
  unlocked?: boolean;
}

export interface ViolationRecord {
  id: string;
  case_number: string;
  reporter_id: string;
  reporter_name: string;
  vehicle_number: string;
  vehicle_image_url: string;
  waste_image_url: string;
  location_address: string;
  latitude: number;
  longitude: number;
  incident_timestamp: string;
  ocr_confidence: number;
  violation_type: string;
  status: 'Pending Verification' | 'Verified Violation' | 'Warning Issued' | 'Fine Levied' | 'Restriction Applied' | 'Dismissed';
  restriction_status: 'Cleared' | 'Warning' | 'Fine Pending' | 'Temporarily Restricted';
  penalty_amount: number;
  verified_by?: string;
  notes?: string;
  created_at: string;
}

export interface WasteScanRecord {
  id: string;
  user_id: string;
  image_url: string;
  detected_category_id: string;
  detected_item_name: string;
  confidence_score: number;
  disposal_instructions: string;
  points_awarded: number;
  scan_timestamp: string;
}

export interface HotspotArea {
  id: string;
  zone_name: string;
  risk_level: 'High' | 'Medium' | 'Low';
  complaint_count: number;
  predicted_probability: number;
  primary_waste_type: string;
  recommended_action: string;
  latitude: number;
  longitude: number;
  radius_meters: number;
}
