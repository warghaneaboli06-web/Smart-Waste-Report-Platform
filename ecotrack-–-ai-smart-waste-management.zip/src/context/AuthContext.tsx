import React, { createContext, useContext, useState, useEffect } from 'react';
import { User, UserRole } from '../types.ts';
import { loginUser, registerUser } from '../services/api.ts';

interface AuthContextType {
  user: User | null;
  role: UserRole;
  isAuthenticated: boolean;
  currentPage: string;
  setCurrentPage: (page: string) => void;
  loginAs: (role: UserRole) => Promise<void>;
  loginCustom: (email: string, password?: string) => Promise<void>;
  login: (email: string, password?: string) => Promise<void>;
  register: (data: any) => Promise<void>;
  switchRole: (role: UserRole) => Promise<void>;
  logout: () => void;
  updateUserContext: (updated: Partial<User>) => void;
  selectedCategoryForInfo?: string | null;
  setSelectedCategoryForInfo: (catId: string | null) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Website starts at Welcome page with no user pre-logged in
  const [user, setUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<string>('landing');
  const [selectedCategoryForInfo, setSelectedCategoryForInfo] = useState<string | null>(null);

  const role = user?.role || 'citizen';
  const isAuthenticated = !!user;

  const loginAs = async (targetRole: UserRole) => {
    try {
      const emailMap: Record<UserRole, string> = {
        citizen: 'citizen@ecotrack.city',
        admin: 'admin@ecotrack.city',
        worker: 'worker@ecotrack.city',
        enforcement: 'enforcement@ecotrack.city'
      };
      const res = await loginUser(emailMap[targetRole], targetRole);
      setUser(res.user);

      // Route to default page for each role
      if (targetRole === 'admin') setCurrentPage('admin_dashboard');
      else if (targetRole === 'worker') setCurrentPage('worker_dashboard');
      else if (targetRole === 'enforcement') setCurrentPage('violations_enforcement');
      else setCurrentPage('citizen_dashboard');
    } catch (err) {
      console.error('Role login failed', err);
    }
  };

  const loginCustom = async (email: string) => {
    const res = await loginUser(email);
    setUser(res.user);
    if (res.user.role === 'admin') setCurrentPage('admin_dashboard');
    else if (res.user.role === 'worker') setCurrentPage('worker_dashboard');
    else if (res.user.role === 'enforcement') setCurrentPage('violations_enforcement');
    else setCurrentPage('citizen_dashboard');
  };

  const login = async (email: string, password?: string) => {
    const res = await loginUser(email);
    setUser(res.user);
    if (res.user.role === 'admin') setCurrentPage('admin_dashboard');
    else if (res.user.role === 'worker') setCurrentPage('worker_dashboard');
    else if (res.user.role === 'enforcement') setCurrentPage('violations_enforcement');
    else setCurrentPage('citizen_dashboard');
  };

  const register = async (data: any) => {
    const res = await registerUser(data);
    setUser(res.user);
    if (res.user.role === 'admin') setCurrentPage('admin_dashboard');
    else if (res.user.role === 'worker') setCurrentPage('worker_dashboard');
    else if (res.user.role === 'enforcement') setCurrentPage('violations_enforcement');
    else setCurrentPage('citizen_dashboard');
  };

  const switchRole = async (targetRole: UserRole) => {
    await loginAs(targetRole);
  };

  const logout = () => {
    setUser(null);
    setCurrentPage('landing');
  };

  const updateUserContext = (updated: Partial<User>) => {
    if (user) {
      setUser({ ...user, ...updated });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role,
        isAuthenticated,
        currentPage,
        setCurrentPage,
        loginAs,
        loginCustom,
        login,
        register,
        switchRole,
        logout,
        updateUserContext,
        selectedCategoryForInfo,
        setSelectedCategoryForInfo
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
